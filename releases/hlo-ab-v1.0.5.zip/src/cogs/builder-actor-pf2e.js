// ============================================================
// COG: builder-actor-pf2e.js - PF2e actor skeleton builder
//                              (and the chassis SF2e re-uses)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.4.2
//           - v0.7.2: BUG FIX (the LAST v0.7.1 bug before launch).
//             buildPfsBoonItems now emits a FULLY shaped FeatPF2e
//             source for each chronicle boon, not a sparse stub.
//             v0.7.1's stub set type=feat + category=pfsboon and
//             passed the FeatSystemData schema in isolation but
//             every boon still vanished after import (Berial PFS
//             re-import log: bulk failed on Devil's Keep's invalid
//             frequency.per="scenario", per-item retry claimed
//             "112 of 113 added", yet zero category=pfsboon items
//             appeared on the actor). The per-item retry's success
//             counter was over-reporting because PF2e's createDocuments
//             override (pf2e.mjs line 50098-50173) silently returns
//             [] in several failure modes inside the inner construction
//             pipeline, and the dialog's per-item catch only sees
//             explicit exceptions. The v0.7.2 fix is to give the
//             FeatPF2e document everything its defineSchema names
//             (pf2e.mjs line 74503-74660): description.value + .gm,
//             traits.value + .otherTags + .rarity, level.value +
//             .taken, category, onlyLevel1, maxTakable,
//             actionType.value, actions.value, prerequisites.value,
//             subfeatures with all nested fields, an empty rules
//             array, slug, frequency only when HLO provided one with
//             a valid enum per. flags.pf2e is initialized to {} so
//             downstream code that walks item.flags.pf2e.grantedBy
//             never sees an undefined intermediate. Devil's Keep's
//             Period="Scenario" maps to per="day" via the parser's
//             mapHloPeriodToFrequencyPer helper (PFS scenarios are
//             single-session affairs; day is the closest enum value).
//             Verified against Berial PFS: all 9 boons land with
//             category=pfsboon and prepareFeats() (pf2e.mjs line
//             38942-38951) buckets them into actor.pfsBoons for the
//             PFS tab render.
//           - 0.4.1: v0.7.1 first attempt. Switched type from
//             campaignFeature to feat. Document construction passed
//             but actor still missing the boons. Superseded by 0.4.2.
//           - 0.4.0: v0.7.0: PFS metadata + PFS boons. buildPfsBlock()
//             walks the actor IR for Faction items (compset
//             "Faction", id prefix "fa") and populates
//             system.pfs.reputation by two-letter faction code
//             (EA / GA / HH / RO / VW / VS), matching the PF2e
//             template.json schema. The Faction handler emits a
//             discriminator `_actorMetadata.subtype === "faction"`
//             that this builder reads; if the handler is not yet
//             registered, the builder also falls back to reading
//             item.compset directly so Berial's six PFS faction
//             memberships still land. buildPfsBoonItems() reads
//             the CustomReward / CustomBoon items and emits one
//             campaignFeature entry per boon with category
//             "pfsboon", which the PF2e sheet renders in its
//             PFS tab. These boons bypass the matcher (no
//             compendium entry exists for player-owned chronicle
//             rewards) and are concatenated into the embedded
//             items list alongside the lore items.
//           - 0.3.0: v0.6.4. buildDetails now derives system.details.
//             keyability.value from the parsed class slug via
//             ./builder-class-defaults.js. SF2e auto-derives
//             every weapon attack and damage modifier from
//             this field; without it, attacks compute against
//             zero. Fixture confirmed at data/test-fixtures/
//             fvtt-actor-bhelthal-operative-lvl1.json
//             (keyability.value = "str" on user's rebuilt
//             Operative; standard Operative defaults to dex
//             per Player Core). The class-defaults cog
//             maintains the slug -> default-key-ability table
//             for both PF2e and SF2e.
//           - 0.2.0: Wave 3 of the cog migration. Promoted from
//             src/builder/build-actor-pf2e.js. Internal imports
//             repointed at sibling cogs (./builder-items.js,
//             ./builder-hp.js). No logic changes; the SF2e cog
//             continues to re-import 11 names from this file
//             (5 constants + 6 helpers).
//           - 0.1.0: Phase 1 (in src/builder/). PF2e/SF2e actor
//             builder. Produces an ActorSkeleton that the import
//             dialog hands to a resolver step before passing to
//             Actor.create or actor.importFromJSON.
//
// PF2e Foundry V13+ shape (subset relevant to Phase 1):
//   {
//     name, type: "character",
//     system: {
//       details: { level: {value}, ancestry, heritage, class, deity },
//       abilities: { str: {mod}, dex: {mod}, ... },
//       attributes: { speed: {value}, hp: {value, max} },
//       saves: { fortitude: {rank}, reflex: {rank}, will: {rank} },
//       skills: { acrobatics: {rank}, athletics: {rank}, ... }
//     },
//     items: [ ... compendium-reference stubs ... ]
//   }
//
// The system handles HP, AC, attack bonuses, etc., as derived stats from the
// inputs above. We deliberately do not set computed totals; setting them
// would fight the PF2e auto-calc layer and cause sheet anomalies.

import { buildItemReferences, applyRuneAndMaterialPatches } from "./builder-items.js";
import { computeBaselineHp } from "./builder-hp.js";
import { keyAbilityForClass } from "./builder-class-defaults.js";
import { factionCodeFor } from "./parser-compset-faction.js";
import { mapHloPeriodToFrequencyPer } from "./parser-compset-customreward.js";

export const ABILITY_KEY = {
  Strength:     "str",
  Dexterity:    "dex",
  Constitution: "con",
  Intelligence: "int",
  Wisdom:       "wis",
  Charisma:     "cha",
};

export const SAVE_KEY = {
  "Fortitude Save": "fortitude",
  "Reflex Save":    "reflex",
  "Will Save":      "will",
};

export const PROFICIENCY_RANKS = {
  Untrained: 0, Trained: 1, Expert: 2, Master: 3, Legendary: 4,
};

// SF2e classes that ship with built-in focus or resolve pools. The HLO
// Reserves compset already surfaces these per-character; this set is a
// hint for the SF2e builder when no explicit Reserves item exists.
export const SF2E_FOCUS_POOL_CLASSES = new Set([
  "mystic", "witchwarper", "technomancer",
]);

/**
 * Build a Foundry actor skeleton from the parser+matcher output.
 *
 * @param {object} actorIR    From parseActor.
 * @param {Array}  matched    From matcher.matchAll (per-item match records).
 * @param {string} systemId   "pf2e" or "sf2e" (controls which packs to reference).
 * @returns {object}          ActorSkeleton ready for the resolver step.
 */
export function buildActorSkeleton(actorIR, matched, systemId) {
  // v0.7.1: consume Rune and Material apply-to-parent patches before
  // anything reads actorIR.items. The pass merges each rune/material
  // into its parent weapon/armor IR (mutates parent.runes /
  // parent.material) and tags the patch items with _consumed=true so
  // the matched-list filter below excludes them from
  // buildItemReferences. Without this step the Rune/Material handlers
  // would silently drop data even though the parser identified the
  // compset.
  applyRuneAndMaterialPatches(actorIR);

  const system = {
    details:    buildDetails(actorIR, matched, systemId),
    abilities:  buildAbilities(actorIR.items),
    attributes: buildAttributes(actorIR),
    saves:      buildSaves(actorIR.items),
    skills:     buildSkills(actorIR.items),
  };

  const languages = buildLanguages(actorIR.items);
  if (languages.length > 0) {
    system.details.languages = { value: languages };
  }

  // PFS faction memberships ride on actor metadata, not embedded items.
  // Adds `system.pfs.reputation = { EA: 0, GA: 0, ... }` per faction
  // entry HLO surfaced. No-op for non-PFS actors (no Faction items).
  const pfs = buildPfsBlock(actorIR.items);
  if (pfs) {
    system.pfs = pfs;
  }

  const compendiumItems = buildItemReferences(
    // Only embed items that map to compendium entries; stat-bearing compsets
    // are absorbed into `system` and do not produce embedded items.
    // v0.7.1: Rune and Material patches are consumed by
    // applyRuneAndMaterialPatches above and tagged with _consumed; their
    // data is merged into the parent weapon/armor IR. We filter them out
    // here so they do not also land as embedded items.
    matched.filter(({ item }) =>
      !STAT_BEARING_COMPSETS.has(item.compset) && !item._consumed),
  );

  // Lore subskills are emitted as embedded "lore" items here, since they are
  // user-created per actor and have no compendium entry to reference.
  const loreItems = buildLoreItems(actorIR.items);

  // PFS chronicle boons (CustomReward / CustomBoon) become embedded
  // feat items with category "pfsboon"; the official PF2e character
  // sheet's prepareFeats() routine (pf2e.mjs line 38946-38951) filters
  // itemTypes.feat where category === "pfsboon" and renders them in
  // the PFS tab automatically. v0.7.0 wrongly used type "campaignFeature"
  // (the Kingmaker item type, whose category enum is restricted to
  // KINGMAKER_CATEGORY_TYPES; pf2e.mjs line 73971-73976), which Foundry
  // rejected at create-time with "category: pfsboon is not a valid
  // choice" across all chronicle boons. Fixed in v0.7.1.
  const pfsBoonItems = buildPfsBoonItems(actorIR.items);

  const items = [...compendiumItems, ...loreItems, ...pfsBoonItems];

  return {
    name: actorIR.name ?? "Imported HLO Character",
    type: actorIR.actorType ?? "character",
    system,
    items,
    flags: {
      "hlo-importer-abyssal-engine": {
        importedAt: new Date().toISOString(),
        sourceHloVersion: actorIR.raw?.hloVersion ?? null,
        sourceSystem: systemId,
        hloKey: actorIR.key,
        hloCharId: actorIR.portfolioCharId ?? null,
        actorTypeDetection: {
          detected: actorIR.actorType ?? "character",
          minionSubtype: actorIR.minionSubtype ?? null,
          confidence: actorIR.actorTypeConfidence ?? null,
          reasons: actorIR.actorTypeReasons ?? [],
        },
      },
    },
  };
}

// Compsets the builder absorbs into `system` (or into actor metadata)
// rather than emitting as embedded items. The matcher returns null for
// these, but the filter below keeps them out of buildItemReferences in
// case a future override accidentally points them at a pack.
//
// PFS-specific entries:
//   Faction       -> system.pfs.reputation (handled by buildPfsBlock)
//   CustomReward  -> embedded feat items (category "pfsboon") via buildPfsBoonItems
//   CustomBoon    -> embedded feat items (category "pfsboon") via buildPfsBoonItems
// CustomReward and CustomBoon are excluded from the compendium-reference
// pipeline here because the boons are bespoke per-character; the builder
// synthesizes them directly alongside the lore items.
export const STAT_BEARING_COMPSETS = new Set([
  "AbilScore", "Save", "Skill", "ArmorClass", "Movement", "Reserves",
  "Derived", "Language", "Trait",
  "Faction", "CustomReward", "CustomBoon",
  // v0.7.1: Rune and Material items are apply-to-parent patches; their
  // data is merged into the parent weapon/armor's IR by
  // applyRuneAndMaterialPatches above, and the patch items themselves
  // are not embedded on the actor. STAT_BEARING_COMPSETS doubles as
  // the "do not produce an embedded item" filter, so they belong here.
  "Rune", "Material",
]);

export function buildDetails(actorIR, _matched, _systemId) {
  // PF2e/SF2e treat ancestry, heritage, class, and deity as embedded items on
  // the actor; the sheet derives display fields from them. We deliberately do
  // not set system.details.{ancestry,heritage,class,deity} inline here, since
  // doing so duplicates state and can fight the system's data model. The
  // matched items appear in the `items` array via buildItemReferences below.
  const details = {
    level: { value: actorIR.gameValues.levelNet ?? 1 },
  };
  if (actorIR.gameValues.xpNet != null) {
    details.xp = { value: actorIR.gameValues.xpNet };
  }
  // Derive key ability from the parsed class. SF2e auto-derives every
  // weapon attack and damage modifier from system.details.keyability.
  // value; if it is undefined when the actor renders, attacks compute
  // against zero. The class-defaults cog maps Operative -> dex, Soldier
  // -> con, etc. Fixture confirmation:
  // data/test-fixtures/fvtt-actor-bhelthal-operative-lvl1.json shows
  // details.keyability.value populated. Skipped silently for actors
  // with no Class item parsed (which the builder will warn about
  // separately via the unmatched-items log).
  const classItem = actorIR.items.find((i) => i.compset === "Class");
  const classSlug = classItem?.primarySlug ?? classItem?.slug ?? null;
  const keyAbility = keyAbilityForClass(classSlug);
  if (keyAbility) {
    details.keyability = { value: keyAbility };
  }
  return details;
}

export function buildAbilities(items) {
  const out = { str: {mod: 0}, dex: {mod: 0}, con: {mod: 0}, int: {mod: 0}, wis: {mod: 0}, cha: {mod: 0} };
  for (const item of items) {
    if (item.compset !== "AbilScore") continue;
    const key = ABILITY_KEY[item.name];
    if (!key) continue;
    out[key] = { mod: item.modifier ?? 0 };
  }
  return out;
}

export function buildAttributes(actorIR) {
  const out = {};
  const speedItem = actorIR.items.find((i) => i.compset === "Movement");
  if (speedItem) {
    out.speed = { value: speedItem.speed ?? 25 };
  }
  // Baseline HP so the sheet renders sensible numbers before the auto-calc
  // layer catches up. Null result means we did not have enough data; in
  // that case we leave HP unset and let Foundry fill in.
  const hp = computeBaselineHp(actorIR);
  if (hp != null) {
    out.hp = { value: hp, max: hp };
  }
  return out;
}

export function buildSaves(items) {
  const out = {};
  for (const item of items) {
    if (item.compset !== "Save") continue;
    const key = SAVE_KEY[item.name];
    if (!key) continue;
    out[key] = { rank: rankFor(item.profLevel) };
  }
  return out;
}

export function buildSkills(items) {
  const out = {};
  for (const item of items) {
    if (item.compset !== "Skill") continue;
    // Lore subskills are handled separately as embedded "lore" items;
    // they do not live on system.skills.
    if (isLoreSkillName(item.name)) continue;
    const key = slugifySkillName(item.name);
    out[key] = { rank: rankFor(item.profLevel) };
  }
  return out;
}

export function isLoreSkillName(name) {
  if (!name) return false;
  return / Lore$/i.test(name.trim());
}

/**
 * Lore skills become embedded "lore" items on the actor, not entries on
 * system.skills. Each gets the rank from the HLO Skill item's profLevel.
 */
export function buildLoreItems(items) {
  const out = [];
  for (const item of items) {
    if (item.compset !== "Skill") continue;
    if (!isLoreSkillName(item.name)) continue;
    out.push({
      name: item.name,
      type: "lore",
      system: {
        proficient: { value: rankFor(item.profLevel) },
        slug: slugifyLoreName(item.name),
      },
      flags: {
        "hlo-importer-abyssal-engine": {
          sourceCompset: "Skill",
          hloSlug: item.slug,
        },
      },
    });
  }
  return out;
}

function slugifyLoreName(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

export function buildLanguages(items) {
  const out = [];
  for (const item of items) {
    if (item.compset !== "Language") continue;
    const key = slugifySkillName(item.name);
    if (key) out.push(key);
  }
  return out;
}

export function rankFor(profLevel) {
  return PROFICIENCY_RANKS[profLevel] ?? 0;
}

export function slugifySkillName(name) {
  if (!name) return null;
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

/**
 * Build the PFS metadata block for the actor from any HLO Faction
 * items (compset "Faction", id prefix "fa"). Returns null when the
 * actor has no Faction items (the typical non-PFS path).
 *
 * Schema target (verified against pf2e v8.1.2 template.json):
 *   system.pfs = {
 *     playerNumber: null, characterNumber: null,
 *     levelBump: false, currentFaction: "EA", school: null,
 *     reputation: { EA: null, GA: null, HH: null, VS: null, RO: null, VW: null }
 *   }
 * The reputation slot for each known faction is flipped from null to
 * the patch's reputation value (defaulting to 0 if the handler did
 * not surface one); unknown faction names are logged at parse time
 * and skipped here so they do not corrupt the schema.
 *
 * The handler emits an `_actorMetadata` discriminator on the IR;
 * this builder also falls back to a direct compset/name lookup so
 * the data still lands if the parser-compset-registry entry has not
 * been wired yet (defensive path during the v0.7.0 rollout).
 */
export function buildPfsBlock(items) {
  const factionItems = items.filter((it) => it?.compset === "Faction");
  if (factionItems.length === 0) return null;
  const reputation = { EA: null, GA: null, HH: null, VS: null, RO: null, VW: null };
  let currentFaction = null;
  for (const item of factionItems) {
    const meta = item._actorMetadata;
    let code = null;
    let rep = 0;
    if (meta && meta.subtype === "faction" && meta.code) {
      code = meta.code;
      rep = typeof meta.reputation === "number" ? meta.reputation : 0;
    } else {
      // Fallback when the handler is not registered: derive the
      // two-letter code from the item name directly so the row still
      // flips from null to "member" on the sheet.
      code = factionCodeFor(item.name);
    }
    if (!code || !(code in reputation)) continue;
    reputation[code] = rep;
    if (currentFaction == null) currentFaction = code;
  }
  return {
    playerNumber:     null,
    characterNumber:  null,
    levelBump:        false,
    currentFaction:   currentFaction ?? "EA",
    school:           null,
    reputation,
  };
}

/**
 * Build embedded PFS chronicle boon items from the actor IR. HLO
 * emits these under two compsets, CustomReward (id prefix
 * "bnCustom") and CustomBoon (id prefix "bnCustomN"); both map to
 * PF2e's `feat` item type with category "pfsboon".
 *
 * Why feat and not campaignFeature: the PF2e character sheet's
 * prepareFeats() routine (pf2e.mjs line 38946-38951) explicitly
 * filters itemTypes.feat for category "pfsboon" and pushes those
 * into the pfsBoons render bucket that drives the PFS tab. The
 * campaignFeature item type is the Kingmaker / kingdom-building
 * item; its category schema (CampaignFeatureSystemData.defineSchema,
 * line 73971-73976) restricts category to KINGMAKER_CATEGORY_TYPES
 * (army-tactic, kingdom-feat, kingdom-feature, kingdom-activity,
 * army-war-action). v0.7.0 wrongly used campaignFeature+pfsboon and
 * Foundry rejected every chronicle boon with a SchemaField error.
 *
 * v0.7.2: the emitted source is now FULLY shaped against
 * FeatPF2e.defineSchema (pf2e.mjs line 74503-74660) rather than a
 * sparse stub. v0.7.1's stub passed the schema in isolation but
 * boons still vanished after import (Berial PFS re-import log
 * captured 9 boons missing despite "112 of 113 items added"). The
 * per-item retry's success counter was over-reporting because PF2e's
 * createDocuments override silently returns [] in several failure
 * modes inside the inner construction pipeline, and the dialog's
 * per-item catch only sees explicit exceptions. Giving the document
 * everything the schema names removes the coercion-time failure
 * modes and the boons survive create.
 *
 * The handler emits a `_homebrewItem` discriminator carrying the
 * canonical shape; this helper falls back to raw fields when the
 * handler has not been registered yet so boons still land during
 * the v0.7.0/v0.7.1 rollout.
 */
export function buildPfsBoonItems(items) {
  const out = [];
  for (const item of items) {
    if (item?.compset !== "CustomReward" && item?.compset !== "CustomBoon") continue;
    const patch = item._homebrewItem ?? null;
    const name = patch?.name ?? item.name ?? "PFS Boon";
    const description = patch?.description
      ?? item.raw?.useInPlay
      ?? "<p><em>Imported from HLO; full text not available in the HLO export. "
         + "Copy the boon text from the Paizo chronicle sheet into this description.</em></p>";

    // Frequency resolution. The parser pre-maps HLO's free-text
    // Period (e.g. "Scenario") to a PF2e enum value via
    // mapHloPeriodToFrequencyPer; we honor patch.frequency when set
    // (already a {max, per} pair or null), otherwise we derive it
    // from raw fields defensively so boons still land if the
    // handler is on an older revision.
    let frequency = patch?.frequency ?? null;
    if (frequency == null) {
      const fallbackPer = mapHloPeriodToFrequencyPer(item.raw?.Period);
      const fallbackMax = typeof item.raw?.trkMaximum === "number" ? item.raw.trkMaximum : null;
      if (fallbackPer && fallbackMax != null && fallbackMax > 0) {
        frequency = { max: fallbackMax, per: fallbackPer };
      }
    }
    const slug = slugifySkillName(name) || "pfs-boon";

    // Construct a FULLY shaped FeatSystemData source. Every field
    // here corresponds to a required entry in pf2e.mjs line
    // 74503-74660; omitting any of them lets the system's schema
    // initializer fill defaults during the actor-side construction,
    // but in practice those late-bound defaults are where the boon
    // items silently disappeared in v0.7.1. Passing complete data
    // makes the construction deterministic.
    const system = {
      description: {
        value: description ? String(description) : "",
        gm: "",
      },
      rules: [],
      slug,
      publication: {
        title:    "Pathfinder Society",
        authors:  "",
        license:  "OGL",
        remaster: false,
      },
      traits: {
        otherTags: [],
        value:     [],
        rarity:    "common",
      },
      level: {
        value: 1,
        taken: 1,
      },
      category: "pfsboon",
      onlyLevel1: false,
      maxTakable: 1,
      actionType: { value: "passive" },
      actions:    { value: null },
      prerequisites: { value: [] },
      subfeatures: {
        keyOptions: [],
        languages: {
          slots:   0,
          granted: [],
        },
        proficiencies:    {},
        senses:           {},
        suppressedFeatures: [],
      },
    };
    if (frequency) {
      // Pre-validated by mapHloPeriodToFrequencyPer; per is a CONFIG
      // .PF2E.frequencies enum key (pf2e.mjs line 62951-62962),
      // max is a positive integer. Foundry's FrequencyField also
      // optionally accepts a numeric `value` for current uses
      // remaining; we set it to max so the boon starts unused.
      system.frequency = {
        max:   frequency.max,
        per:   frequency.per,
        value: frequency.max,
      };
    }

    out.push({
      name,
      type: "feat",
      img:  "icons/sundries/documents/document-sealed-red.webp",
      system,
      // flags.pf2e is pre-initialized so any code that walks
      // item.flags.pf2e.grantedBy.id (notably the system's class
      // grant-graph traversal) sees an object instead of undefined.
      // hlo-importer-abyssal-engine flag carries the back-reference
      // so the import log + journal can identify the boon's HLO
      // origin if the user later asks where it came from.
      flags: {
        pf2e: {},
        "hlo-importer-abyssal-engine": {
          sourceCompset: item.compset,
          hloSlug: item.slug,
          hloPeriodRaw: patch?.hloPeriodRaw ?? item.raw?.Period ?? null,
        },
      },
    });
  }
  return out;
}
