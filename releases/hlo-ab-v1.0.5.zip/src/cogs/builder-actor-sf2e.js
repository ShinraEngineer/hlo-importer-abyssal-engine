// ============================================================
// COG: builder-actor-sf2e.js - SF2e actor skeleton builder
//                              (thin overlay on the PF2e cog)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.4.0
//           - v0.7.0: PFS metadata + chronicle boons. SF2e's
//             template.json (verified against data/FoundryVTT-
//             WindowsPortable-14.361/Data/systems/sf2e/template
//             .json lines 106-120) ships the same system.pfs
//             reputation schema as PF2e (EA / GA / HH / RO / VW
//             / VS) and the same campaignFeature item type with
//             category "pfsboon", so SF2e Organized Play
//             characters wear identical metadata. We delegate to
//             the PF2e builder's buildPfsBlock and
//             buildPfsBoonItems helpers (re-exported from the
//             chassis) rather than duplicating the logic.
//           - 0.3.0: Wave 3 of the cog migration. Promoted from
//             src/builder/build-actor-sf2e.js. Internal imports
//             repointed at sibling cogs (./builder-actor-pf2e.js
//             for the 11 reused names + ./builder-items.js for
//             buildItemReferences). No logic changes.
//           - 0.2.0: Phase 3 (in src/builder/). Dedicated SF2e
//             actor builder. Composes the PF2e shared core
//             (abilities, saves, skills, lores, languages,
//             attributes, details) and layers SF2e-specific
//             behavior on top: augmentation flagging, focus
//             pool placeholder for casters, weapon-upgrade
//             tagging for tech weapons.
//
// PF2e and SF2e share enough of the chassis (system data layer, ability
// schema, proficiency rank model) that a clean fork would invite drift.
// Instead this cog re-uses the PF2e cog's exported helpers and only
// implements the bits that genuinely diverge.

import {
  ABILITY_KEY,
  SAVE_KEY,
  PROFICIENCY_RANKS,
  STAT_BEARING_COMPSETS,
  SF2E_FOCUS_POOL_CLASSES,
  buildDetails,
  buildAbilities,
  buildAttributes,
  buildSaves,
  buildSkills,
  buildLanguages,
  buildLoreItems,
  buildPfsBlock,
  buildPfsBoonItems,
  rankFor,
  slugifySkillName,
  isLoreSkillName,
} from "./builder-actor-pf2e.js";
import { buildItemReferences, applyRuneAndMaterialPatches } from "./builder-items.js";

/**
 * Build a Foundry SF2e actor skeleton. Same shape as the PF2e variant; the
 * difference is in how augmentations, weapon upgrades, and focus pools are
 * tagged on the way out.
 *
 * @param {object} actorIR    From parseActor.
 * @param {Array}  matched    From matcher.matchAll.
 * @param {string} systemId   Expected: "sf2e".
 * @returns {object}          ActorSkeleton.
 */
export function buildActorSkeletonSf2e(actorIR, matched, systemId) {
  // v0.7.1: consume Rune and Material apply-to-parent patches before
  // anything reads actorIR.items. Identical to the PF2e path; see
  // builder-actor-pf2e.js for the rationale.
  applyRuneAndMaterialPatches(actorIR);

  const system = {
    details:    buildDetails(actorIR, matched, systemId),
    abilities:  buildAbilities(actorIR.items),
    attributes: buildAttributes(actorIR),
    saves:      buildSaves(actorIR.items),
    skills:     buildSkills(actorIR.items),
  };

  const languages = buildLanguages(actorIR.items);
  if (languages.length > 0) {
    system.details.languages = { value: languages };
  }

  // PFS faction memberships ride on actor metadata, not embedded items.
  // SF2e's pfs.reputation schema is identical to PF2e's, so the same
  // helper populates it for SFS Organized Play characters.
  const pfs = buildPfsBlock(actorIR.items);
  if (pfs) {
    system.pfs = pfs;
  }

  // Focus pool placeholder: HLO surfaces Focus Points via the Reserves
  // compset, which the parser already captures. For SF2e caster classes
  // (Mystic, Witchwarper, Technomancer) we surface a focus block even when
  // HLO did not emit a Reserves entry, so the sheet has something to
  // render at zero rather than an empty struct that confuses the system.
  attachFocusPool(actorIR, system);

  // Augmentations and weapon/armor upgrades arrive as items via the
  // matcher; tag them in flags so the SF2e sheet can group them in the
  // augmentations panel rather than scattering them through Inventory.
  const compendiumItems = buildItemReferences(
    matched.filter(({ item }) =>
      !STAT_BEARING_COMPSETS.has(item.compset) && !item._consumed),
  );
  const taggedItems = compendiumItems.map(tagSf2eItem);

  const loreItems = buildLoreItems(actorIR.items);

  // PFS chronicle boons (CustomReward / CustomBoon) become embedded
  // campaignFeature items. SF2e ships the same item type with the
  // same "pfsboon" category, so the helper works unchanged.
  const pfsBoonItems = buildPfsBoonItems(actorIR.items);

  return {
    name: actorIR.name ?? "Imported HLO Character",
    type: actorIR.actorType ?? "character",
    system,
    items: [...taggedItems, ...loreItems, ...pfsBoonItems],
    flags: {
      "hlo-importer-abyssal-engine": {
        importedAt: new Date().toISOString(),
        sourceHloVersion: actorIR.raw?.hloVersion ?? null,
        sourceSystem: systemId,
        hloKey: actorIR.key,
        hloCharId: actorIR.portfolioCharId ?? null,
        actorTypeDetection: {
          detected: actorIR.actorType ?? "character",
          minionSubtype: actorIR.minionSubtype ?? null,
          confidence: actorIR.actorTypeConfidence ?? null,
          reasons: actorIR.actorTypeReasons ?? [],
        },
      },
    },
  };
}

function attachFocusPool(actorIR, system) {
  const classItem = actorIR.items.find((i) => i.compset === "Class");
  const classSlug = classItem?.primarySlug?.replace(/^cl/, "").toLowerCase();
  if (!classSlug || !SF2E_FOCUS_POOL_CLASSES.has(classSlug)) return;

  const focusReserve = actorIR.items.find(
    (i) => i.compset === "Reserves" && /focus/i.test(i.name ?? ""),
  );
  if (!system.resources) system.resources = {};
  system.resources.focus = {
    value: focusReserve?.trkValue ?? 0,
    max:   focusReserve?.trkMaximum ?? 0,
  };
}

function tagSf2eItem(ref) {
  if (!ref) return ref;
  // Mark augmentations and upgrades so the SF2e sheet can group them.
  if (ref.sourceCompset === "Augmentation") {
    ref.flags ??= {};
    ref.flags["hlo-importer-abyssal-engine"] ??= {};
    ref.flags["hlo-importer-abyssal-engine"].sf2eCategory = "augmentation";
  } else if (ref.sourceCompset === "Upgrade") {
    ref.flags ??= {};
    ref.flags["hlo-importer-abyssal-engine"] ??= {};
    ref.flags["hlo-importer-abyssal-engine"].sf2eCategory = "upgrade";
  }
  return ref;
}
