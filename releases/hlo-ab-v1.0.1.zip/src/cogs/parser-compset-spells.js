// ============================================================
// COG: parser-compset-spells.js - Spell normalizer
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - Migrated from src/parser/compsets/spells.js as part of
//             the cog architecture pivot. Captures rank, DC, range,
//             target, and save fields HLO surfaces. Spell-attack
//             proficiency lives on the Spell item (proLevelBonNet)
//             and is wired through the builder when spellcasting
//             entries take shape.

export const Spell = {
  normalize(raw, _warnings) {
    return {
      spLevelBase:      raw.spLevelBase ?? null,
      spLevelNet:       raw.spLevelNet ?? null,
      proLevelBonNet:   raw.proLevelBonNet ?? null,
      stNet:            raw.stNet ?? null,
      stDC:             raw.stDC ?? null,
      vaSave:           raw.vaSave ?? null,
      vaRangeText:      raw.vaRangeText ?? null,
      vaTarget:         raw.vaTarget ?? null,
      actionRaw:        raw.Action ?? null,
    };
  },
};

export default { id: "parser-compset-spells" };
