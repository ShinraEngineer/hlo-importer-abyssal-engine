// ============================================================
// COG: util-version.js - Module identity constants
//                        (id, title, version, HLO API base/tool name)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-18
// Revision: 1.0.1 - module identity constants (id, title, version,
//           HLO API base/tool name). Full version history is in
//           CHANGELOG.md.

export const MODULE_ID = "hlo-importer-abyssal-engine";
export const MODULE_TITLE = "HeroLab to Foundry - Powered by Abyssal Engine";

// Keep MODULE_VERSION in lockstep with module.json "version": both are
// bumped on every update so Foundry's module list and the on-screen
// version badge agree on exactly which build is running.
export const MODULE_VERSION = "1.0.1";

// HLO Public API. The tool name is stable (no version numbers, per LWD docs).
// Whatever string is passed when acquiring the access token may be surfaced
// publicly inside HLO, so this is a brand-visible identifier.
export const HLO_API_BASE = "https://api.herolab.online";
export const HLO_TOOL_NAME = "HeroLab to Foundry - Powered by Abyssal Engine";

// Recognized Foundry system ids the module reacts to. The SF2e id is a working
// assumption pending verification against the live Foundry package registry
// (open question #1 in the project documentation).
export const SUPPORTED_SYSTEMS = Object.freeze(["pf2e", "sf2e"]);
