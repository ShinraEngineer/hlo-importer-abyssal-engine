// ============================================================
// COG: parser-compset-customarmor.js - CustomArmor normalizer
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.2.0
//           - v0.7.1 Rune Triad (a review pass). Wired util-rune-parser
//             into CustomArmor.normalize for defensive coverage.
//             CustomArmor entries usually do NOT lead with a "+N"
//             rune prefix; the canonical example "Numerian Steel
//             Breastplate" carries no runes in the display name
//             (the rune data lives on a separate compset entry that
//             references this armor via containment). But if a
//             custom armor DOES carry a leading rune prefix the
//             handler now parses it the same way Armor does, so
//             the builder can write system.runes uniformly across
//             both compsets. Empty `runes` envelopes pass through
//             (potency=0, striking=0, propertyRunes=[]); the
//             existing baseName field from extractBaseArmorName is
//             preserved and continues to feed the matcher.
//           - 0.1.0: New compset cog for v0.7.0. HLO emits magic and
//             lore-named armor under the "CustomArmor" compset
//             (id prefix "ar", same prefix as Armor; the compset
//             field disambiguates). Berial's wizard ships
//             arCustomArmor.1221 "Numerian Steel Breastplate"
//             which is a runed +1 Resilient Energy-Resistant
//             breastplate; the display name is custom but the
//             underlying base is the canonical pf2e.equipment-srd
//             "breastplate" entry. CustomArmor mirrors the Armor
//             schema (arAC, arItemAC, arDexModCap, proLevelBonNet,
//             grBulk, profLevel) so the actor builder treats it
//             as a Foundry type="armor" item, and adds a
//             `baseName` field carrying the stripped base term
//             so the matcher can resolve the underlying
//             equipment-srd entry. If the strip yields nothing
//             usable (the name is too custom to parse), the
//             matcher falls through to the raw display name and
//             the dialog embeds it as a homebrew armor item with
//             the custom name preserved.
//
// The strip strategy: PF2e armor names are short kebab-case
// terms (breastplate, chain-shirt, half-plate, full-plate,
// leather, hide, padded, scale-mail, splint-mail, chain-mail,
// studded-leather, plate-armor, buckler). HLO display names
// like "Numerian Steel Breastplate" or "Mithral Chain Shirt"
// follow the same convention as precious-material weapons: a
// flavor prefix in front of the base armor noun. We walk the
// known PF2e base-armor list and look for any one of them as a
// suffix in the display name; the first hit wins. This is
// resilient to the prefix being one word (Mithral) or two
// (Numerian Steel) or more (Adamantine Reinforced).

import { extractRunes } from "./util-rune-parser.js";

/**
 * Same shape transform as parser-compset-armor.adaptRunesForArmor.
 * CustomArmor lands on Foundry as type="armor", so the rune envelope
 * follows the armor schema (potency, resilient, property[]). See the
 * Armor handler comment for why we rename `striking` to `resilient`
 * here.
 */
function adaptRunesForArmor(runes) {
  return {
    potency:       runes.potency ?? 0,
    striking:      0,
    resilient:     runes.striking ?? 0,
    propertyRunes: Array.isArray(runes.propertyRunes) ? runes.propertyRunes : [],
    baseName:      runes.baseName ?? "",
    matchedRunes:  Array.isArray(runes.matchedRunes) ? runes.matchedRunes : [],
  };
}

const PF2E_BASE_ARMORS = [
  // Two-word bases must come first so "chain shirt" beats "chain mail"
  // when both end in the same final word.
  "chain shirt",
  "chain mail",
  "scale mail",
  "splint mail",
  "studded leather",
  "half plate",
  "full plate",
  "plate armor",
  // Single-word bases.
  "breastplate",
  "leather",
  "hide",
  "padded",
  "buckler",
];

/**
 * Strip the custom-name flavor prefix from a CustomArmor display name and
 * return the base armor noun. Case-insensitive on detection; returns the
 * base in canonical lowercase form for slug derivation. Returns null if
 * no known base is detected, in which case the matcher will fall back to
 * the full display name and likely miss, prompting a homebrew embed.
 */
export function extractBaseArmorName(name) {
  if (!name || typeof name !== "string") return null;
  const lower = name.toLowerCase();
  for (const base of PF2E_BASE_ARMORS) {
    if (lower === base) return base;
    if (lower.endsWith(` ${base}`)) return base;
  }
  return null;
}

export const CustomArmor = {
  normalize(raw, _warnings) {
    const baseName = extractBaseArmorName(raw.name);
    // Defensive: most CustomArmor names have no rune prefix, but if
    // one ever does ("+1 Numerian Steel Breastplate") we want the
    // builder to write the +1 to system.runes.potency. The empty
    // envelope returned by extractRunes for non-runed names is safe
    // for the builder to consume unconditionally.
    const runes = adaptRunesForArmor(extractRunes(raw?.name ?? ""));
    return {
      arAC:             raw.arAC ?? null,
      arItemAC:         raw.arItemAC ?? null,
      arDexModCap:      raw.arDexModCap ?? null,
      proLevelBonNet:   raw.proLevelBonNet ?? null,
      grBulk:           raw.grBulk ?? null,
      profLevel:        raw.ProfLevel ?? null,
      // baseName feeds matcher-slug-table.slugCandidates as an
      // additional candidate. If the strip succeeds we get a
      // canonical base-armor slug like "breastplate" or
      // "chain-shirt"; if not we just emit null and the matcher
      // works with the display-name slug.
      baseName,
      runes,
    };
  },
};

export default { id: "parser-compset-customarmor" };
