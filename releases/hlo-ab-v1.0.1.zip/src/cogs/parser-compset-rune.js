// ============================================================
// COG: parser-compset-rune.js - Rune normalizer (apply-to-parent)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.1.0
//           - v0.7.1: new cog for HLO's Rune compset. HLO emits
//             every weapon and armor rune as a standalone nested
//             item under the parent weapon/armor (containment
//             "Installed"). Until now those 49 Rune items across
//             the five test characters fell through as "Unknown
//             compset" warnings and the rune data they carried
//             was lost. Berial Jeggare PFS surfaced the worst
//             case: his Numerian Steel Breastplate ships with
//             three nested runes (ruArmPotency1, ruArmResilient,
//             ruArmResistFire). The breastplate's name is just
//             "Numerian Steel Breastplate" with zero rune data
//             baked in, so util-rune-parser cannot recover
//             ruArmResistFire from the name. That rune was
//             silently dropped in v0.7.0.
//
//             The handler does NOT route to a compendium pack
//             (Foundry stores runes ON the parent weapon/armor's
//             system.runes, not as standalone items). Instead it
//             emits an `_runeApplyTo` discriminator that the
//             builder layer consumes to merge the rune into the
//             parent's runes envelope. The Rune item itself is
//             dropped from the actor's embedded-item list (see
//             STAT_BEARING_COMPSETS in builder-actor-pf2e.js).
//
//             Schema of the emitted patch:
//               _runeApplyTo: {
//                 target:    "weapon" | "armor",
//                 runeType:  "potency" | "striking" |
//                            "resilient" | "property",
//                 runeName:  string?,  // canonical PF2e slug
//                                      // ("ghost-touch", "wounding",
//                                      // "fire-resistant"); null for
//                                      // potency/striking/resilient
//                 runeValue: number?,  // numeric tier for potency
//                                      // (+1/+2/+3), striking (1/2/3)
//                                      // and resilient (1/2/3); null
//                                      // for property runes
//               }
//
//             Target detection (from the HLO id prefix on slug):
//               ruWep*   -> "weapon"
//               ruArm*   -> "armor"
//               ruShld*  -> "armor"  (shields are armor in PF2e)
//
//             The slug-to-runeType/runeName mapping is data-driven
//             (RUNE_SLUG_TABLE below); unknown slugs are warned but
//             still pass the target through so the builder at least
//             knows which item the orphaned rune belongs to.
//
//             Coordinates with the IR-shape work on the parent
//             weapon: the parent already carries `runes` from
//             parser-compset-weapons.js (potency, striking,
//             propertyRunes[], baseName, matchedRunes). The builder
//             post-processing pass merges this handler's patches into
//             that same envelope (max() for potency/striking, push
//             for propertyRunes, separate resilient field for armor).

import { RUNE_KEYWORDS } from "./util-rune-parser.js";

/**
 * Lookup table for HLO rune slug -> { runeType, runeName, runeValue }.
 *
 * The keys are the HLO id prefix-stripped slug (the part after
 * "ruWep", "ruArm", or "ruShld"). For potency and striking, runeValue
 * is the tier number. For property runes, runeName is the canonical
 * PF2e Foundry propertyRunes[] slug.
 *
 * Coverage targets the runes that appear in the v0.7.0 test corpus
 * (Berial Jeggare PFS, Bhelroth EC, Revascis Virholt) plus the
 * common PF2e Core/Player Core runes. Add new entries here without
 * touching builder code: the post-processing pass is data-driven.
 *
 * Some slugs are shared between weapon and armor families (the HLO
 * id distinguishes via the ruWep / ruArm / ruShld prefix); the
 * lookup is by suffix only, since the type/name/value mapping is
 * independent of the target.
 */
export const RUNE_SLUG_TABLE = {
  // Potency tiers (weapon + armor share the suffix).
  "Potency1":      { runeType: "potency",  runeValue: 1, runeName: null },
  "Potency2":      { runeType: "potency",  runeValue: 2, runeName: null },
  "Potency3":      { runeType: "potency",  runeValue: 3, runeName: null },
  // Striking tiers (weapon-only; HLO does not ship striking-Mj for
  // armor since "resilient" is the armor analog).
  "Striking":      { runeType: "striking", runeValue: 1, runeName: null },
  "StrikingGr":    { runeType: "striking", runeValue: 2, runeName: null },
  "StrikingMj":    { runeType: "striking", runeValue: 3, runeName: null },
  // Resilient tiers (armor-only).
  "Resilient":     { runeType: "resilient", runeValue: 1, runeName: null },
  "ResilientGr":   { runeType: "resilient", runeValue: 2, runeName: null },
  "ResilientMj":   { runeType: "resilient", runeValue: 3, runeName: null },
  // Also covers HLO's numeric-suffix variant for resilient.
  "Resilient2":    { runeType: "resilient", runeValue: 2, runeName: null },
  "Resilient3":    { runeType: "resilient", runeValue: 3, runeName: null },

  // Weapon property runes. Slugs are PF2e Foundry camelCase form per
  // RUNE_DATA in pf2e.mjs (also see util-rune-parser.js PROPERTY_SLUG).
  // The matched-runes slugs MUST agree with util-rune-parser's so the
  // dedupe in applyRunePatch works when both name-extraction (used by
  // weapons and magic items) and standalone-rune extraction (Rune
  // compset) emit the same property rune.
  "Anarchic":      { runeType: "property", runeValue: null, runeName: "anarchic" },
  "Animated":      { runeType: "property", runeValue: null, runeName: "animated" },
  "Axiomatic":     { runeType: "property", runeValue: null, runeName: "axiomatic" },
  "Corrosive":     { runeType: "property", runeValue: null, runeName: "corrosive" },
  "Disrupting":    { runeType: "property", runeValue: null, runeName: "disrupting" },
  "Fearsome":      { runeType: "property", runeValue: null, runeName: "fearsome" },
  "Flaming":       { runeType: "property", runeValue: null, runeName: "flaming" },
  "Frost":         { runeType: "property", runeValue: null, runeName: "frost" },
  "GhostTouch":    { runeType: "property", runeValue: null, runeName: "ghostTouch" },
  "Grievous":      { runeType: "property", runeValue: null, runeName: "grievous" },
  "Holy":          { runeType: "property", runeValue: null, runeName: "holy" },
  "Impactful":     { runeType: "property", runeValue: null, runeName: "impactful" },
  "Keen":          { runeType: "property", runeValue: null, runeName: "keen" },
  "Returning":     { runeType: "property", runeValue: null, runeName: "returning" },
  "Shock":         { runeType: "property", runeValue: null, runeName: "shock" },
  "Speed":         { runeType: "property", runeValue: null, runeName: "speed" },
  "SpellStoring":  { runeType: "property", runeValue: null, runeName: "spellStoring" },
  "Thundering":    { runeType: "property", runeValue: null, runeName: "thundering" },
  "UndeadBane":    { runeType: "property", runeValue: null, runeName: "undead-bane" },
  "Unholy":        { runeType: "property", runeValue: null, runeName: "unholy" },
  "Vitalizing":    { runeType: "property", runeValue: null, runeName: "vitalizing" },
  "Vorpal":        { runeType: "property", runeValue: null, runeName: "vorpal" },
  "Wounding":      { runeType: "property", runeValue: null, runeName: "wounding" },

  // Armor property runes (energy-resistant family + utility).
  // PF2e uses camelCase: fireResistant, greaterReady, etc.
  "ResistAcid":    { runeType: "property", runeValue: null, runeName: "acidResistant" },
  "ResistCold":    { runeType: "property", runeValue: null, runeName: "coldResistant" },
  "ResistElec":    { runeType: "property", runeValue: null, runeName: "electricityResistant" },
  "ResistFire":    { runeType: "property", runeValue: null, runeName: "fireResistant" },
  "ResistSonic":   { runeType: "property", runeValue: null, runeName: "sonicResistant" },
  "Ready":         { runeType: "property", runeValue: null, runeName: "ready" },
  "ReadyGr":       { runeType: "property", runeValue: null, runeName: "greaterReady" },
  "Winged":        { runeType: "property", runeValue: null, runeName: "winged" },
  "WingedGr":      { runeType: "property", runeValue: null, runeName: "greaterWinged" },
  "Slick":         { runeType: "property", runeValue: null, runeName: "slick" },
  "SlickGr":       { runeType: "property", runeValue: null, runeName: "greaterSlick" },
  "SlickMj":       { runeType: "property", runeValue: null, runeName: "majorSlick" },
  "Shadow":        { runeType: "property", runeValue: null, runeName: "shadow" },
  "ShadowGr":      { runeType: "property", runeValue: null, runeName: "greaterShadow" },
  "ShadowMj":      { runeType: "property", runeValue: null, runeName: "majorShadow" },
  "Invisibility":  { runeType: "property", runeValue: null, runeName: "invisibility" },
  "InvisibilityGr": { runeType: "property", runeValue: null, runeName: "greaterInvisibility" },
  "Advancing":     { runeType: "property", runeValue: null, runeName: "advancing" },

  // Shield property runes (rare in test corpus; coverage scaffolded).
  "Reinforc":      { runeType: "property", runeValue: null, runeName: "reinforcing" },
  "ReinforcGr":    { runeType: "property", runeValue: null, runeName: "greaterReinforcing" },
};

/**
 * Detect the target item type (weapon or armor) from an HLO rune
 * slug. ruWep* runes apply to weapons, ruArm* to armor, ruShld* to
 * shields (which PF2e/SF2e model as a flavor of armor). Returns null
 * if the slug does not match any known prefix.
 *
 * Note: the HLO slug arrives with its sequence stripped (parser-
 * items.js does the split on "." before normalize() is called). The
 * raw id retains the full prefix.
 */
export function targetForRuneSlug(slug) {
  if (!slug || typeof slug !== "string") return null;
  if (slug.startsWith("ruWep")) return "weapon";
  if (slug.startsWith("ruArm")) return "armor";
  if (slug.startsWith("ruShld")) return "armor";
  return null;
}

/**
 * Extract the rune-name suffix from an HLO slug. Returns the part
 * after the family prefix (ruWep / ruArm / ruShld) so the result can
 * be looked up in RUNE_SLUG_TABLE. Examples:
 *   "ruWepGhostTouch" -> "GhostTouch"
 *   "ruArmResistFire" -> "ResistFire"
 *   "ruShldReinforcGr" -> "ReinforcGr"
 */
export function suffixForRuneSlug(slug) {
  if (!slug || typeof slug !== "string") return null;
  if (slug.startsWith("ruWep")) return slug.slice("ruWep".length);
  if (slug.startsWith("ruArm")) return slug.slice("ruArm".length);
  if (slug.startsWith("ruShld")) return slug.slice("ruShld".length);
  return null;
}

export const Rune = {
  normalize(raw, warnings) {
    // parser-items.js (v0.2.0) injects the slug onto raw as `_slug`
    // before dispatching so handlers can classify by HLO id prefix
    // without changing the normalize() signature. The slug is the
    // most reliable target signal because HLO ids are stable while
    // display names are localized ("Energy-resistant, fire" vs the
    // slug ruArmResistFire). When the slug is unavailable (older
    // call sites, future tests with synthetic raw objects), the
    // name-based classifier (classifyByName below) covers the same
    // ground from HLO's canonical display-name conventions.
    const slugHint = raw?._slug ?? null;
    const name = raw?.name ?? "";

    // Prefer the slug-derived classification; fall back to name parse.
    let target = targetForRuneSlug(slugHint);
    let suffix = suffixForRuneSlug(slugHint);
    let entry = suffix ? RUNE_SLUG_TABLE[suffix] : null;

    if (!entry) {
      const fromName = classifyByName(name);
      if (fromName) {
        target = target ?? fromName.target;
        entry = {
          runeType:  fromName.runeType,
          runeValue: fromName.runeValue ?? null,
          runeName:  fromName.runeName ?? null,
        };
      }
    }

    if (!entry || !target) {
      if (Array.isArray(warnings)) {
        warnings.push({
          code: "unknown-rune",
          message: `Unrecognized Rune item "${name}" (slug hint: ${slugHint ?? "none"}). Foundry rune data not applied.`,
          context: { name, slugHint },
        });
      }
      return {};
    }

    return {
      _runeApplyTo: {
        target,
        runeType:  entry.runeType,
        runeName:  entry.runeName ?? null,
        runeValue: entry.runeValue ?? null,
      },
    };
  },
};

/**
 * Name-based fallback classifier. Used when the slug context is not
 * available to the normalizer (the parser-items dispatcher gives the
 * handler raw + warnings; the slug lives on the outer item record).
 * Walks a few heuristics in order:
 *   1. "Weapon potency +N" / "Armor potency +N" -> potency tier.
 *   2. "Striking[, greater|major]" -> striking tier (weapon).
 *   3. "Resilient[, greater|major]" -> resilient tier (armor).
 *   4. Property-rune keyword match against RUNE_KEYWORDS.property.
 *   5. Energy-resistant variants ("Energy-resistant, fire" etc.) ->
 *      "<element>-resistant" property rune on armor.
 *
 * Returns { target, runeType, runeValue?, runeName? } or null.
 */
export function classifyByName(name) {
  if (!name || typeof name !== "string") return null;
  const lower = name.toLowerCase().trim();

  // 1. Potency. HLO ships "Weapon potency +1" and "Armor potency +1".
  const potMatch = lower.match(/^(weapon|armor|shield)\s+potency\s+\+?(\d)/);
  if (potMatch) {
    const target = potMatch[1] === "weapon" ? "weapon" : "armor";
    const value = Math.min(parseInt(potMatch[2], 10), 3);
    return { target, runeType: "potency", runeValue: value };
  }

  // 2. Striking tiers.
  if (/^striking(\s*,\s*(greater|major))?$/.test(lower)) {
    let value = 1;
    if (/greater/.test(lower)) value = 2;
    else if (/major/.test(lower)) value = 3;
    return { target: "weapon", runeType: "striking", runeValue: value };
  }

  // 3. Resilient tiers (armor-only).
  if (/^resilient(\s*,\s*(greater|major))?$/.test(lower)) {
    let value = 1;
    if (/greater/.test(lower)) value = 2;
    else if (/major/.test(lower)) value = 3;
    return { target: "armor", runeType: "resilient", runeValue: value };
  }

  // 4. Energy-resistant family ("Energy-resistant, fire" / "...,
  // greater fire"). HLO singular nouns: acid, cold, electricity,
  // fire, sonic. Greater variants prefix with "greater". PF2e Foundry
  // uses camelCase slugs (fireResistant, greaterFireResistant) per
  // RUNE_DATA in pf2e.mjs.
  const energyMatch = lower.match(/^energy[-\s]resistant\s*,\s*(greater\s+)?(acid|cold|electricity|fire|sonic)/);
  if (energyMatch) {
    const element = energyMatch[2];
    const base = `${element}Resistant`;
    return {
      target: "armor",
      runeType: "property",
      runeName: energyMatch[1] ? `greater${base.charAt(0).toUpperCase()}${base.slice(1)}` : base,
    };
  }

  // 5. Single-word property-rune keyword. Walk RUNE_KEYWORDS.property
  // (the canonical phrase list shared with util-rune-parser) and emit
  // the camelCase slug PF2e Foundry uses on system.runes.property[].
  // Two-word phrases ("ghost touch") become camelCase ("ghostTouch");
  // single-word ones pass through lowercased.
  for (const phrase of RUNE_KEYWORDS.property) {
    if (lower === phrase || lower.startsWith(`${phrase} `)
        || lower.startsWith(`${phrase},`)) {
      const slug = phraseToCamelSlug(phrase);
      // Property runes can land on either weapon or armor; assume
      // weapon as the default and let the builder's parent-target
      // override us if the parent is armor (the apply-to-parent merge
      // already has the parent's compset in hand).
      return { target: "weapon", runeType: "property", runeName: slug };
    }
  }

  // 6. "Ready, greater" / "Ready" / "Winged" / shield-only families.
  if (/^ready(\s*,\s*greater)?$/.test(lower)) {
    const greater = /greater/.test(lower);
    return {
      target: "armor",
      runeType: "property",
      runeName: greater ? "greaterReady" : "ready",
    };
  }
  if (/^winged(\s*,\s*greater)?$/.test(lower)) {
    const greater = /greater/.test(lower);
    return {
      target: "armor",
      runeType: "property",
      runeName: greater ? "greaterWinged" : "winged",
    };
  }
  if (/^reinforcing(\s*,\s*greater)?$/.test(lower)) {
    const greater = /greater/.test(lower);
    return {
      target: "armor",
      runeType: "property",
      runeName: greater ? "greaterReinforcing" : "reinforcing",
    };
  }

  return null;
}

/**
 * Helper: convert a phrase like "ghost touch" or "spell storing" to
 * the PF2e Foundry camelCase slug ("ghostTouch", "spellStoring"). For
 * single-word inputs, returns the lowercased phrase unchanged. Used
 * by classifyByName when the energy-resistant / Ready / Winged
 * branches do not apply.
 */
function phraseToCamelSlug(phrase) {
  if (!phrase) return "";
  const parts = phrase.toLowerCase().split(/[\s-]+/).filter(Boolean);
  if (parts.length === 0) return "";
  return parts[0] + parts.slice(1).map(
    (p) => p.charAt(0).toUpperCase() + p.slice(1),
  ).join("");
}

export default { id: "parser-compset-rune" };
