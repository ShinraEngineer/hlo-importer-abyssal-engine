// ============================================================
// COG: util-rune-parser.js - PF2e/SF2e rune-prefix extractor
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.2.0
//           - v0.7.1 Rune Triad (a review pass). Extended the parser to
//             cover armor-side fundamental and property runes so the
//             v0.7.1 Armor and CustomArmor extractRunes wiring can
//             carry the same shape the weapon handler already uses.
//             Added resilient tiers ("resilient", "greater
//             resilient", "major resilient") to RUNE_KEYWORDS so the
//             striking field can also represent armor fundamentals
//             (1=resilient, 2=greater resilient, 3=major resilient);
//             the field name "striking" stays on the IR because that
//             is what the weapon handler emits and what the builder
//             consumes, and the builder maps it to system.runes.
//             resilient on armor items. Added the armor property
//             runes HLO actually ships on the curated test corpus:
//             "fire resistant" / "cold resistant" / "acid resistant"
//             / "electricity resistant" / "sonic resistant" /
//             "force resistant" (energy-resistant family),
//             "winged", "greater winged", "ready", "greater ready",
//             "advancing", "shadow", "greater shadow", "major
//             shadow", "slick", "greater slick", "major slick",
//             "invisibility", "greater invisibility". These were
//             previously dropped by the loop, so Bhelroth's "+3
//             greater resilient fire resistant winged greater ready
//             full plate" stopped at the +3 and left "greater
//             resilient fire resistant ..." in the base name. The
//             property-rune slug map was extended for every phrase
//             whose canonical Foundry slug is not just the phrase
//             with spaces replaced by hyphens.
//           - 0.1.0: New cog. HLO emits weapons and certain MagicItem
//             entries with the runes baked into the display name
//             ("+1 striking wounding bastard sword", "+1 striking
//             ghost touch handwraps of mighty blows"). PF2e and
//             SF2e Foundry store runes on system.runes (potency,
//             striking, property[]) and resolve the rest of the
//             slug to the bare base item ("bastard-sword",
//             "handwraps-of-mighty-blows"). Without an extractor
//             the matcher fed the full prefixed name into the
//             slugifier and the resulting base item came back
//             with runes.potency=0 / runes.striking=0 / property=[]
//             (verified 2026-05-16 against Berial Jeggare's
//             imported actor: bastard sword landed at potency 0).
//
//             extractRunes(name) returns:
//               {
//                 potency: 0|1|2|3,
//                 striking: 0|1|2|3,            // 1 = striking, 2 = greater, 3 = major
//                 propertyRunes: Array<string>, // canonical Foundry slugs
//                 baseName: string,             // name with all rune words removed
//                 matchedRunes: Array<string>,  // canonical names of runes that
//                                               // were stripped, for warnings/audit
//               }
//
//             Property-rune coverage targets the runes HLO actually
//             ships on weapons in the curated test corpus plus the
//             common PF2e Core/Player Core fundamentals: ghost touch,
//             wounding, frost, shock, flaming, vorpal, holy, anarchic,
//             axiomatic, disrupting, returning, grievous, fearsome,
//             undead-bane, unholy. Additional runes can be added to
//             RUNE_KEYWORDS without code changes.
//
//             The parser is conservative: it only strips a leading
//             "+N" or rune keyword if the keyword is one of the
//             recognized ones. Anything else stays in baseName.
//             Two-word rune phrases ("ghost touch", "greater
//             striking", "major striking", "undead bane",
//             "spell-storing") are matched before single-word
//             variants so the longest match wins.

/**
 * Canonical rune keyword table. The order within each section is the
 * order they are scanned, and longest phrases are listed first so
 * "greater striking" is matched before "striking" and "ghost touch"
 * is matched before stray words. Values are the canonical PF2e Foundry
 * propertyRune slugs (lowercase, hyphenated) the matcher will write
 * back onto system.runes.property[].
 *
 * Striking and potency are handled separately as numeric fields, not
 * as property runes; they are listed here for completeness so the
 * parser knows to strip the words even when they appear standalone.
 */
export const RUNE_KEYWORDS = {
  // Fundamental "striking" runes for weapons (longest first) and the
  // armor-side "resilient" family that occupies the same numeric tier
  // slot on the IR. Both are stored under `striking` in the extractor
  // output; the builder maps that field to system.runes.striking on
  // weapons and system.runes.resilient on armor. We do not differentiate
  // here because HLO's display-name grammar guarantees only one of the
  // two ever appears in a single name (weapons get "striking", armor
  // gets "resilient").
  striking: [
    { phrase: "major striking",     tier: 3 },
    { phrase: "greater striking",   tier: 2 },
    { phrase: "striking",           tier: 1 },
    { phrase: "major resilient",    tier: 3 },
    { phrase: "greater resilient",  tier: 2 },
    { phrase: "resilient",          tier: 1 },
  ],
  // Property runes. Two-word phrases must come before any single-word
  // variant that shares a leading word. Order matters: "greater shadow"
  // before "shadow", "fire resistant" before "fire", and so on.
  property: [
    // Weapon-side runes (v0.7.0 baseline).
    "ghost touch",
    "undead bane",
    "spell storing",
    "spell-storing",
    "wounding",
    "frost",
    "shock",
    "flaming",
    "vorpal",
    "holy",
    "anarchic",
    "axiomatic",
    "disrupting",
    "returning",
    "grievous",
    "fearsome",
    "unholy",
    "thundering",
    "corrosive",
    "keen",
    "speed",
    // Armor-side runes (v0.7.1 extension). Two-word phrases first so
    // "greater ready" beats stray "ready" and the energy-resistant
    // family is detected as a single phrase.
    "greater shadow",
    "major shadow",
    "greater slick",
    "major slick",
    "greater winged",
    "greater ready",
    "greater invisibility",
    "fire resistant",
    "cold resistant",
    "acid resistant",
    "electricity resistant",
    "sonic resistant",
    "force resistant",
    "winged",
    "ready",
    "shadow",
    "slick",
    "advancing",
    "invisibility",
  ],
};

// Map of phrase as written in the input to the canonical Foundry
// propertyRune slug. PF2e uses camelCase slugs for property runes
// (ghostTouch, spellStoring, fireResistant, greaterReady), per
// data/.../systems/pf2e/pf2e.mjs RUNE_DATA.weapon.property /
// RUNE_DATA.armor.property. The v0.7.1 rune triad switched from the
// initial v0.7.0 kebab-case guess ("ghost-touch") to the canonical
// PF2e form so the runes written to system.runes.property[] are
// actually recognized by the rule-element pipeline. Any entry not
// listed here falls through to a generic phrase-to-camelCase
// conversion, but the explicit map below covers every rune the
// parser currently knows about, so the fallback is just a safety
// net for runes added to RUNE_KEYWORDS without a matching slug.
const PROPERTY_SLUG = {
  // Weapon-side runes.
  "ghost touch":           "ghostTouch",
  "undead bane":           "undead-bane",
  "spell storing":         "spellStoring",
  "spell-storing":         "spellStoring",
  "wounding":              "wounding",
  "frost":                 "frost",
  "shock":                 "shock",
  "flaming":               "flaming",
  "vorpal":                "vorpal",
  "holy":                  "holy",
  "anarchic":              "anarchic",
  "axiomatic":             "axiomatic",
  "disrupting":            "disrupting",
  "returning":             "returning",
  "grievous":              "grievous",
  "fearsome":              "fearsome",
  "unholy":                "unholy",
  "thundering":            "thundering",
  "corrosive":             "corrosive",
  "keen":                  "keen",
  "speed":                 "speed",
  // Armor-side runes (v0.7.1).
  "fire resistant":        "fireResistant",
  "cold resistant":        "coldResistant",
  "acid resistant":        "acidResistant",
  "electricity resistant": "electricityResistant",
  "sonic resistant":       "sonicResistant",
  "force resistant":       "forceResistant",
  "winged":                "winged",
  "greater winged":        "greaterWinged",
  "ready":                 "ready",
  "greater ready":         "greaterReady",
  "shadow":                "shadow",
  "greater shadow":        "greaterShadow",
  "major shadow":          "majorShadow",
  "slick":                 "slick",
  "greater slick":         "greaterSlick",
  "major slick":           "majorSlick",
  "advancing":             "advancing",
  "invisibility":          "invisibility",
  "greater invisibility":  "greaterInvisibility",
};

/**
 * Fallback phrase-to-slug for any rune in RUNE_KEYWORDS.property that has
 * no explicit entry in PROPERTY_SLUG. Converts "two word phrase" to
 * "twoWordPhrase" (camelCase). Single-word phrases pass through. The
 * function is defensive: an empty string returns an empty string.
 */
function phraseToCamelSlug(phrase) {
  if (!phrase) return "";
  const parts = phrase.toLowerCase().split(/[\s-]+/).filter(Boolean);
  if (parts.length === 0) return "";
  return parts[0] + parts.slice(1).map(
    (p) => p.charAt(0).toUpperCase() + p.slice(1),
  ).join("");
}

/**
 * Extract PF2e/SF2e rune prefixes from a display name.
 *
 * Examples:
 *   extractRunes("+1 striking wounding bastard sword")
 *     -> { potency: 1, striking: 1, propertyRunes: ["wounding"],
 *          baseName: "bastard sword",
 *          matchedRunes: ["+1", "striking", "wounding"] }
 *
 *   extractRunes("+1 striking ghost touch handwraps of mighty blows")
 *     -> { potency: 1, striking: 1, propertyRunes: ["ghostTouch"],
 *          baseName: "handwraps of mighty blows",
 *          matchedRunes: ["+1", "striking", "ghostTouch"] }
 *
 *   extractRunes("+3 greater resilient fire resistant winged greater ready full plate")
 *     -> { potency: 3, striking: 2,
 *          propertyRunes: ["fireResistant", "winged", "greaterReady"],
 *          baseName: "full plate",
 *          matchedRunes: ["+3", "greater-resilient", "fireResistant",
 *                         "winged", "greaterReady"] }
 *
 *   extractRunes("bastard sword")
 *     -> { potency: 0, striking: 0, propertyRunes: [],
 *          baseName: "bastard sword", matchedRunes: [] }
 *
 * Note: the `striking` field carries both weapon striking tiers and
 * armor resilient tiers (0/1/2/3). The builder reads this field as
 * system.runes.striking on weapons and system.runes.resilient on
 * armor.
 *
 * @param {string} name  Display name, possibly with leading runes.
 * @returns {{
 *   potency: 0|1|2|3,
 *   striking: 0|1|2|3,
 *   propertyRunes: Array<string>,
 *   baseName: string,
 *   matchedRunes: Array<string>,
 * }}
 */
export function extractRunes(name) {
  const empty = {
    potency: 0,
    striking: 0,
    propertyRunes: [],
    baseName: typeof name === "string" ? name : "",
    matchedRunes: [],
  };
  if (!name || typeof name !== "string") return empty;

  let remainder = name.trim();
  let potency = 0;
  let striking = 0;
  const propertyRunes = [];
  const matchedRunes = [];

  // 1. Leading "+N" potency. Only +1, +2, +3 are valid in PF2e/SF2e;
  // higher values are clamped at 3 to stay within the Foundry schema.
  const potencyMatch = remainder.match(/^\+([0-9])\s+/);
  if (potencyMatch) {
    potency = Math.min(parseInt(potencyMatch[1], 10), 3);
    matchedRunes.push(`+${potency}`);
    remainder = remainder.slice(potencyMatch[0].length).trimStart();
  }

  // 2. Strip leading rune keywords in a loop. Each pass tries striking
  // tiers and property phrases (longest first) and strips the first
  // match it finds; if nothing matches, we stop and treat the rest
  // as the base name.
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const stripped = tryStripLeadingRune(remainder, propertyRunes, matchedRunes,
      (tier) => { striking = Math.max(striking, tier); });
    if (stripped == null) break;
    remainder = stripped;
  }

  return {
    potency,
    striking,
    propertyRunes,
    baseName: remainder.trim(),
    matchedRunes,
  };
}

/**
 * Try to strip a single leading rune keyword from the input. On a hit,
 * appends the property rune slug (when applicable) and the canonical
 * matched-rune label, calls onStriking(tier) for striking matches, and
 * returns the remainder. On a miss returns null.
 */
function tryStripLeadingRune(input, propertyRunes, matchedRunes, onStriking) {
  const lower = input.toLowerCase();

  // Striking tiers first (longest phrase wins).
  for (const { phrase, tier } of RUNE_KEYWORDS.striking) {
    if (startsWithWord(lower, phrase)) {
      onStriking(tier);
      matchedRunes.push(phrase.replace(/\s+/g, "-"));
      return input.slice(phrase.length).trimStart();
    }
  }

  // Property runes.
  for (const phrase of RUNE_KEYWORDS.property) {
    if (startsWithWord(lower, phrase)) {
      const slug = PROPERTY_SLUG[phrase] ?? phraseToCamelSlug(phrase);
      if (!propertyRunes.includes(slug)) propertyRunes.push(slug);
      matchedRunes.push(slug);
      return input.slice(phrase.length).trimStart();
    }
  }

  return null;
}

/**
 * True if `haystack` starts with `needle` followed by a word boundary
 * (whitespace or end of string). Prevents "shock" from matching the
 * start of "shocker" or "frost" matching "frostbite". Case-folded
 * comparison is the caller's responsibility (we expect lowercase
 * inputs here).
 */
function startsWithWord(haystack, needle) {
  if (!haystack.startsWith(needle)) return false;
  const after = haystack[needle.length];
  return after === undefined || /\s/.test(after);
}

export default { id: "util-rune-parser" };
