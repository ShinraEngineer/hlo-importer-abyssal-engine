// ============================================================
// COG: api-hlo-client.js - HLO Public API client
//                          (acquire-access-token + character/get)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.4.0
//           - Wave 4 of the cog migration. Promoted from
//             src/api/hlo-client.js. Internal import still
//             points at ../util/version.js; that gets relocated
//             to a sibling cog in Wave 6.
//           - 0.3.0: Fix infinite-poll bug. Previous logic
//             treated any non-zero status as "still preparing"
//             and re-polled until the cap. Empirically HLO
//             returns status=2 with the export payload populated
//             on the very first response (status=2 means "data
//             updated"; status=0 means "unchanged since last
//             baseline"). The presence of a populated
//             `export.actors` record is the real success signal,
//             not status=0. Reworked the loop to return as soon
//             as that arrives.
//           - 0.1.0: Phase 4 (in src/api/). HLO Public API
//             client. Two endpoints are wired:
//               POST /v1/access/acquire-access-token
//               POST /v1/character/get
//             plus a small fetch wrapper that handles the
//             `wait`/poll cycle, rate-limit recognition, and
//             CORS-vs-HTTP-error distinction.
//
// Notes:
//   - The tool name passed to acquire-access-token MUST be stable across
//     versions. The HLO docs are explicit that adding version numbers to
//     the tool name causes LWD to treat it as a separate tool.
//   - Polling is actively discouraged for live updates; the proper pattern
//     for "watch this character" is SignalR subscriptions (Phase 7). For
//     one-shot fetch the polling is bounded and idiomatic.

import { HLO_API_BASE, HLO_TOOL_NAME } from "./util-version.js";

const ACQUIRE_TOKEN_PATH    = "/v1/access/acquire-access-token";
const GET_CHARACTER_PATH    = "/v1/character/get";
const MAX_POLL_ITERATIONS   = 5;      // safety cap (~7.5s at default wait)
const DEFAULT_WAIT_MS       = 1500;

export class HLOApiError extends Error {
  constructor(message, { kind, status, body, cause } = {}) {
    super(message);
    this.name = "HLOApiError";
    this.kind = kind ?? "unknown";   // "http" | "cors" | "rate-limit" | "shape" | "timeout"
    this.status = status ?? null;
    this.body = body ?? null;
    if (cause) this.cause = cause;
  }
}

/**
 * Exchange a user JWT (refresh token) for a short-lived access token.
 * @param {string} userToken HLO External Integration User Token (JWT).
 * @returns {Promise<string>} The access token.
 */
export async function acquireAccessToken(userToken) {
  if (!userToken) throw new Error("acquireAccessToken: userToken is required.");
  const body = {
    refreshToken: userToken,
    toolName: HLO_TOOL_NAME,
    lifespan: 0,
  };
  const data = await postJson(`${HLO_API_BASE}${ACQUIRE_TOKEN_PATH}`, body);
  if (!data?.accessToken) {
    throw new HLOApiError("acquire-access-token: response missing accessToken.", {
      kind: "shape", body: data,
    });
  }
  return data.accessToken;
}

/**
 * Fetch a character export by element token. Handles the polling cycle so
 * the caller sees a single promise that resolves to the export JSON.
 *
 * @param {string} accessToken
 * @param {string} elementToken
 * @param {object} [options]
 * @param {number} [options.actor]    Actor index (default null per HLO docs).
 * @param {number} [options.baseline] Baseline (default 0).
 * @param {(iteration: number, data: object) => void} [options.onPoll]
 *   Optional callback fired after every response, with the 1-based
 *   iteration number and the parsed JSON. Used by the dialog to push
 *   per-poll debug entries so the user sees what HLO returns during
 *   the wait/retry cycle.
 * @returns {Promise<object>} The character export (the same shape the manual paste path consumes).
 */
export async function getCharacter(accessToken, elementToken, options = {}) {
  if (!accessToken)  throw new Error("getCharacter: accessToken is required.");
  if (!elementToken) throw new Error("getCharacter: elementToken is required.");
  // HLO docs (Public API section 4.2) say `actor` defaults to null and
  // `baseline` defaults to 0. Sending actor: 0 looked harmless but may be
  // interpreted as an explicit (non-existent) actor index by some HLO
  // server versions; null is the documented "give me the primary" value.
  const body = {
    accessToken,
    elementToken,
    actor:    options.actor    ?? null,
    baseline: options.baseline ?? 0,
  };
  const onPoll = typeof options.onPoll === "function" ? options.onPoll : null;
  let attempt = 0;
  while (attempt < MAX_POLL_ITERATIONS) {
    attempt += 1;
    const data = await postJson(`${HLO_API_BASE}${GET_CHARACTER_PATH}`, body);
    if (onPoll) {
      try { onPoll(attempt, data); } catch { /* swallow logging errors */ }
    }
    const waitMs = typeof data?.wait === "number" ? data.wait : DEFAULT_WAIT_MS;
    const resultCode = data?.result;
    const resultLabel = describeResultCode(resultCode);

    // Detect a known error result code (any non-zero numeric or any
    // non-Success string) before falling through to the shape check.
    if (resultLabel && resultLabel !== "Success") {
      throw new HLOApiError(
        `HLO character/get returned result=${JSON.stringify(resultCode)} (${resultLabel}). ` +
        `severity=${JSON.stringify(data?.severity)}. ` +
        `response keys: [${Object.keys(data ?? {}).join(", ")}].`,
        { kind: /Throttled|Lockout/i.test(resultLabel) ? "rate-limit" : "shape", body: data },
      );
    }

    // HLO Public API status semantics (verified empirically, doc was
    // misleading): status=0 means "no change since baseline" (export
    // omitted), status=2 means "export updated and present", any other
    // non-zero value means HLO is still preparing. The reliable success
    // signal is a populated export.actors record; trust the payload.
    if (data?.export && data.export.actors && Object.keys(data.export.actors).length > 0) {
      return data.export;
    }
    if (typeof data?.status === "number" && data.status !== 0) {
      await sleep(Math.max(waitMs, DEFAULT_WAIT_MS));
      continue;
    }
    // status=0 with no export means "you already have the latest" which
    // for a first fetch is a server-side bug; surface the shape either
    // way so the user can paste it back for debugging.
    const keys = Object.keys(data ?? {});
    const preview = keys.length
      ? `keys=[${keys.join(", ")}], result=${JSON.stringify(resultCode)}, severity=${JSON.stringify(data?.severity)}, status=${JSON.stringify(data?.status)}, wait=${JSON.stringify(data?.wait)}`
      : "(empty body)";
    throw new HLOApiError(
      `character/get: response missing export payload. ${preview}.`,
      { kind: "shape", body: data },
    );
  }
  throw new HLOApiError(`character/get: did not complete in ${MAX_POLL_ITERATIONS} polls.`, {
    kind: "timeout",
  });
}

// HLO Public API result codes from section 4.4 of the project docs.
// Returns a human-readable label for known codes, the raw value as a
// string for unknown integers, or null for missing/zero result fields
// (which mean success or no error info, both of which fall through to
// the shape check).
function describeResultCode(code) {
  if (code == null) return null;
  if (typeof code === "string") {
    if (/^success$/i.test(code) || code === "0") return "Success";
    return code;
  }
  if (typeof code !== "number") return String(code);
  if (code === 0) return null; // success path; let shape check handle the rest
  switch (code) {
    case 7000: return "Api_Unchanged";
    case 7100: return "Api_Bad_Api_Token";
    case 7110: return "Api_Bad_Element_Token";
    case 7800: return "Api_Caller_Throttled";
    case 7805: return "Api_Caller_Lockout_Tier";
    case 7900: return "Api_Not_Enabled";
    default:   return `Unknown_${code}`;
  }
}

/**
 * POST a JSON body and return the parsed JSON response. Distinguishes CORS
 * failures (TypeError on fetch with empty response) from HTTP errors.
 */
async function postJson(url, body) {
  let res;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(body),
      mode: "cors",
      credentials: "omit",
    });
  } catch (err) {
    // Browser-side fetch surfaces CORS rejection as a TypeError with no body.
    throw new HLOApiError(
      `Network or CORS failure contacting ${url}. If you see this inside Foundry, confirm browser console for a CORS message.`,
      { kind: "cors", cause: err },
    );
  }
  let data = null;
  try {
    data = await res.json();
  } catch (err) {
    if (!res.ok) {
      throw new HLOApiError(`HTTP ${res.status} from ${url} with non-JSON body.`, {
        kind: "http", status: res.status, cause: err,
      });
    }
    throw new HLOApiError(`Non-JSON body from ${url}.`, { kind: "shape", cause: err });
  }
  if (!res.ok) {
    throw new HLOApiError(`HTTP ${res.status} from ${url}.`, {
      kind: "http", status: res.status, body: data,
    });
  }
  return data;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, ms)));
}
