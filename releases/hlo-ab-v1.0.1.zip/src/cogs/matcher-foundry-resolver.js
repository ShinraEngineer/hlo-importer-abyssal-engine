// ============================================================
// COG: matcher-foundry-resolver.js - Live-Foundry resolver
//                                    backed by game.packs
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.3.0
//           - v0.6.7 audit fix. Dropped the malformed UUID
//             fallback at the uuid: line. Previous code was:
//               pack.getUuid?.(entry._id)
//                 ?? `Compendium.${packId}.${entry._id}`
//             The fallback string was wrong-shaped for V14 -
//             canonical UUID format is Compendium.{scope}.
//             {packId}.{Type}.{id} (e.g. Compendium.pf2e.
//             feats-srd.Item.abc123); fallback omitted the
//             Type segment and would have produced UUIDs no
//             fromUuid() could resolve. Audit (a review pass of the
//             v0.6.7 review) confirmed pack.getUuid is in
//             V14's documented contract, not an optional
//             method, so the optional chaining and fallback
//             were defensive overkill. See docs/FOUNDRY_API_
//             NOTES.md for the full audit findings.
//           - 0.2.0: Wave 2 of the cog migration. Promoted from
//             src/matcher/foundry-resolver.js. Internal import
//             now points at sibling cog ./matcher-slug-table.js.
//             No logic changes.
//           - 0.1.0: Phase 1 (in src/matcher/). Foundry-runtime
//             resolver. Mirrors the shape of mock-resolver.js but
//             resolves against the live `game.packs` collection.
//             The index of each pack is cached per session so
//             repeat lookups during a single import do not
//             re-fetch.
//
// PF2e and SF2e store the canonical slug on `system.slug` of each compendium
// document. By default that field is NOT part of `pack.index`; we have to
// rebuild the index with `fields: ["system.slug"]` to make slug lookups
// possible. This is the load-bearing detail without which the matcher's
// slug-first strategy would silently miss every entry.

import { slugifyName } from "./matcher-slug-table.js";

/**
 * Build a Foundry-runtime resolver. Must be invoked inside Foundry where
 * `game.packs` is available; in Node use makeMockResolver instead.
 *
 * @returns {{
 *   index: (packId: string) => Promise<Array<{name: string, slug: string, uuid: string}>>,
 *   bySlug: (packId: string, slug: string) => Promise<object | null>,
 * }}
 */
export function makeFoundryResolver() {
  const cache = new Map();

  async function indexFor(packId) {
    if (cache.has(packId)) return cache.get(packId);
    const pack = game?.packs?.get(packId);
    if (!pack) {
      cache.set(packId, []);
      return [];
    }
    const idx = await pack.getIndex({ fields: ["system.slug", "type"] });
    const arr = Array.from(idx, (entry) => ({
      _id: entry._id,
      name: entry.name,
      slug: entry.system?.slug ?? slugifyName(entry.name),
      // v0.6.7: getUuid is reliably present on every V14
      // CompendiumCollection (per docs/FOUNDRY_API_NOTES.md, Compendium
      // section). Previous fallback string was malformed - V14 canonical
      // shape is Compendium.{scope}.{packId}.{Type}.{id} and the fallback
      // omitted the Type segment, which would have failed any downstream
      // fromUuid() lookup. The audit also confirmed `pack.getUuid` is in
      // the documented contract, not an optional method, so the optional
      // chaining was defensive overkill. Now uses pack.getUuid directly.
      uuid: pack.getUuid(entry._id),
      type: entry.type,
    }));
    cache.set(packId, arr);
    return arr;
  }

  return {
    async index(packId) {
      return indexFor(packId);
    },
    async bySlug(packId, slug) {
      const arr = await indexFor(packId);
      return arr.find((e) => e.slug === slug) ?? null;
    },
  };
}
