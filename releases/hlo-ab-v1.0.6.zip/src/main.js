// Author:   Shinra CC
// Date:     2026-10-29
// Revision: 0.6.3
//           - 0.6.3: Sheet button injection is a named function registered on both
//             renderActorSheet (V1 sheets) and renderActorSheetV2 (audit C10),
//             so the button survives either system moving to ApplicationV2.
//           - Sheet-header button no longer stretches across the
//             title bar at wide window sizes. The button is now
//             wrapped in a <span class="ae-header-btn-wrap"> that
//             becomes the actual flex child of .window-header, and
//             both the wrapper and the inner button are pinned to
//             flex: 0 0 auto / max-width: max-content via CSS
//             !important overrides. Root cause was an upstream
//             flex-grow rule (most likely from V1 compat or a
//             system stylesheet) growing the button itself to
//             consume the unallocated header width. Five prior
//             revisions tried to fix this by tightening internal
//             margin / padding / gap on the button; none of them
//             addressed the parent-imposed flex growth. This
//             change does. Paired with import-dialog.css 0.7.1.
//           - 0.6.1: v0.6.5: button text changed from "Abyssal-Engine
//             Import" to "AE HeroLab Importer" per user feedback
//             that the previous label was branded but not
//             informative ("doesn't tell the user what it is").
//             Same icon-then-label layout. Tooltip preserves
//             the Abyssal Engine attribution for users who
//             hover. Paired with tightened CSS margins/padding
//             in import-dialog.css 0.6.1 to give back the
//             "dead space" the screenshot called out.
//           - 0.6.0: Sheet-header button: removed the theme-detection
//             branch entirely. Field-confirmed that the dark-
//             purple variant rendered washed-out and barely
//             legible against PF2e/SF2e light-mode headers, and
//             the gray variant reads fine on both dark and
//             light. One icon, one CSS class, no per-render
//             theme inspection. resolveSheetTheme() and
//             ICON_LIGHT_SHEET are gone. Defensive simplicity
//             beats a dynamic switch that picked wrong.
//           - Same release: removed the duplicate-button bug.
//             Old code fell back to root.querySelector("header")
//             when .window-header was missing, which sometimes
//             matched a nested <header> inside the sheet body
//             (the character vitals strip on PF2e/SF2e sheets).
//             The fallback is gone; we only inject into the
//             literal .window-header. If a sheet does not
//             expose one, no button is injected (cleaner than
//             dropping it into the wrong parent).
//           - 0.5.0: Wave 6 of the cog migration. The four bootstrap
//             imports now point at src/cogs/ exclusively
//             (cogs/util-version, cogs/util-logger, cogs/ui-
//             import-dialog, cogs/ui-settings). main.js stays
//             at src/main.js because it is declared in
//             module.json's esmodules array as the Foundry
//             entrypoint; renaming it would require editing
//             module.json in lockstep with the Foundry loader.
//             After this wave, src/ contains only main.js +
//             cogs/ + schema-snapshots/.
//           - 0.4.3: Removed the viewport-fixed version badge entirely. The
//             badge now lives INSIDE the import dialog (bottom-left
//             corner of the dialog window), visible only while the
//             dialog is open, never floating on the Foundry screen.
//             The dialog template renders it from MODULE_VERSION via
//             its prepared context. injectVersionBadge() is gone.
//           - 0.4.2: Version badge now reads MODULE_VERSION instead of
//             the removed MODULE_BUILD. module.json "version" is bumped
//             on every update now, so MODULE_VERSION is the single
//             source of truth the badge surfaces.
//           - 0.4.1: Fixed resolveSheetTheme for PF2e/SF2e. It matched a
//             bare `.theme-light` class, which the global colorScheme
//             setting puts on document.body; but PF2e/SF2e sheets are
//             dark by default and only their `.themed.theme-light`
//             styling flips them light. So a light global setting
//             wrongly painted the button purple on a still-dark SF2e
//             sheet. Now matches `.themed.theme-light` (both classes),
//             the real "sheet is light" signal, which also excludes
//             document.body by construction. Also added the on-screen
//             version badge in the bottom-left corner.
//           - 0.4.0: Sheet-header import button is now theme-aware. The
//             button ships in two color schemes (grey for dark sheets,
//             abyssal purple for light sheets) because a single fixed
//             color could not stay legible on both. resolveSheetTheme()
//             inspects the host sheet to decide which icon + CSS theme
//             class to apply.
//           - 0.3.0: Sheet-header import button rebrand: dropped the
//             generic FontAwesome cloud-arrow icon for the Abyssal
//             Engine minimalist gear/crystal mark, and renamed the
//             visible label from "HLO" to "Abyssal-Engine Import". The
//             icon ships with the module under icons/ and is sized via
//             CSS so it scales crisply on hi-DPI displays without
//             baking a rasterized copy.
//           - Phase 1, module entrypoint. Registers init and ready hooks,
//             verifies the active game system, and injects an "Import from
//             HLO" button onto character sheets for the supported systems.
//             Clicking the button opens the HLOImportDialog (ApplicationV2)
//             in paste-JSON mode. API and upload modes arrive in later
//             phases.

import { MODULE_ID, MODULE_TITLE, MODULE_VERSION, SUPPORTED_SYSTEMS } from "./cogs/util-version.js";
import { logger } from "./cogs/util-logger.js";
import { HLOImportDialog } from "./cogs/ui-import-dialog.js";
import { registerSettings } from "./cogs/ui-settings.js";

// One glyph for every sheet, dark or light. Field testing showed the
// dark-purple variant rendered as a washed-out near-black against PF2e/
// SF2e light-mode headers (the system stylesheets blend it into the
// header background), while the gray variant reads cleanly on both.
// One icon is simpler and more reliable than a per-render theme switch
// that picked wrong half the time.
const ICON_GLYPH = `modules/${MODULE_ID}/icons/abyssal-engine-minimalist-light-gray.png`;

Hooks.once("init", () => {
  logger.info(`${MODULE_TITLE} v${MODULE_VERSION} initializing.`);
  registerSettings();
});

Hooks.once("ready", () => {
  const systemId = game?.system?.id;
  if (!SUPPORTED_SYSTEMS.includes(systemId)) {
    logger.warn(
      `Active system "${systemId}" is not in the supported list (${SUPPORTED_SYSTEMS.join(", ")}).`,
      "The Import from HLO button will not appear.",
    );
    return;
  }
  logger.info(`Ready. Active system: ${systemId}.`);
});

// Inject the import button on character sheets after Foundry renders them.
// renderActorSheet fires for Application V1 sheets (what PF2e and SF2e ship
// today); ApplicationV2 sheets fire renderActorSheetV2 instead, so both are
// registered (audit C10) and the per-header dedupe below keeps a sheet that
// somehow fires both from getting two buttons.
function injectImportButton(app, html, _data) {
  const systemId = game?.system?.id;
  if (!SUPPORTED_SYSTEMS.includes(systemId)) return;
  if (app?.actor?.type !== "character") return;

  // html may be a DOM element (V13 sheets) or a jQuery wrapper (legacy);
  // normalize to a plain element root.
  const root = html instanceof HTMLElement
    ? html
    : (html?.[0] ?? html);
  if (!root || typeof root.querySelector !== "function") return;

  // Only inject into the application's window-header. The previous
  // fallback to root.querySelector("header") was matching a nested
  // <header> inside the sheet body (the PF2e/SF2e character vitals
  // strip), which produced a duplicate button under the title bar.
  // No fallback: if there is no .window-header, skip the injection
  // entirely. A missing button is better than a button in the wrong
  // place.
  const header = root.querySelector(".window-header");
  if (!header) return;

  // Dedupe against THIS header (not just any descendant of root) so a
  // re-render or a second .window-header somewhere in the tree cannot
  // double-inject.
  if (header.querySelector(`[data-${MODULE_ID}="button"]`)) return;

  // Build the button entirely via safe DOM methods. Avoids innerHTML for
  // defensive habit even with static content.
  //
  // IMPORTANT: do NOT use the `header-button` class. Foundry V13 / PF2e
  // attach jQuery-delegated click handlers on the actor sheet header
  // that match that class and expect each matched element to be a
  // registered sheet-control with a click-action config. An unregistered
  // button with the class triggers a TypeError ("Cannot read properties
  // of undefined (reading 'onclick')") inside foundry.mjs. Use a
  // dedicated module-scoped class instead, and call
  // stopImmediatePropagation() to prevent the same-element jQuery
  // delegate from firing alongside our native listener.
  const btn = document.createElement("button");
  btn.type = "button";
  btn.classList.add("abyssal-engine-hlo-import");
  btn.setAttribute(`data-${MODULE_ID}`, "button");
  btn.title = "AE HeroLab Importer (Abyssal Engine: import from HeroLab Online)";

  const icon = document.createElement("img");
  icon.src = ICON_GLYPH;
  icon.alt = "";
  icon.classList.add("ae-import-glyph");
  btn.appendChild(icon);
  btn.appendChild(document.createTextNode(" AE HeroLab Importer"));

  btn.addEventListener("click", (ev) => {
    ev.preventDefault();
    ev.stopImmediatePropagation();
    try {
      new HLOImportDialog({ document: app.actor }).render(true);
    } catch (err) {
      logger.error("Failed to open HLOImportDialog", err);
    }
  });

  // Wrap the button in a span that becomes the actual flex child of
  // .window-header. This isolates the button from the parent's flex
  // layout so that any upstream rule (PF2e/SF2e system styles, V1
  // compatibility layer, or future Foundry changes) that tries to
  // grow header children does so on the wrapper, not on the button
  // itself. The wrapper is explicitly flex: 0 0 auto so it does not
  // grow either. Belt-and-suspenders; the import button has stretched
  // to full title-bar width across five revisions and we are not
  // re-fighting this on the next system update.
  const wrap = document.createElement("span");
  wrap.classList.add("ae-header-btn-wrap");
  wrap.setAttribute(`data-${MODULE_ID}`, "button-wrap");
  wrap.appendChild(btn);

  const titleEl = header.querySelector(".window-title");
  if (titleEl && titleEl.nextSibling) {
    header.insertBefore(wrap, titleEl.nextSibling);
  } else {
    header.appendChild(wrap);
  }
}

Hooks.on("renderActorSheet", injectImportButton);
Hooks.on("renderActorSheetV2", injectImportButton);
