// ============================================================
// COG: builder-items.js - Compendium-reference stub builder
//                         shared by PF2e and SF2e actor builders
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-29
// Revision: 0.5.2
//           - 0.5.2: applyRunePatch accepts runeType "reinforcing" and records the
//             numeric tier on the parent IR for shields (audit A15).
//           - 0.5.1: v1.0.6: Staff joins WEAPON_COMPSETS_FOR_RUNES so a Rune item
//             nested under a staff patches the staff the way it would a
//             Weapon.
//           - v0.7.1 Rune Triad (pass 2): buildItemReference now
//             plumbs `item.runes` through to the compendium-reference
//             stub as `ref.runes`. The dialog's resolveSkeletonForCreate
//             reads this field and writes system.runes onto the
//             resolved Foundry item, mapping `runes.striking` to
//             system.runes.striking on weapons and `runes.resilient`
//             to system.runes.resilient on armor. The propertyRunes
//             list (canonical camelCase slugs from util-rune-parser:
//             ghostTouch, fireResistant, greaterReady, etc.) is
//             written to system.runes.property. Without this stub
//             field the dialog had no path from the parsed runes to
//             the actor item; v0.7.0 weapons landed with empty
//             system.runes despite the parser correctly extracting
//             the rune set. Verified against Bhelroth EC and Berial
//             Jeggare ETT/PFS.
//           - v0.7.1: added applyRuneAndMaterialPatches(actorIR),
//             a pre-build pass that consumes the _runeApplyTo and
//             _materialApplyTo discriminators emitted by the new
//             parser-compset-rune and parser-compset-material
//             cogs. HLO ships every weapon and armor rune (and
//             every material variant) as a standalone item nested
//             under the parent weapon/armor; PF2e/SF2e Foundry
//             stores both as fields ON the parent
//             (system.runes.{potency,striking,resilient,property[]}
//             and system.material.{type,grade}). The pre-build
//             pass walks the IR, locates each apply-to patch,
//             finds the parent by parentId, merges the rune/
//             material into the parent's IR envelope (taking
//             max() for potency/striking/resilient so any name-
//             extracted runes from util-rune-parser also win),
//             and tags the patch item with _consumed so the
//             actor builders can filter it out of
//             buildItemReferences. Without this pass, the new
//             Rune/Material handlers would emit zero embedded
//             items (correct) but also drop the data they
//             collected (silent regression). Verified against
//             Berial Jeggare PFS's Numerian Steel Breastplate
//             (three nested runes including ruArmResistFire) and
//             Bhelroth EC's bastard sword (four runes + one
//             material).
//           - v0.6.10: added reqLevelNet to the stub's hlo
//             back-reference so the dialog's new
//             assignFeatLocations() helper can bind HLO feats
//             to the correct class/skill/ancestry slot
//             instead of letting them cascade to "Bonus
//             Feats." parser-compset-feats already preserves
//             reqLevelNet on the parsed item; this just
//             plumbs it through the stub layer.
//           - 0.2.0: Wave 3 of the cog migration. Promoted from
//             src/builder/build-items.js. No logic changes; only
//             the file location and header are new.
//           - 0.1.0: Phase 1 (in src/builder/). Shared item
//             construction. Takes a matched item record (item IR
//             plus match result) and produces either:
//               (a) a compendium reference stub the import
//                   dialog will resolve against game.packs at
//                   Actor.create time, or
//               (b) a homebrew item document (when no match was
//                   found and the user opted to keep unmatched
//                   items as raw HLO data).
//
// Phase 1 only emits compendium references. Homebrew fallback lands in
// Phase 2 alongside the feats / spells / weapons handlers.

/**
 * Build a Foundry item-reference stub from a matched item.
 * Returns an object with the minimum shape needed for the import dialog to
 * later resolve the document via `game.packs.get(pack).getDocument(...)`.
 *
 * @param {{item: object, match: object|null}} matched
 * @returns {object | null} Reference stub or null if no usable match.
 */
export function buildItemReference({ item, match }) {
  if (!match) return null;
  // v0.6.6: skip-by-design matches resolve to no compendium item;
  // builder must not emit a reference, the dialog logs the skip
  // separately so the user sees what was deliberately omitted.
  if (match.strategy === "skip") return null;
  return {
    type: "compendium-reference",
    pack: match.pack,
    slug: match.slug,
    name: item.name ?? match.entry?.name ?? null,
    sourceCompset: item.compset,
    confidence: match.confidence,
    strategy: match.strategy,
    // v0.7.1 Rune Triad (pass 2): pass the parsed rune envelope
    // through to the dialog so resolveSkeletonForCreate can write
    // system.runes onto the resolved Foundry weapon/armor item. The
    // envelope is whatever the parser handler attached (Weapon,
    // Armor, CustomArmor, MagicItem all populate it from
    // extractRunes(name)). Items with no runes get an empty envelope
    // (potency=0, striking=0, propertyRunes=[]) which still writes a
    // zeroed system.runes block; this is safe because PF2e's template
    // default for system.runes is the same zeroed block, so we never
    // write garbage to a non-magic weapon. Items whose IR carries no
    // runes field at all (every non-weapon, non-armor compset) get
    // null here and the dialog skips the write.
    runes: item.runes ?? null,
    // Preserve a back-reference so the dialog can show the user what HLO
    // item produced this reference, for the conversion log.
    hlo: {
      id: item.id,
      slug: item.slug,
      containment: item.containment ?? null,
      parentId: item.parentId ?? null,
      // v0.6.10: surfaced for assignFeatLocations() in the
      // dialog's resolver pass. SF2e/PF2e use level.taken +
      // location to bind a feat to a class/skill/ancestry slot;
      // unset feats cascade to "Bonus Feats." HLO knows the
      // level the feat was taken at; we just have to forward it.
      reqLevelNet: item.reqLevelNet ?? null,
      // Trait list helps the slotter decide which category the
      // feat belongs to (trtClass*, trtSkill, ancestry traits,
      // trtGeneral) when system.category is not enough.
      traitIds: Array.isArray(item.traitIds) ? item.traitIds : [],
    },
  };
}

/**
 * Build many item references at once. Filters out null results (items that
 * had no match) so the caller gets a clean list. Use this when assembling
 * the `items` array on a Foundry actor.
 */
export function buildItemReferences(matchedList) {
  return matchedList
    .map(buildItemReference)
    .filter((ref) => ref != null);
}

/**
 * Compsets eligible to receive an apply-to-parent rune patch. Weapons
 * and the magic-item handwraps/bloodknuckles family take weapon runes;
 * armor (including the CustomArmor variant for lore-named armors) and
 * shields take armor/shield runes. MagicItem is included because HLO
 * emits handwraps under MagicItem; the handler tags those with
 * foundryType="weapon" and the same system.runes envelope applies.
 */
const WEAPON_COMPSETS_FOR_RUNES = new Set([
  "Weapon", "MagicItem", "Staff",
]);
const ARMOR_COMPSETS_FOR_RUNES = new Set([
  "Armor", "CustomArmor",
]);

/**
 * Apply _runeApplyTo and _materialApplyTo patches in-place onto the
 * actor IR. For each patch item:
 *   1. Find the parent IR by patch.parentId.
 *   2. For runes: merge into parent.runes (taking max() of existing
 *      potency/striking/resilient so name-extracted runes from
 *      util-rune-parser still hold; pushing property runes onto the
 *      list without dupes).
 *   3. For materials: write parent.material = { type, grade }. The
 *      target is derived from the parent's compset since HLO uses one
 *      "mt" prefix for both weapon and armor materials.
 *   4. Tag the patch item with _consumed=true so the actor builder
 *      filters it out of buildItemReferences.
 *
 * Logs a warning to the warnings array when a patch can't be applied
 * (no parent, parent has wrong compset for the rune target, etc.) so
 * the dialog's conversion log surfaces the orphan.
 *
 * @param {object} actorIR  ActorIR from parseActor. Mutated in place.
 * @param {Array}  warnings Shared warning accumulator (optional).
 * @returns {object}        actorIR (for chaining).
 */
export function applyRuneAndMaterialPatches(actorIR, warnings) {
  if (!actorIR?.items || !Array.isArray(actorIR.items)) return actorIR;

  const byId = new Map(actorIR.items.map((it) => [it.id, it]));

  for (const item of actorIR.items) {
    if (item._runeApplyTo) {
      applyRunePatch(item, byId, warnings);
    }
    if (item._materialApplyTo) {
      applyMaterialPatch(item, byId, warnings);
    }
  }
  return actorIR;
}

function applyRunePatch(patchItem, byId, warnings) {
  const patch = patchItem._runeApplyTo;
  const parent = patchItem.parentId ? byId.get(patchItem.parentId) : null;

  if (!parent) {
    pushWarn(warnings, "orphan-rune",
      `Rune "${patchItem.name}" has no parent weapon/armor in scope; the rune was not applied.`,
      { runeItemId: patchItem.id, parentId: patchItem.parentId });
    return;
  }

  // Verify the parent's compset matches the rune's target. If a weapon
  // rune is nested under armor (or vice versa) we treat it as a data
  // bug and warn but still apply, because the parent linkage is what
  // HLO sent.
  const parentIsWeapon = WEAPON_COMPSETS_FOR_RUNES.has(parent.compset);
  const parentIsArmor  = ARMOR_COMPSETS_FOR_RUNES.has(parent.compset);
  if (!parentIsWeapon && !parentIsArmor) {
    pushWarn(warnings, "rune-parent-mismatch",
      `Rune "${patchItem.name}" parent "${parent.name}" (compset ${parent.compset}) is neither weapon nor armor; the rune was not applied.`,
      { runeItemId: patchItem.id, parentCompset: parent.compset });
    return;
  }

  // Initialize parent.runes envelope if no handler has already set it.
  // As of v0.7.1 the Weapon, Armor, CustomArmor, and MagicItem handlers
  // all populate `runes` from extractRunes(name), so this seed is
  // typically a no-op for those compsets; it remains as a safety net
  // for future compsets that route runes here without their own name
  // extractor.
  parent.runes ??= {
    potency: 0,
    striking: 0,
    propertyRunes: [],
    baseName: parent.name ?? "",
    matchedRunes: [],
  };
  // Armor stores resilient as a separate numeric field; potency is
  // shared between weapon and armor. Armor IRs initialize resilient
  // to 0 in parser-compset-armor; this default covers weapon IRs that
  // accidentally receive an armor rune, and pre-pass-2 IR snapshots.
  parent.runes.resilient ??= 0;

  switch (patch.runeType) {
    case "potency":
      parent.runes.potency = Math.max(parent.runes.potency ?? 0,
                                       patch.runeValue ?? 0);
      parent.runes.matchedRunes.push(`+${patch.runeValue}`);
      break;
    case "striking":
      parent.runes.striking = Math.max(parent.runes.striking ?? 0,
                                        patch.runeValue ?? 0);
      parent.runes.matchedRunes.push(
        patch.runeValue === 3 ? "major-striking"
          : patch.runeValue === 2 ? "greater-striking"
          : "striking");
      break;
    case "resilient":
      parent.runes.resilient = Math.max(parent.runes.resilient ?? 0,
                                         patch.runeValue ?? 0);
      parent.runes.matchedRunes.push(
        patch.runeValue === 3 ? "major-resilient"
          : patch.runeValue === 2 ? "greater-resilient"
          : "resilient");
      break;
    case "reinforcing":
      parent.runes.reinforcing = Math.max(parent.runes.reinforcing ?? 0,
                                           patch.runeValue ?? 0);
      parent.runes.matchedRunes.push(`reinforcing-${patch.runeValue ?? 0}`);
      break;
    case "property":
      if (patch.runeName && !parent.runes.propertyRunes.includes(patch.runeName)) {
        parent.runes.propertyRunes.push(patch.runeName);
        parent.runes.matchedRunes.push(patch.runeName);
      }
      break;
    default:
      pushWarn(warnings, "unknown-rune-type",
        `Rune "${patchItem.name}" has unknown runeType "${patch.runeType}"; only potency/striking/resilient/reinforcing/property are recognized.`,
        { runeItemId: patchItem.id, runeType: patch.runeType });
      return;
  }

  patchItem._consumed = true;
}

function applyMaterialPatch(patchItem, byId, warnings) {
  const patch = patchItem._materialApplyTo;
  const parent = patchItem.parentId ? byId.get(patchItem.parentId) : null;

  if (!parent) {
    pushWarn(warnings, "orphan-material",
      `Material "${patchItem.name}" has no parent weapon/armor in scope; the material was not applied.`,
      { materialItemId: patchItem.id, parentId: patchItem.parentId });
    return;
  }

  // Materials apply to both weapons and armor (HLO uses one "mt"
  // prefix). The parent's compset tells us which Foundry schema
  // applies; either way it ends up on parent.material with the
  // canonical PF2e shape.
  const parentEligible = WEAPON_COMPSETS_FOR_RUNES.has(parent.compset)
                      || ARMOR_COMPSETS_FOR_RUNES.has(parent.compset);
  if (!parentEligible) {
    pushWarn(warnings, "material-parent-mismatch",
      `Material "${patchItem.name}" parent "${parent.name}" (compset ${parent.compset}) is neither weapon nor armor; the material was not applied.`,
      { materialItemId: patchItem.id, parentCompset: parent.compset });
    return;
  }

  parent.material = {
    type:  patch.materialName,
    grade: patch.materialGrade,
  };

  patchItem._consumed = true;
}

function pushWarn(warnings, code, message, context) {
  if (Array.isArray(warnings)) {
    warnings.push({ code, message, context });
  }
}
