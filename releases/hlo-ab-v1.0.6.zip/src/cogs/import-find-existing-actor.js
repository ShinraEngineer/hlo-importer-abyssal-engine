// ============================================================
// COG: import-find-existing-actor.js - Idempotent re-import
//                                      lookup (flag + name fallback)
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-29
// Revision: 0.3.1
//           - 0.3.1: Name fallback adopts only an actor of the type the import is
//             about to write (audit B9).
//           - Wave 5 of the cog migration. Promoted from
//             src/import/find-existing-actor.js. Internal import
//             still points at ../util/version.js; that gets
//             relocated to a sibling cog in Wave 6.
//           - 0.2.0: Added name-based fallback. Previously this
//             only matched actors carrying our module flag, so
//             a manually-created actor with the matching name
//             would be invisible and the import would silently
//             produce a duplicate at the bottom of the actor
//             list. Now we also offer a name match (case-
//             insensitive, exact) as a second pass, with
//             `matchedBy` on the return so the caller can log
//             how we found it.
//           - 0.1.0: Wave 5 (in src/import/). Idempotency
//             helper. Looks up any actor in the world that was
//             previously imported from the same HLO portfolio
//             so the dialog can offer Update vs Create New
//             rather than silently producing duplicates.
//
// The hlo flag we stamp at create time (flags.hlo-importer-abyssal-engine)
// carries `hloKey` (HLO actor key like "actor.1") and `sourceHloVersion`,
// which together identify a re-imported character. The portfolio's charId
// is also captured for cross-version lookups.

import { MODULE_ID } from "./util-version.js";

/**
 * Find an existing actor that matches this HLO actor. First pass uses
 * our module flag (charId + hloKey), second pass falls back to exact
 * name match so users can re-import onto a manually-created actor.
 *
 * @param {string} charId   HLO portfolio.charId (e.g. "pSF9tO95").
 * @param {string} hloKey   HLO actor key (e.g. "actor.1").
 * @param {string} [actorName]  HLO actor name; used for fallback match.
 * @param {string} [actorType]  Foundry actor type the import will write;
 *                              a name match must share it when given.
 * @returns {{ actor: Actor, matchedBy: "flag"|"name" } | null}
 */
export function findExistingHloActor(charId, hloKey, actorName = null, actorType = null) {
  if (typeof game === "undefined") return null;
  const actors = game.actors?.contents ?? [];

  // First pass: exact flag match (previously imported by us).
  if (charId && hloKey) {
    for (const actor of actors) {
      const flags = actor.flags?.[MODULE_ID];
      if (!flags) continue;
      if (flags.hloCharId === charId && flags.hloKey === hloKey) {
        return { actor, matchedBy: "flag" };
      }
      // Older imports may have only hloKey; treat as a match if charId is absent.
      if (flags.hloKey === hloKey && !flags.hloCharId) {
        return { actor, matchedBy: "flag" };
      }
    }
  }

  // Second pass: case-insensitive exact name match. Adopt the actor by
  // claiming it on update; useful when the user pre-created the sheet.
  // When the caller says what type it is about to write (character, npc,
  // familiar), only an actor of that type is adopted (0.2.1, audit B9):
  // adopting an NPC that shares the PC's name wrote a character-shaped
  // system block onto it.
  if (actorName) {
    const target = actorName.trim().toLocaleLowerCase();
    for (const actor of actors) {
      if ((actor.name ?? "").trim().toLocaleLowerCase() !== target) continue;
      if (actorType && actor.type !== actorType) continue;
      return { actor, matchedBy: "name" };
    }
  }
  return null;
}
