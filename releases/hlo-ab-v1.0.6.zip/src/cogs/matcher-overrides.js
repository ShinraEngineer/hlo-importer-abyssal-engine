// ============================================================
// COG: matcher-overrides.js - Curated HLO -> Foundry override
//                             table for known-mismatch landmines
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-28
// Revision: 0.6.12
//           - 0.6.12: v1.0.6 (public issue 2): NaturalWep:nwFoxfireKit added to
//             SKIP_BY_DESIGN. The Foxfire ancestry feat grants the strike
//             through its rule elements, exactly like nwFist and nwFangsGr.
//           - v0.7.1 (pass 3, silent-drop Bug 2 fallback): two name-
//             keyed Wand overrides for "Wand of cozy cabin" (HLO
//             sentence case) and "Wand of Cozy Cabin" (Foundry title
//             case) routing to equipment-srd/wand-of-cozy-cabin. The
//             v0.7.0 Berial PFS import dropped this wand silently
//             because matchItem returned null and the dialog's
//             COMPENDIUM_COMPSETS gate did not list Wand. The
//             silent-drop fix in ui-import-dialog now makes this
//             miss visible; this override turns the miss into a
//             canonical hit when the user has pf2e.equipment-srd
//             installed (the wand-of-cozy-cabin slug is verified
//             present per parser-compset-wand.js's pack-index audit).
//             Both casings are registered because OVERRIDES is a
//             keyed Map and the parser passes the raw display name
//             from HLO; HLO emits sentence-case for spell names in
//             wand entries.
// Revision: 0.6.10
//           - Revascis Virholt (Vampire Magus L20) verification sweep
//             surfaced 13 unmatched items from v0.7.0 testing. After
//             investigation, 12 of them resolve to SKIP_BY_DESIGN or a
//             single OVERRIDE; one (Background:Combatant) is left as a
//             real miss pending future Foundry/HLO data alignment.
//             Total adds: 11 SKIP_BY_DESIGN, 2 OVERRIDES (Scorching
//             Rays name + HLO-id slug pair).
//
//             SKIP_BY_DESIGN group 1: seven vampire/undead trait
//             blocks installed via the Vampire Dedication feat's
//             GrantItem rule chain. Verified against the Virholt
//             Foundry actor export (KaT3cE0L5xkQAGur, 2026-05-16):
//             Vampire Dedication
//             (pf2e.feats-srd/vampire-dedication, source I5hzE0XT2BsjatS3)
//             carries flags.pf2e.itemGrants for basicUndeadBenefits,
//             revulsion, sunlight, and drinkBlood;
//             basicUndeadBenefits is the umbrella ancestry-feature
//             (pf2e.ancestryfeatures/basic-undead-benefits, source
//             SAbzItAI4uwbdnQk) that delivers the undead trait
//             benefits as descriptive text (Disease/Poison
//             Protection, Immunity to Death Effects, Paralysis/Sleep
//             Protection, Undead Hunger, Void Healing, Void
//             Survival). HLO emits each benefit as its own
//             Ability:ab* line, but PF2e does not ship them as
//             standalone compendium items; they live as paragraphs
//             under the parent benefits feature. Sunlight
//             Vulnerability is delivered by the Sunlight ancestry-
//             feature (slug "sunlight") granted by the same chain.
//             Skipping at the matcher prevents duplicate/orphan
//             items on the actor while keeping the conversion log
//             clean. Added:
//               Ability:abDisPoisProtUnd  (Disease and Poison Protection)
//               Ability:abImmuneDeathUnd  (Immunity to Death Effects)
//               Ability:abParaSleepProUnd (Paralysis and Sleep Protection)
//               Ability:abSunlightVulnVam (Sunlight Vulnerability)
//               Ability:abUndeadHungerUnd (Undead Hunger / Drink Blood)
//               Ability:abVoidHealing     (Void Healing inversion)
//               Ability:abVoidSurvival    (Void Survival trait)
//
//             SKIP_BY_DESIGN group 2: two magic-item activation
//             echoes, same pattern as the existing
//             Ability:abWayfinderLight skip. The matching MagicItem
//             entries (Crown of Intellect, Greater Soaring Wings
//             tattoo) already resolve canonically via the MagicItem
//             route; the Ability line is the action that activates
//             the item, not a separate compendium item. Added:
//               Ability:abCrIntSearchMind (Crown of Intellect Search activation)
//               Ability:abTatSoarWinFlyGr (Greater Soaring Wings Fly activation)
//
//             SKIP_BY_DESIGN group 3: Action:abArcCascadeMag with HLO
//             name "Arcane Cascade +1" falls into the same
//             activation-echo bucket. The Magus class chain (clMagus)
//             auto-installs the Arcane Cascade class-feature AND the
//             matching action entry. Verified against Virholt's
//             Foundry export: TWO arcane-cascade items already present
//             on the imported actor, one a classfeature
//             (Compendium.pf2e.classfeatures.Item.09iL38CZZEa0q0Mt,
//             folder under Hybrid Study/Laughing Shadow) and one an
//             action (Compendium.pf2e.actionspf2e.Item.HbejhIywqIufrmVM,
//             stance trait), both installed via the Hybrid Study
//             grant chain. The "+1" suffix is HLO's stance-bonus
//             tier display. SKIP_BY_DESIGN is the right disposition:
//             the action already exists; the HLO Ability line would
//             create a duplicate. Chose this over a slug-pipeline
//             "+N" stripping extension because (a) the item is already
//             auto-installed so a clean match would still produce a
//             duplicate, and (b) no other "+N"-tier Action cases are
//             observed in the v0.7.0 fixtures to justify a general
//             pipeline rule. Added:
//               Action:abArcCascadeMag (Arcane Cascade stance bonus tier)
//
//             SKIP_BY_DESIGN group 4: NaturalWep:nwFangsGr verified
//             auto-granted by Vampire Dedication. The dedication
//             description text states "you gain a fangs unarmed attack
//             that deals 1d6 piercing damage" and Virholt's Foundry
//             actor export shows the fangs strike present under the
//             unarmed-strikes block (slug "fangs", group brawling,
//             traits unarmed+grapple) installed by the dedication
//             grant chain alongside the Drink Blood action. The HLO
//             NaturalWep:nwFangsGr line is the same auto-granted
//             unarmed strike, exactly parallel to the existing
//             NaturalWep:nwFist universal-unarmed skip. Added:
//               NaturalWep:nwFangsGr (vampire fangs auto-grant)
//
//             OVERRIDES additions: Spell:spScorchingRay and
//             Spell:"Scorching Ray" both route to
//             spells-srd/scorching-rays. Same pattern as the existing
//             0.6.3 / 0.6.4 Remaster-spell rename block (Wail of the
//             Banshee -> wails-of-the-damned, Magic Missile ->
//             force-barrage, etc): pf2e v8.1.2 retains the spell but
//             renames it to the plural form. Both name-keyed and HLO-
//             id slug-keyed forms registered so the override catches
//             whichever the parser emits. Note on Virholt's Scorching
//             Ray duplication: the HLO export carries spScorchingRay
//             TWICE, once as the spellbook page (spScorchingRay.811
//             nested under grSpellbook.349) and once as the top-level
//             repertoire/spontaneous slot (spScorchingRay.822). This
//             is HLO's deliberate model: the spellbook entry and the
//             prepared/spontaneous slot are distinct item records
//             that share a slug. Both reach the override here and
//             both resolve correctly; dedup at the parser layer would
//             lose the spellbook-vs-slot distinction the actor
//             builder uses to attach each spell to the right
//             spellcastingEntry. Documented but intentionally not
//             changed.
//
//             Non-addition (one entry): Background:Combatant
//             (Bhelroth EC) verified against the 2026-05-16 V14
//             pf2e.backgrounds pack via the bundled FoundryVTT
//             install: no background entry named "Combatant" exists,
//             no background slug "combatant" exists (the word appears
//             only inside another background's description body
//             text). The closest neighbouring backgrounds are
//             "Warrior" and "Osprey Warrior", neither synonymous with
//             "Combatant". Leaving this as a real miss surfaces the
//             gap so a future Foundry data update or an HLO-side
//             data correction (HLO ID is not in the stub list because
//             the parser synthesizes Background items from
//             actBackgroundText, which carries only the display name)
//             can resolve it. Adding a speculative override would
//             route the call to a non-existent slug and silently
//             fail, masking the signal.
// Revision: 0.6.9
//           - Spellbook compset skip. HLO emits Wizard (and other
//             prepared-caster) spellbooks as their own compset
//             "Spellbook" with id prefix "gr" (e.g. grSpellbook.878
//             on the Berial Jeggare PF2e Wizard 8 fixture, a primary
//             spellbook holding 53 nested spells; plus an empty
//             backup grSpellbook.1356). PF2e (v8.1.2) and SF2e
//             (v1.1.2) do NOT model the spellbook as a discrete
//             Foundry item. Evidence:
//             * pf2e.mjs ITEM_TYPES (line 3281-3306) enumerates the
//               23 item types; "book" exists (line 3289) as a generic
//               PhysicalItemPF2e subtype (BookPF2e, pf2e.mjs line
//               55489) for in-world tomes, not a spellcasting
//               container.
//             * equipment-srd ships zero entries with a "spellbook"
//               slug or a bare "Spellbook" name. The only book-themed
//               equipment is "Spellbook of Redundant Enchantment"
//               (a specific magic item, not the generic spellbook).
//             * The mechanism PF2e uses is spellcastingEntry plus
//               child spell items. The Wizard class entry's
//               GrantItem rules install the "Wizard Spellcasting"
//               class feature, which provisions the spellcastingEntry
//               on the actor; prepared spells live as child items
//               keyed by system.location pointing at the
//               spellcastingEntry id. Verified against the Berial
//               Jeggare Foundry export (fpGhYbzcmO4HOpfF, 2026-05-16):
//               imported actor has the Wizard class (id
//               UZ06BR9t2qLFRWYr), "Wizard Spellcasting" feat
//               (location UZ06BR9t2qLFRWYr), all prepared spells, and
//               NO item named "Spellbook" at all. SF2e follows the
//               same pattern (sf2e.mjs line 3304: same
//               spellcastingEntry type).
//             Added "Spellbook:grSpellbook" to SKIP_BY_DESIGN. The
//             parser-compset-spellbook cog returns an empty IR patch
//             so the dispatcher recognises the compset cleanly; the
//             matcher's skip pre-check in matcher-core.js
//             short-circuits with strategy="skip" before any
//             compendium lookup. The contained spells reach the
//             actor through the standard Spell-compset pipeline,
//             and the spellcastingEntry that anchors them is
//             auto-provisioned by the Wizard class embed.
// Revision: 0.6.8
//           - PF2e class-feats refresh against the 4373-entry
//             pf2e.class-feats pack-index dump (PF2e v8.1.2,
//             2026-05-16). Two zarmstrong-era overrides
//             pointed at slugs that no longer exist in the
//             live pack:
//             * Feat:Fencer -> fencer-style. Fencer Style was
//               a Swashbuckler style feat that the Remaster
//               removed entirely. No successor exists in
//               class-feats (zero hits on "fencer" across all
//               4373 entries). Commented out the legacy line
//               so the next HLO hit logs as a true miss
//               instead of silently routing to a non-existent
//               compendium id. There is no canonical target
//               to redirect to.
//             * Feat:Hellknight Signifier Dedication ->
//               hellknight-signifer-dedication. The Remaster
//               split the Signifer chain: the dedication slot
//               is now plain "Hellknight Dedication" and the
//               Signifer progression lives at
//               "Hellknight Signifer Preferment" (level 6).
//               Retargeted the legacy display name to
//               hellknight-dedication so HLO characters with
//               the old class-feat label still resolve to a
//               valid compendium entry. Added an explicit
//               override for Hellknight Signifier Preferment
//               (HLO mis-spelling with the second "i") that
//               redirects to the canonical Foundry slug
//               hellknight-signifer-preferment.
//             Other zarmstrong entries verified valid against
//             the live dump: Known Weakness -> known-
//             weaknesses (level 4 ranger) and Infinite
//             Possilbilites -> infinite-possibilities (level
//             4 witch focus feat) both confirmed present. No
//             new bulk overrides added: the 19 multi-paren-
//             no-bare collision groups (Counterspell, Dueling
//             Dance, Improved Familiar, Mature Animal
//             Companion, Twinned Defense, etc.) all resolve
//             via the parens-preserved-first key in matcher-
//             pack-index 0.3.0 when HLO emits the
//             parenthetical, and we have no observed bare-
//             name HLO emission to overfit against.
// Revision: 0.6.7
//           - SF2e ancestry-slice audit (Ancestries + Heritages +
//             Ancestry Features + Ancestry Feats) against the
//             2026-05-16 V14 pack-index dumps (sf2e v1.1.2: 48
//             ancestries, 286 heritages, 47 ancestry-features, 1318
//             ancestry-feat entries in sf2e.feats; sf2e-anachronism
//             v2.1.0 mirror: 1289 entries). Findings:
//             * Cross-system pack routing fix for the four
//               SF2e-native parenthetical ancestry-feats. The 0.6.0
//               override block routed all 23 parenthetical heritage
//               variants to "feats-srd", which qualifies to
//               pf2e.feats-srd on PF2e (correct for the 19 PF2e
//               natives) but to sf2e.feats-srd on SF2e (a pack that
//               does not exist). For the four SF2e-native entries
//               (Ancestral Weapon Familiarity Astrazoan,
//               Bioluminescence Shirren, Gooey Engulf Entu, Hang in
//               There Nu Friend) the fallback would have failed when
//               a PF2e character pulled SF2e content through the
//               Anachronism route. Switched their override pack to
//               the already-namespaced "sf2e-anachronism.feats" so
//               the fallback resolves correctly. SF2e characters
//               continue to hit the parens-preserved canonical key
//               in matcher-pack-index 0.3.0 before reaching the
//               override layer at all.
//             * SF2e SENSE_TYPES coverage re-confirmed COMPLETE
//               (sf2e.mjs line 15212 enumerates 17 senses: 15 are in
//               SKIP_BY_DESIGN, 2 are canonical compendium entries
//               that match natively: greater-darkvision in pf2e-
//               anachronism.ancestry-features and thoughtsense in
//               sf2e.ancestry-features). No additions needed.
//             * SF2e versatile heritages (aquazoan, borai,
//               construct-copycat, corpsefolk, deadwood, gap-touched,
//               inflorescent, karapentu, nelentu, petrified, prismeni,
//               sand-roamer, skitter-raised, squentu, tempering,
//               wildseed, yeulentu) all ship as clean kebab-case
//               slugs in sf2e.heritages; HLO hr* slugs decamelize
//               natively (confirmed for hrPrismeni on Noxora,
//               2026-05-16 import log).
//             * Native-resolved SF2e ancestry-features (no override
//               or skip needed): emotionsense, soulfeel, dermal-
//               hearing, limited-telepathy, magical-sense, thought-
//               sense -- all live in sf2e.ancestry-features and
//               decamelize from the HLO ab* slug to the canonical
//               kebab-case slug.
// Revision: 0.6.6
//           - PF2e identity-item audit (backgrounds, deities,
//             heritages, ancestries) against the 2026-05-16 V14
//             pack-index dump (pf2e v8.1.2: 490 backgrounds, 478
//             deities, 322 heritages, 50 ancestries). Findings:
//             * Ancestry/Heritage Remaster aliases. HLO retains
//               several pre-Remaster names that no longer exist in
//               pf2e.ancestries or pf2e.heritages. Added name-keyed
//               and HLO-id-keyed Heritage overrides for the planar/
//               half-ancestry pairs that were collapsed/renamed:
//                 Half-Elf     -> aiuvarin   (heritage)
//                 Half-Orc     -> dromaar    (heritage)
//                 Aasimar      -> nephilim   (heritage)
//                 Tiefling     -> nephilim   (heritage)
//               And the Ancestry rename:
//                 Gnoll        -> kholo      (ancestry)
//               Each target slug was verified present in the 2026-
//               05-16 dump; each legacy slug is ABSENT.
//             * Background canonical-lookup safety. Two background
//               collision pairs exist where the parens-stripped key
//               collides on first-wins registration:
//                 press-ganged -> Press-Ganged (G&G) | (LOWG)
//                 refugee      -> Refugee (Fall of Plaguestone) |
//                                 Refugee (PC2)
//               If HLO emits the disambiguated name with parens
//               (e.g. "Refugee (PC2)"), the parens-PRESERVED first-
//               pass in matcher-pack-index 0.3.0 resolves it
//               correctly. If HLO emits the bare name, the lookup
//               is non-deterministic (alphabetic-first wins). No
//               overrides added: we have no evidence HLO emits the
//               bare form, and a speculative default could mask a
//               real future signal. Documented for future investig.
//             * Deity epithets. The four Nyarlathotep variants and
//               two Lissala variants all carry distinct parens-
//               preserved slugs and resolve through the canonical
//               lookup's parens-PRESERVED first-pass. "Lissala"
//               bare resolves to the bare entry, not the (Order of
//               Virtue) variant, so HLO's bare-name emit case is
//               already correct without an override.
//             * Comma-suffix landmines. Zero PF2e background, deity,
//               heritage, or ancestry names contain a literal comma
//               (only "Srikalis, Sritaming, and Sribaril" deity has
//               commas in the name, and its slug includes them
//               verbatim, so symmetric normalizeKey matches).
//             * Diacritic/non-ASCII names. sf2e-anachronism's
//               "Crèche Born" background normalizes both name and
//               slug to "cr-che-born" symmetrically, so the lookup
//               matches without an override.
//             * "(BB)" Beginner Box heritages. "Battle-Trained
//               Human (BB)" and "Warden Human (BB)" resolve through
//               the parens-preserved pass when HLO emits with the
//               suffix. The bare-name case is undefined behaviour
//               (no bare equivalent ships) and would simply miss.
// Revision: 0.6.5
//           - PF2e action-pack audit (actions, reactions, free
//             actions, exploration actions, downtime actions),
//             plus effects and conditions, against the 2026-05-16
//             V14 pack-index dumps (pf2e v8.1.2). Findings, all
//             verified, no overrides added:
//             * All five PF2e action categories live in a SINGLE
//               compendium pack, pf2e.actionspf2e (390+135+54+54+22
//               entries; the per-category split in the log file
//               names is a logger convenience, not a Foundry pack
//               boundary). The Action and Ability compsets already
//               route to actionspf2e in matcher-slug-table.js so
//               every "Treat Wounds", "Aid", "Avoid Notice",
//               "Liberating Step", "Earn Income" etc. resolves via
//               the deterministic pack-index lookup. No DC variants
//               exist in Foundry action names (zero hits for "DC"
//               in the name across all five logs); only "Dragon
//               Breath (Dragon Form)" carries a parenthetical, and
//               the parens-preserved try in lookupCanonical handles
//               that family if HLO ever emits it.
//             * HLO does NOT emit a Condition or Effect compset.
//               Verified against both fixtures (noxora SF2e
//               operative, synthetic PF2e fighter): the observed
//               compset set is {AbilScore, Ability, Action,
//               Ammunition, Ancestry, Armor, ArmorClass,
//               ArmorTrait, Augmentation, Class, Deity, Derived,
//               Feat, GearBasic, Heritage, Language, Movement,
//               NaturalWep, Reserves, Save, Skill, Spell, Trait,
//               Upgrade, Weapon, WeaponTrait}. Conditions are
//               actor state (system.attributes / token effects)
//               applied by the system at runtime; effects are
//               runtime artifacts attached by macros or rule
//               elements. Neither belongs in the SKIP_BY_DESIGN
//               set, because no `Condition:*` or `Effect:*` key
//               can be produced by parser-items. If HLO ever
//               starts emitting them, parser-items will surface
//               an `unknown-compset` warning, which is the right
//               alarm. Pre-empting that with a speculative skip
//               would mask the signal, contrary to the standing
//               rule in this file's header against speculative
//               entries.
//             * Cross-checked condition names (43 entries) against
//               action-pack names (655 entries combined): zero
//               collisions. There is no name HLO could emit that
//               would simultaneously match an action and a
//               condition, so no disambiguation is needed.
//             * Footnote (out of scope for this audit but noted
//               for follow-up): the action-cost decoder in
//               parser-compset-feats.js still uses the legacy
//               short-form codes (A/AA/AAA/R/F) while real HLO
//               payloads emit Action1/Action2/Action3/Reaction/
//               FreeAction. This only affects the displayed cost
//               glyph, not pack-matching, so it does not change
//               the audit conclusion.
// Revision: 0.6.4
//           - PF2e cantrips + L1-3 spell audit (pack-index dumps
//             from 2026-05-16, pf2e v8.1.2, V14: 129 cantrips +
//             1018 L1-3 spells across pf2e.spells-srd and
//             sf2e-anachronism.spells). Parallel finding to 0.6.3
//             for the L4-10 tiers: pf2e v8.1.2 ships only the
//             Remaster slug and name for every legacy spell name
//             below; both the pre-Remaster slug and the pre-
//             Remaster name are ABSENT from the current dump.
//             Added Remaster aliases (name + HLO id slug) for:
//               Magic Missile        -> force-barrage      (L1)
//               True Strike          -> sure-strike        (L1)
//               Magic Weapon         -> runic-weapon       (L1)
//               Magic Armor          -> runic-body         (L1)
//               Magic Fang           -> runic-body         (L1)
//               Hideous Laughter     -> laughing-fit       (L2)
//               Touch of Idiocy      -> stupefy            (L2)
//               Endure Elements      -> endure             (L1)
//               Continual Flame      -> everlight          (L2)
//               Comprehend Language  -> translate          (L2)
//               Tongues              -> translate          (L2)
//               See Invisibility     -> see-the-unseen     (L2)
//               Glitterdust          -> revealing-light    (L2)
//               Searing Light        -> holy-light         (L3)
//               Disrupt Undead       -> vitality-lash      (L1)
//               Flaming Sphere       -> floating-flame     (L2)
//             Other audit observations (no override needed):
//             * 59 spell names with possessive apostrophes
//               (Frost's Touch, Shadow's Web, Hunter's Luck,
//               etc.) all canonicalise by dropping the apostrophe
//               and match through the pack-index's symmetric
//               normalizeKey from both name and slug sides.
//             * "Deja Vu" (only non-ASCII spell name in the L1-3
//               slice) resolves via normalizeKey's symmetric
//               stripping: name "Deja Vu" and canonical slug
//               "deja-vu" both normalize to d-j-vu and match
//               exactly. The free-standing slugifyName helper
//               would mangle it in isolation, but the matcher
//               compares normalizeKey to normalizeKey.
//             * No L1-3 spell names contain parentheticals,
//               colons, commas, or semicolons.
//             * No cross-pack name collisions between
//               pf2e.spells-srd and sf2e-anachronism.spells.
//             * Focus spells that share a name with a standard
//               spell also share pack and slug, so the existing
//               Spell route resolves both without disambiguation.
//             Existing PF2e Spell overrides (Catacylsm,
//             Shadow's Web typos) cover real higher-level spells
//             outside the L1-3 slice and remain correct.
// Revision: 0.6.3
//           - PF2e mid-to-high level spell audit (pack-index dumps
//             from 2026-05-16, pf2e v8.1.2, levels 4-6 + 7-9 + 10,
//             1216 entries across pf2e.spells-srd and
//             sf2e-anachronism.spells). Added Remaster renames
//             where HLO still emits the legacy display name but
//             pf2e.spells-srd ships only the renamed entry:
//               Wail of the Banshee -> wails-of-the-damned (L9)
//               Time Stop           -> freeze-time          (L10)
//               Mind Blank          -> hidden-mind          (L8)
//               Plane Shift         -> interplanar-teleport (L7)
//               Flesh to Stone      -> petrify              (L6)
//               True Sight          -> truesight            (L6)
//             Each legacy slug is absent from the dump and each
//             remaster slug is present and unique. Cloudkill,
//             Horrid Wilting, Feeblemind, and Finger of Death have
//             no obvious remaster replacement in the current pack
//             and remain without an override so future drift can
//             still be detected as a miss. Apostrophe spells in
//             these tiers (Hero's Defiance, Jassim's Allegiance,
//             Garden of the Green Man's Growth, Deity's Strike,
//             Love's Sacrifice, Medusa's Wrath, Nature's Enmity,
//             Ocean's Roar, Mariner's Curse, etc.) all canonicalize
//             via slugifyName's apostrophe strip ('s -> s) and need
//             no override; verified by comparing every pack slug to
//             slugifyName(name). No ritual-trait entries appear in
//             spells-srd; rituals live in pf2e.rituals and route
//             through that pack instead.
// Revision: 0.6.2
//           - PF2e class-features audit (pack-index dump from
//             2026-05-16, pf2e v8.1.2, V14, 841 entries in
//             pf2e.classfeatures). Cross-checked every Class-
//             compset promotion in OVERRIDES against the live
//             pack-index. Findings:
//             * Champion sanctifications (liberation, redemption,
//               justice, desecration, iniquity, obedience,
//               grandeur) ship as class-features tagged `champion`,
//               not as standalone `clX` class IDs. The six
//               subclass IDs HLO emits (clLiberator, clRedeemer,
//               clPaladin, clAntipaladin, clTyrant, clDesecrator)
//               are correctly redirected to the parent `champion`
//               class. The sanctification class-feature itself
//               reaches the canonical pack-index via the
//               Feat/Ability compset and resolves without an
//               override.
//             * Alchemist research fields (bomber, chirurgeon,
//               mutagenist, toxicologist) ship as level-1 class-
//               features, AND each progression beat (Field
//               Discovery L5, Advanced Vials L11, Perpetual
//               Infusions L7, Perpetual Potency L11, Perpetual
//               Perfection L17, Greater Field Discovery L13) ships
//               in two flavours: a generic base entry and four
//               subclass-suffixed entries (field-discovery-bomber,
//               field-discovery-chirurgeon, etc). HLO's
//               parenthetical display name "Field Discovery
//               (Bomber)" normalizes to "field-discovery" via the
//               pack-index normalizeKey (parens-stripped) AND
//               preserves the suffix form "field-discovery-bomber"
//               via slugCandidates, so both reach valid entries
//               without an override.
//             * Rogue rackets (thief, ruffian, scoundrel,
//               mastermind, eldritch-trickster) ship as class-
//               features tagged `rogue`. OVERRIDES correctly
//               promotes the five HLO subclass-as-class IDs to
//               the parent `rogue` class.
//             * Investigator methodologies ship as
//               `*-methodology` class-features (alchemical-
//               sciences-methodology, empiricism-methodology,
//               forensic-medicine-methodology, interrogation-
//               methodology). HLO's legacy `clEmpiricism`
//               redirects to `investigator` via OVERRIDES; the
//               methodology class-feature itself resolves
//               canonically.
//             No new OVERRIDES required. Existing Class-compset
//             entries verified correct against the 2026-05-16
//             dump.
// Revision: 0.6.1
//           - SF2e Class + Class Features + Class Feats audit
//             (pack-index dumps from 2026-05-16, sf2e v1.1.2 +
//             pf2e-anachronism v2.1.0: 6 SF2e classes, 119 SF2e
//             class-features, 340 SF2e feats + 4033 anachronism
//             feats reachable via the Feat compset fallback).
//             Findings:
//             * sf2e.class-features: zero slugifyName mismatches
//               across all 119 entries. Operative specializations
//               (Striker, Skirmisher, Sniper, Infiltrator, Ghost)
//               and Mystic Connections / Solarian Manifestations
//               resolve through the existing Ability ->
//               class-features routing plus name fallback. The
//               HLO Ability ids decamelize with the Operative
//               suffix attached (abInfiltratorOpr ->
//               infiltrator-opr) which misses, but the name
//               "Infiltrator" slugifies to "infiltrator" and
//               hits the class-features pack on the second
//               candidate. Verified against the Noxora fixture.
//             * sf2e.feats: one canonical-slug normalization edge
//               case. "AbadarCorp Rep Dedication" packs as
//               abadar-corp-rep-dedication (CamelHumps split into
//               kebab on AbadarCorp), but slugifyName collapses
//               CamelHumps and produces abadarcorp-rep-dedication
//               instead. Added a name-keyed Feat override below.
//               All other 339 sf2e.feats entries (including the
//               32 punctuation-bearing names like "Bring it On!"
//               and "Iomedae's Sword") slugify cleanly to their
//               canonical pack slug.
//             * sf2e.classes: ships Envoy, Mystic, Operative,
//               Solarian, Soldier, Witchwarper in v1.1.2. HLO
//               playtest classes (clTechnomancer, clMechanic,
//               clVanguard) are in system-detection.SF2E_CLASS_
//               SLUGS for system inference but have no compendium
//               entry yet. Deliberately not skipped: the user
//               picked a real class, so surfacing the miss in the
//               conversion log is correct until sf2e ships them.
// Revision: 0.6.0
//           - PF2e ancestry-feats audit. Added name-keyed Feat
//             overrides for the 23 parenthetical heritage variants
//             in the 2026-05-16 V14 pf2e ancestry-feats index dump
//             (Tusks (Orc), Tree Climber (Goblin), Eternal Wings
//             (Sylph), Trample (Centaur), etc). These complement
//             the matcher-pack-index 0.3.0 parens-preserved-first
//             normalize fix: the pack-index resolves these at
//             runtime inside Foundry, but the override table acts
//             as a fallback for any path where the live index is
//             unavailable, and provides a static, greppable record
//             of the heritage disambiguations the system relies on.
//             Verified against the index dump that each canonical
//             slug exists. No curse/blood/lineage suffix patterns
//             needed overrides (dragonblood family, accursed,
//             bloodletting all decamelize cleanly from HLO ids).
// Revision: 0.5.1
//           - SF2e spell-content audit (pack-index dumps from
//             2026-05-16, sf2e v1.1.2 + pf2e-anachronism v2.1.0,
//             1929 unique spell entries across cantrips, levels
//             1-10, focus, traditions). Confirmed Spell routing
//             includes pf2e-anachronism.spells for SF2e (the deep
//             PF2e catalog reach). Found one real
//             canonical-pack-index gap: "Anima Invocation
//             (Modified)" has the canonical slug
//             anima-invocation-modified, but normalizeKey() strips
//             parentheticals so HLO's name normalizes to
//             anima-invocation and misses. Added a name-keyed
//             OVERRIDE routed to pf2e-anachronism.spells so the
//             SF2e route resolves; PF2e characters do not see this
//             spell in their native pack so a separate PF2e entry
//             is not needed. Other diacritic / curly-quote / typo
//             patterns all resolve via the canonical pack-index's
//             symmetric normalizeKey (Deja Vu's name and slug both
//             normalize to d-j-vu; apostrophes are stripped on
//             both sides). Cataclysm and Shadow's Web overrides
//             remain PF2e-only because no SF2e occurrences are
//             observed yet; revisit if HLO emits them on an SF2e
//             character. No SF2e focus spell or cantrip naming
//             oddities found; "Focus" never appears in the
//             SF2e-native focus spell names (the focus trait
//             marks them instead).
// Revision: 0.5.0
//           - Resolved the five PF2e unmatched-modal stubs from
//             the 2026-05-16 conversion log:
//             * Ability:abResistance (Void 1, Allied Alchemical
//               Splash 10, Fire 5) -> SKIP_BY_DESIGN. Resistances
//               are numeric stats applied to
//               actor.system.attributes.resistances[], not
//               compendium items. Verified: no "Resistance" entry
//               in pf2e actions/class-features/ancestry-features
//               packs (only Enhanced/Incredible/Raging Resistance
//               class features exist, which have their own slugs).
//             * Ability:abWayfinderLight -> SKIP_BY_DESIGN. The
//               Wayfinder is a separate magic-item line
//               (slug "wayfinder" in pf2e.equipment-srd); the
//               Light activation is the cast-Light affordance
//               granted by carrying the wayfinder, parallel to
//               abEnvironProtect's relationship to the matching
//               Upgrade. The standalone "Light" cantrip is a
//               Spell, not an Ability.
//             * GearBasic:grClothingCoWe -> override to
//               equipment-srd / clothing-cold-weather. HLO names
//               the item "Clothing, winter" but PF2e stores it as
//               "Clothing (Cold-Weather)"; the HLO slug literally
//               encodes CoWe = Cold-Weather.
// Revision: 0.4.1
//           - Replaced the speculative SF2e subclass-promotion
//             placeholder with a documented finding. Verified
//             against the 2026-05-16 V14 pack-index dumps
//             (sf2e v1.1.2): all SF2e classes ship as top-level
//             entries; subclass-style slots live in class-features
//             instead, so no promotions are needed.
// Revision: 0.4.0
//           - Expanded the senses skip-list. Investigated the full
//             SF2e/PF2e SENSE_TYPES set (sf2e.mjs line 15212) and
//             cross-referenced every entry against the 2026-05-15
//             V14 pack-index dump, restricted to the packs the
//             Ability compset actually routes to (actions,
//             class-features, ancestry-features per matcher-slug-
//             table.js). Senses with NO Ability-routed entry get a
//             SKIP_BY_DESIGN line; HLO emits them as Ability slugs
//             but they live on actor.system.perception.senses and
//             are installed by the Ancestry/Heritage embed.
//             Added: abDarkvision, abEcholocation, abLifesense,
//             abBloodsense, abTremorsense, abTruesight, abScent,
//             abSpiritsense, abWavesense, abMagicsense,
//             abInfraredVision, abMotionSense, abElectromagSense,
//             abSeeInvisibility. Deliberately NOT added:
//             abGreaterDarkvision (real pf2e-anachronism.ancestry-
//             features feat) and abThoughtsense (real sf2e.ancestry-
//             features feat) -- both have canonical entries the
//             matcher should still find.
//           - 0.3.0: Added Ability:abLowLightVision to
//             SKIP_BY_DESIGN. Low-Light Vision is a sense that
//             SF2e/PF2e applies via the actor's
//             system.perception.senses field; no compendium item
//             exists in any pack (verified via the 3 MB SF2e +
//             pf2e-anachronism index dump from V14 on 2026-05-15).
//             HLO sends it as an Ability so the matcher kept
//             missing it. Skipping silently matches the system's
//             existing behaviour.
//           - 0.2.0: Wave 2 of the cog migration. Promoted from
//             src/matcher/overrides.js. No logic changes; only the
//             file location and header are new.
//           - 0.1.0: Phase 1 (in src/matcher/). Curated overrides
//             for the known-mismatch landmines, sourced from
//             zarmstrong's 134-version changelog (compiled in
//             ARCHITECTURE section 12) plus anything we accumulate
//             over time.
//
// Each entry is keyed by `${compset}:${hloSlugOrName}` and maps to either a
// concrete Foundry reference `{ pack, slug }` or a redirect `{ remapTo:
// "<other-hlo-slug>" }` that re-runs the matcher against the corrected slug.
// Keep redirects shallow (one hop) to avoid loops.

// Adding new overrides:
//   1. Try `npm run parse:noxora` (or run the import in Foundry) to see
//      which HLO slug or name the matcher missed.
//   2. Identify the canonical Foundry slug by searching the compendium.
//   3. Add an entry below keyed by `${compset}:${hloSlugOrName}`.
//   4. Slug-keyed entries fire on the parser's id-derived slug; name-keyed
//      entries fire on the raw HLO display name.
//
// Keep entries focused on real, observed mismatches. Speculative entries
// pollute the table and can mask real issues if HLO later adds the content
// under a different slug than we predicted.

export const OVERRIDES = new Map([
  // ---------- PF2e Class subclass promotions ----------
  // Champion subclasses that HLO exports as standalone class IDs but PF2e
  // Foundry stores under the parent "champion" class.
  ["Class:clLiberator",   { pack: "classes", slug: "champion" }],
  ["Class:clRedeemer",    { pack: "classes", slug: "champion" }],
  ["Class:clPaladin",     { pack: "classes", slug: "champion" }],
  ["Class:clAntipaladin", { pack: "classes", slug: "champion" }],
  ["Class:clTyrant",      { pack: "classes", slug: "champion" }],
  ["Class:clDesecrator",  { pack: "classes", slug: "champion" }],

  // Alchemist research fields exported as classes; promote to parent.
  ["Class:clMutagenist",     { pack: "classes", slug: "alchemist" }],
  ["Class:clBomber",         { pack: "classes", slug: "alchemist" }],
  ["Class:clToxicologist",   { pack: "classes", slug: "alchemist" }],
  ["Class:clChirurgeon",     { pack: "classes", slug: "alchemist" }],

  // Rogue rackets to parent.
  ["Class:clThief",             { pack: "classes", slug: "rogue" }],
  ["Class:clRuffian",           { pack: "classes", slug: "rogue" }],
  ["Class:clMastermind",        { pack: "classes", slug: "rogue" }],
  ["Class:clScoundrel",         { pack: "classes", slug: "rogue" }],
  ["Class:clEldritchTrickster", { pack: "classes", slug: "rogue" }],

  // Investigator methodologies (legacy Empiricism).
  ["Class:clEmpiricism",  { pack: "classes", slug: "investigator" }],

  // ---------- PF2e Feat name overrides (from zarmstrong's changelog) ----------
  // Pack name is "feats-srd" in PF2e (not "feats", which is the SF2e pack).
  //
  // 0.6.8: Feat:Fencer is intentionally absent. The Remaster removed Fencer
  // Style entirely (verified 2026-05-16: zero hits on "fencer" across the
  // 4373-entry pf2e.class-feats pack dump). Leaving the legacy override in
  // place would silently route to a non-existent slug. Surface the miss
  // instead so HLO-side data can be re-checked when this name appears.
  ["Feat:Known Weakness",                   { pack: "feats-srd", slug: "known-weaknesses" }],
  ["Feat:Infinite Possilbilites",           { pack: "feats-srd", slug: "infinite-possibilities" }],
  // 0.6.8: Remaster split Hellknight Signifier Dedication into two feats:
  // "Hellknight Dedication" (the entry slot) and "Hellknight Signifer
  // Preferment" (the level-6 progression). The HLO display name is preserved
  // for back-compat but now points at the dedication slot, which is the
  // closest non-empty target. Verified 2026-05-16 against the live class-
  // feats dump: hellknight-signifer-dedication is ABSENT, hellknight-
  // dedication is PRESENT, hellknight-signifer-preferment is PRESENT.
  ["Feat:Hellknight Signifier Dedication",  { pack: "feats-srd", slug: "hellknight-dedication" }],
  ["Feat:Hellknight Signifier Preferment",  { pack: "feats-srd", slug: "hellknight-signifer-preferment" }],

  // ---------- PF2e Spell name overrides ----------
  // Pack name is "spells-srd" in PF2e (not "spells", which is the SF2e pack).
  ["Spell:Catacylsm",      { pack: "spells-srd", slug: "cataclysm" }],
  ["Spell:Shadows's Web",  { pack: "spells-srd", slug: "shadows-web" }],
  ["Spell:Shadow's Web",   { pack: "spells-srd", slug: "shadows-web" }],

  // ---------- PF2e Remaster spell renames (L4-L10) ----------
  // HLO retains the pre-Remaster display names for these six spells but
  // pf2e v8.1.2's spells-srd pack ships only the renamed entry. Verified
  // against the 2026-05-16 V14 pack-index dumps for spell-levels-4-6,
  // 7-9, and 10: each legacy slug below is ABSENT and each target slug
  // is PRESENT and unique. Both slug-keyed (spLegacyId) and name-keyed
  // forms are registered so the override catches whichever HLO emits.
  ["Spell:Wail of the Banshee", { pack: "spells-srd", slug: "wails-of-the-damned" }],
  ["Spell:spWailOfTheBanshee",  { pack: "spells-srd", slug: "wails-of-the-damned" }],
  ["Spell:Time Stop",           { pack: "spells-srd", slug: "freeze-time" }],
  ["Spell:spTimeStop",          { pack: "spells-srd", slug: "freeze-time" }],
  ["Spell:Mind Blank",          { pack: "spells-srd", slug: "hidden-mind" }],
  ["Spell:spMindBlank",         { pack: "spells-srd", slug: "hidden-mind" }],
  ["Spell:Plane Shift",         { pack: "spells-srd", slug: "interplanar-teleport" }],
  ["Spell:spPlaneShift",        { pack: "spells-srd", slug: "interplanar-teleport" }],
  ["Spell:Flesh to Stone",      { pack: "spells-srd", slug: "petrify" }],
  ["Spell:spFleshToStone",      { pack: "spells-srd", slug: "petrify" }],
  ["Spell:True Sight",          { pack: "spells-srd", slug: "truesight" }],
  ["Spell:spTrueSight",         { pack: "spells-srd", slug: "truesight" }],

  // ---------- PF2e Remaster spell renames (cantrips + L1-3) ----------
  // Parallel finding to the L4-L10 block above: pf2e v8.1.2's spells-srd
  // ships only the Remaster name and slug for each of these spells, with
  // the pre-Remaster slug and name both ABSENT from the dump. Verified
  // against the 2026-05-16 V14 pack-index dumps for cantrips and
  // spell-levels-1-3. Every legacy name below was checked: zero hits on
  // both name and slug across pf2e.spells-srd and sf2e-anachronism.spells.
  // Every target slug was confirmed PRESENT and unique in pf2e.spells-srd.
  // Both name-keyed and HLO-id slug-keyed forms are registered so the
  // override catches whichever the parser emits.
  //
  // Note on "Magic Fang": the pre-Remaster Magic Fang was the focus spell
  // that became Runic Body in the L1 focus list. If HLO ever emits it as
  // a Spell line (some legacy importers do), this routes it correctly.
  // Note on "Tongues" and "Comprehend Language": both pre-Remaster names
  // collapse to Translate in pf2e v8.1.2.
  ["Spell:Magic Missile",        { pack: "spells-srd", slug: "force-barrage" }],
  ["Spell:spMagicMissile",       { pack: "spells-srd", slug: "force-barrage" }],
  ["Spell:True Strike",          { pack: "spells-srd", slug: "sure-strike" }],
  ["Spell:spTrueStrike",         { pack: "spells-srd", slug: "sure-strike" }],
  ["Spell:Magic Weapon",         { pack: "spells-srd", slug: "runic-weapon" }],
  ["Spell:spMagicWeapon",        { pack: "spells-srd", slug: "runic-weapon" }],
  ["Spell:Magic Armor",          { pack: "spells-srd", slug: "runic-body" }],
  ["Spell:spMagicArmor",         { pack: "spells-srd", slug: "runic-body" }],
  ["Spell:Magic Fang",           { pack: "spells-srd", slug: "runic-body" }],
  ["Spell:spMagicFang",          { pack: "spells-srd", slug: "runic-body" }],
  ["Spell:Hideous Laughter",     { pack: "spells-srd", slug: "laughing-fit" }],
  ["Spell:spHideousLaughter",    { pack: "spells-srd", slug: "laughing-fit" }],
  ["Spell:Touch of Idiocy",      { pack: "spells-srd", slug: "stupefy" }],
  ["Spell:spTouchOfIdiocy",      { pack: "spells-srd", slug: "stupefy" }],
  ["Spell:Endure Elements",      { pack: "spells-srd", slug: "endure" }],
  ["Spell:spEndureElements",     { pack: "spells-srd", slug: "endure" }],
  ["Spell:Continual Flame",      { pack: "spells-srd", slug: "everlight" }],
  ["Spell:spContinualFlame",     { pack: "spells-srd", slug: "everlight" }],
  ["Spell:Comprehend Language",  { pack: "spells-srd", slug: "translate" }],
  ["Spell:spComprehendLanguage", { pack: "spells-srd", slug: "translate" }],
  ["Spell:Tongues",              { pack: "spells-srd", slug: "translate" }],
  ["Spell:spTongues",            { pack: "spells-srd", slug: "translate" }],
  ["Spell:See Invisibility",     { pack: "spells-srd", slug: "see-the-unseen" }],
  ["Spell:spSeeInvisibility",    { pack: "spells-srd", slug: "see-the-unseen" }],
  ["Spell:Glitterdust",          { pack: "spells-srd", slug: "revealing-light" }],
  ["Spell:spGlitterdust",        { pack: "spells-srd", slug: "revealing-light" }],
  ["Spell:Searing Light",        { pack: "spells-srd", slug: "holy-light" }],
  ["Spell:spSearingLight",       { pack: "spells-srd", slug: "holy-light" }],
  ["Spell:Disrupt Undead",       { pack: "spells-srd", slug: "vitality-lash" }],
  ["Spell:spDisruptUndead",      { pack: "spells-srd", slug: "vitality-lash" }],
  ["Spell:Flaming Sphere",       { pack: "spells-srd", slug: "floating-flame" }],
  ["Spell:spFlamingSphere",      { pack: "spells-srd", slug: "floating-flame" }],

  // 0.6.10: Scorching Ray was retained but renamed to the plural
  // "Scorching Rays" in pf2e v8.1.2 (Remaster pluralization, same
  // family as Wails of the Damned and Force Barrage above). Both the
  // pre-Remaster name and the legacy id slug are absent from the live
  // pf2e.spells-srd; the renamed slug "scorching-rays" is present.
  // Both key shapes registered so the override catches whichever HLO
  // emits. Source: Revascis Virholt L20 Vampire Magus import miss
  // (2026-05-16 conversion log).
  ["Spell:Scorching Ray",        { pack: "spells-srd", slug: "scorching-rays" }],
  ["Spell:spScorchingRay",       { pack: "spells-srd", slug: "scorching-rays" }],

  // ---------- PF2e GearBasic name overrides ----------
  // HLO sends "Clothing, winter" with slug grClothingCoWe; PF2e packages
  // it as "Clothing (Cold-Weather)" with slug clothing-cold-weather. The
  // HLO slug suffix "CoWe" encodes Cold-Weather, confirming the mapping.
  ["GearBasic:grClothingCoWe", { pack: "equipment-srd", slug: "clothing-cold-weather" }],

  // ---------- PF2e Wand canonical-name fallback (Bug 2, v0.7.1) ----------
  // Berial PFS's "Wand of cozy cabin" (compset Wand, slug waWand) returned
  // a null match in the v0.7.0 import and disappeared with no warn line
  // and no actor item: the canonical pack-index lookup found no Wand entry
  // under that name, and the per-item miss log + unmatched modal both
  // gated on COMPENDIUM_COMPSETS which did not list Wand. This override
  // is the static fallback for the canonical "wand-of-<spell-slug>"
  // pattern that PF2e equipment-srd uses for every magic wand
  // (verified via parser-compset-wand.js header: wand-of-cozy-cabin,
  // wand-of-fireball, wand-of-mage-armor, etc.). Name-keyed because
  // HLO's slug ("waWand") collapses to "wand" and carries no spell-
  // specific information; the display name is the only place the
  // spell identity is encoded. Both the HLO sentence-case form and
  // the Foundry title-case form are registered so the override
  // catches whichever the parser emits.
  ["Wand:Wand of cozy cabin", { pack: "equipment-srd", slug: "wand-of-cozy-cabin" }],
  ["Wand:Wand of Cozy Cabin", { pack: "equipment-srd", slug: "wand-of-cozy-cabin" }],

  // ---------- SF2e Spell name overrides ----------
  // SF2e characters reach this entry via pf2e-anachronism.spells (the
  // deep PF2e spell catalog). The canonical pack-index normalizeKey()
  // strips parentheticals, so HLO's display name "Anima Invocation
  // (Modified)" normalizes to "anima-invocation" while the pack entry's
  // slug normalizes to "anima-invocation-modified". The keys do not
  // match and the canonical lookup misses. A name-keyed OVERRIDE routed
  // to the already-namespaced pf2e-anachronism.spells pack catches the
  // call after the canonical miss. No equivalent PF2e-native entry
  // exists (the spell ships only in the anachronism module), so a PF2e
  // override row is not needed.
  ["Spell:Anima Invocation (Modified)", { pack: "pf2e-anachronism.spells", slug: "anima-invocation-modified" }],

  // ---------- SF2e Feat: CamelHumps name normalization ----------
  // "AbadarCorp Rep Dedication" packs as abadar-corp-rep-dedication (sf2e
  // v1.1.2 splits CamelHumps on the AbadarCorp brand name). slugifyName
  // collapses CamelHumps because it lowercases before splitting, producing
  // abadarcorp-rep-dedication, which misses. Name-keyed so it fires after
  // the canonical lookup, regardless of HLO id shape.
  ["Feat:AbadarCorp Rep Dedication", { pack: "feats", slug: "abadar-corp-rep-dedication" }],

  // ---------- Ancestry-feats: parenthetical heritage variants ----------
  // Each pair below collides on the canonical pack-index's parens-stripped
  // name key (e.g. "Tusks (Orc)" and "Tusks (Half-Orc)" both normalize to
  // "tusks", and registerKey is first-wins). matcher-pack-index 0.3.0 now
  // tries a parens-PRESERVED normalize first to resolve these correctly;
  // these overrides are the static fallback. Keyed by HLO display name
  // (raw, parens intact). Pack is pf2e.feats-srd for 19 of the 23
  // entries; four SF2e-native variants (Ancestral Weapon Familiarity
  // (Astrazoan), Bioluminescence (Shirren), Gooey Engulf (Entu), Hang
  // in There (Nu)Friend!) live in sf2e.feats and use the already-
  // namespaced sf2e-anachronism.feats pack so PF2e characters pulling
  // SF2e content resolve them correctly through the fallback. Verified
  // against the 2026-05-16 V14 ancestry-feats dumps (pf2e v8.1.2 +
  // sf2e v1.1.2 + sf2e-anachronism v2.1.0).
  // Four SF2e-native entries below use the already-namespaced
  // sf2e-anachronism.feats pack because their canonical content lives
  // in sf2e.feats; the override fallback fires only on PF2e characters
  // pulling SF2e content (where the routed packs include
  // sf2e-anachronism.feats). SF2e characters resolve these natively
  // via the parens-preserved canonical pack-index key.
  ["Feat:Ancestral Weapon Familiarity (Astrazoan)", { pack: "sf2e-anachronism.feats", slug: "ancestral-weapon-familiarity-astrazoan" }],
  ["Feat:Bioluminescence (Shirren)",                { pack: "sf2e-anachronism.feats", slug: "bioluminescence-shirren" }],
  ["Feat:Blessed Blood (Nephilim)",                 { pack: "feats-srd", slug: "blessed-blood-nephilim" }],
  ["Feat:Breath of the Dragon (Dragonblood)",       { pack: "feats-srd", slug: "breath-of-the-dragon-dragonblood" }],
  ["Feat:Dangle (Vanara)",                          { pack: "feats-srd", slug: "dangle-vanara" }],
  ["Feat:Eternal Wings (Nephilim)",                 { pack: "feats-srd", slug: "eternal-wings-nephilim" }],
  ["Feat:Eternal Wings (Sylph)",                    { pack: "feats-srd", slug: "eternal-wings-sylph" }],
  ["Feat:Gooey Engulf (Entu)",                      { pack: "sf2e-anachronism.feats", slug: "gooey-engulf-entu" }],
  ["Feat:Hang in There (Nu)Friend!",                { pack: "sf2e-anachronism.feats", slug: "hang-in-there-nu-friend" }],
  ["Feat:Incredible Luck (Halfling)",               { pack: "feats-srd", slug: "incredible-luck-halfling" }],
  ["Feat:Inner Fire (Naari)",                       { pack: "feats-srd", slug: "inner-fire-naari" }],
  ["Feat:Irrepressible (Halfling)",                 { pack: "feats-srd", slug: "irrepressible-halfling" }],
  ["Feat:Irrepressible (Nephilim)",                 { pack: "feats-srd", slug: "irrepressible-nephilim" }],
  ["Feat:Many Guises (Kitsune)",                    { pack: "feats-srd", slug: "many-guises-kitsune" }],
  ["Feat:Quick Stow (Ratfolk)",                     { pack: "feats-srd", slug: "quick-stow-ratfolk" }],
  ["Feat:Shared Luck (Halfling)",                   { pack: "feats-srd", slug: "shared-luck-halfling" }],
  ["Feat:Startling Appearance (Fleshwarp)",         { pack: "feats-srd", slug: "startling-appearance-fleshwarp" }],
  ["Feat:Trample (Centaur)",                        { pack: "feats-srd", slug: "trample-centaur" }],
  ["Feat:Trample (Sarangay)",                       { pack: "feats-srd", slug: "trample-sarangay" }],
  ["Feat:Tree Climber (Elf)",                       { pack: "feats-srd", slug: "tree-climber-elf" }],
  ["Feat:Tree Climber (Goblin)",                    { pack: "feats-srd", slug: "tree-climber-goblin" }],
  ["Feat:Tusks (Half-Orc)",                         { pack: "feats-srd", slug: "tusks-half-orc" }],
  ["Feat:Tusks (Orc)",                              { pack: "feats-srd", slug: "tusks-orc" }],

  // ---------- PF2e Armor: Elven Chain grade default ----------
  // Verified against the 2026-05-16 V14 pf2e.equipment-srd index dump
  // (201 armor entries): there is NO plain "elven-chain" slug. The pack
  // ships two grade variants, "elven-chain-standard-grade" and
  // "elven-chain-high-grade", expressed in display name as "Elven Chain
  // (Standard-Grade)" and "Elven Chain (High-Grade)". HLO often emits
  // the bare name "Elven Chain" on legacy character sheets that
  // pre-date the grade split. Default the bare name to the standard-
  // grade entry; the high-grade variant resolves through the
  // parens-folding pass in slugCandidates step 3.5 when HLO supplies
  // the tier explicitly.
  ["Armor:Elven Chain", { pack: "equipment-srd", slug: "elven-chain-standard-grade" }],

  // ---------- PF2e Heritage Remaster aliases ----------
  // HLO retains the pre-Remaster heritage names for the half-ancestry
  // and planar-touched pairs that pf2e v8.1.2 has consolidated. Each
  // legacy name below is ABSENT from the 2026-05-16 V14 pf2e.heritages
  // index dump; each target slug is PRESENT and unique. Both name-keyed
  // and HLO-id-keyed forms are registered so the override fires
  // regardless of whether HLO emits the legacy display name or the
  // legacy id slug. The HLO id convention for Heritage is `hr*`
  // (Heritage compset prefix per matcher-slug-table.js).
  //
  //   Half-Elf  -> aiuvarin  (post-Remaster half-elf heritage)
  //   Half-Orc  -> dromaar   (post-Remaster half-orc heritage)
  //   Aasimar   -> nephilim  (Aasimar and Tiefling consolidated)
  //   Tiefling  -> nephilim  (into a single nephilim heritage)
  ["Heritage:Half-Elf",   { pack: "heritages", slug: "aiuvarin" }],
  ["Heritage:hrHalfElf",  { pack: "heritages", slug: "aiuvarin" }],
  ["Heritage:Half-Orc",   { pack: "heritages", slug: "dromaar" }],
  ["Heritage:hrHalfOrc",  { pack: "heritages", slug: "dromaar" }],
  ["Heritage:Aasimar",    { pack: "heritages", slug: "nephilim" }],
  ["Heritage:hrAasimar",  { pack: "heritages", slug: "nephilim" }],
  ["Heritage:Tiefling",   { pack: "heritages", slug: "nephilim" }],
  ["Heritage:hrTiefling", { pack: "heritages", slug: "nephilim" }],

  // ---------- PF2e Ancestry Remaster aliases ----------
  // The 2026-05-16 V14 pf2e.ancestries dump ships Kholo (the post-
  // Remaster gnoll). Legacy "Gnoll" name and `anGnoll` slug are both
  // ABSENT. HLO may retain the pre-Remaster id on legacy character
  // sheets; route both forms to the kholo entry. Other Remaster name
  // changes audited (goblin, kobold, orc, human, dwarf, elf, leshy,
  // halfling, hobgoblin) are all unchanged in the dump.
  ["Ancestry:Gnoll",   { pack: "ancestries", slug: "kholo" }],
  ["Ancestry:anGnoll", { pack: "ancestries", slug: "kholo" }],

  // ---------- SF2e Class subclass promotions ----------
  // None known. Verified against the 2026-05-16 V14 pack-index dumps
  // (sf2e v1.1.2, 33 classes + 119 class-features): every SF2e class
  // ships as a top-level entry in sf2e.classes (Mystic, Witchwarper,
  // Operative, Solarian, Soldier, Envoy, etc). Subclass slots that
  // PF2e packs alongside a parent class (Champion-Liberator,
  // Alchemist-Mutagenist, Rogue-Thief) appear in SF2e only as
  // class-features (e.g. Mystic Bond, Connection, Solarian Mastery)
  // rather than separate class IDs that need promotion. Add entries
  // here only if HLO is observed emitting an SF2e subclass-style
  // standalone class ID that the matcher cannot resolve canonically.
]);

/**
 * v0.6.6: items HLO sends that are NOT compendium-eligible and should
 * be silently skipped rather than logged as unmatched. Keyed by
 * `${compset}:${hloSlug}`. Two categories:
 *
 *   1. System-auto-granted (NaturalWep:nwFist): every character has an
 *      auto-derived unarmed strike via SF2e/PF2e's natural-attack rules;
 *      no separate compendium item exists. Embedding one would create a
 *      duplicate phantom Fist on the actor.
 *   2. Activation echoes (Ability:abEnvironProtect): the Ability is the
 *      action that activates the matching Upgrade (which DID match);
 *      it is a system-derived effect of having the upgrade equipped,
 *      not a separate item.
 *
 * The matcher checks this set BEFORE attempting compendium lookup and
 * returns a strategy="skip" record so the conversion log can note the
 * deliberate skip without flagging it as a miss.
 */
export const SKIP_BY_DESIGN = new Set([
  "NaturalWep:nwFist",
  "Ability:abEnvironProtect",

  // ---------- Numeric resistances applied to actor attributes ----------
  // HLO emits every granted resistance (Resistance to Void 1, Resistance
  // to Fire 5, Resistance to Allied Alchemical Item Splash 10, etc.) as
  // an Ability:abResistance line. PF2e stores these as numeric entries in
  // actor.system.attributes.resistances[]; no compendium item named just
  // "Resistance" exists in actions, class-features, or ancestry-features
  // (the only matches are Enhanced/Incredible/Raging Resistance class
  // features, which have their own distinct HLO slugs). All numeric and
  // typed variants collapse to the same abResistance slug, so one skip
  // entry covers every Resistance line. The actor build pass applies the
  // numeric values directly from the gameValues block.
  "Ability:abResistance",

  // ---------- Magic-item activation echoes ----------
  // Parallel to abEnvironProtect's relationship with the matching Upgrade.
  // The Wayfinder is a separate magic-item compendium entry
  // (pf2e.equipment-srd / slug "wayfinder") that HLO imports as its own
  // Gear line. abWayfinderLight is the activation Ability that lets the
  // bearer cast the Light cantrip from the wayfinder; it is not a
  // standalone item. The bare "Light" entry in PF2e is a Spell cantrip,
  // not an action or magic-item activation, so there is nothing to route
  // to. Skipping silently keeps the conversion log clean.
  "Ability:abWayfinderLight",

  // ---------- Senses delivered via actor.system.perception.senses ----------
  // The SF2e/PF2e SENSE_TYPES list (sf2e.mjs ~L15212) enumerates the
  // engine-recognised senses. HLO emits each one as an `ab*` Ability when
  // it is granted by an ancestry or heritage, but the systems do NOT have
  // compendium items for the base senses below; the Ancestry/Heritage
  // embed installs them directly into perception.senses. We verified
  // against the 2026-05-15 V14 pack-index dump that none of these slugs
  // or names exist in any Ability-routed pack (actions, class-features,
  // ancestry-features). Skipping silently keeps the conversion log clean.
  //
  // Counter-examples (NOT skipped, real compendium entries exist):
  //   abGreaterDarkvision -> pf2e-anachronism.ancestry-features (feat)
  //   abThoughtsense      -> sf2e.ancestry-features (feat)
  //
  // Range tiers (e.g. abLifesense30 vs abLifesense60) are handled at the
  // parser-id layer: HLO's id is the slug-prefix, the range lives in the
  // name. All tiers collapse to the same `ab*` slug, so one skip entry
  // covers every range.
  "Ability:abLowLightVision",
  "Ability:abDarkvision",
  "Ability:abEcholocation",
  "Ability:abLifesense",
  "Ability:abBloodsense",
  "Ability:abTremorsense",
  "Ability:abTruesight",
  "Ability:abScent",
  "Ability:abSpiritsense",
  "Ability:abWavesense",
  "Ability:abMagicsense",
  "Ability:abInfraredVision",
  "Ability:abMotionSense",
  "Ability:abElectromagSense",
  "Ability:abSeeInvisibility",

  // ---------- Vampire Dedication auto-grant chain (undead trait blocks) ----------
  // 0.6.10: pf2e v8.1.2's Vampire Dedication feat
  // (pf2e.feats-srd/vampire-dedication, source I5hzE0XT2BsjatS3)
  // carries flags.pf2e.itemGrants for basicUndeadBenefits,
  // revulsion, sunlight, and drinkBlood. basicUndeadBenefits is the
  // umbrella ancestry-feature (pf2e.ancestryfeatures/basic-undead-benefits,
  // source SAbzItAI4uwbdnQk) whose descriptive text delivers Disease
  // and Poison Protection, Immunity to Death Effects, Paralysis and
  // Sleep Protection, Undead Hunger, Void Healing, and Void Survival.
  // None of those benefit blocks ship as their own compendium item;
  // they are description-only sub-sections of the parent feature.
  // HLO emits each as its own Ability:ab* line. Skipping at the
  // matcher prevents duplicate items on the imported actor while
  // keeping the conversion log clean. Verified against the Revascis
  // Virholt Foundry actor export (KaT3cE0L5xkQAGur, 2026-05-16).
  "Ability:abDisPoisProtUnd",
  "Ability:abImmuneDeathUnd",
  "Ability:abParaSleepProUnd",
  "Ability:abSunlightVulnVam",
  "Ability:abUndeadHungerUnd",
  "Ability:abVoidHealing",
  "Ability:abVoidSurvival",

  // 0.6.10: Action:abArcCascadeMag with HLO name "Arcane Cascade +1"
  // is the activation-tier echo of the Magus class chain's auto-
  // installed Arcane Cascade. The Magus class entry (clMagus) embeds
  // Hybrid Study, which grants both the Arcane Cascade class-feature
  // (Compendium.pf2e.classfeatures.Item.09iL38CZZEa0q0Mt) and the
  // matching Action (Compendium.pf2e.actionspf2e.Item.HbejhIywqIufrmVM)
  // automatically. Verified against the Virholt Foundry actor export:
  // both arcane-cascade items are present on the imported actor before
  // HLO's Action line is processed. The "+1" suffix is HLO's stance-
  // bonus tier display, not a new item. Skipping prevents a duplicate
  // arcane-cascade action; the existing entry already covers the tier
  // bonus through PF2e's standard stance-effect handling.
  "Action:abArcCascadeMag",

  // ---------- Vampire Dedication auto-granted unarmed strike ----------
  // 0.6.10: NaturalWep:nwFangsGr (HLO name "Fangs") is the vampire
  // fangs unarmed strike that Vampire Dedication auto-grants on
  // acquisition. The dedication description text states "you gain a
  // fangs unarmed attack that deals 1d6 piercing damage. They're in
  // the brawling group and have the grapple and unarmed traits."
  // Verified against the Virholt Foundry actor export: the fangs
  // strike is already present under the actor's unarmed-strikes
  // block (slug "fangs", group brawling, traits unarmed+grapple)
  // before the matcher reaches this NaturalWep line. Exactly parallel
  // to the existing NaturalWep:nwFist skip for the universal Fist
  // unarmed strike. Skipping prevents a duplicate phantom fangs
  // weapon on the imported actor.
  "NaturalWep:nwFangsGr",

  // ---------- Kitsune Foxfire auto-granted unarmed strike ----------
  // v1.0.6 (public issue 2): NaturalWep:nwFoxfireKit (HLO name
  // "Foxfire") is the ranged unarmed strike the Foxfire ancestry feat
  // grants. The feat itself imports through the Feat route
  // (ftFoxfireKit -> feats-srd/foxfire) and PF2e's rule elements add
  // the strike to the actor's unarmed-strikes block, so no equipment
  // entry exists and the matcher used to report it as a miss. Same
  // pattern as nwFist and nwFangsGr.
  "NaturalWep:nwFoxfireKit",

  // ---------- Magic-item activation echoes (Vampire L20 fixtures) ----------
  // 0.6.10: parallel to the existing Ability:abWayfinderLight skip.
  // The matching MagicItem entries already resolve canonically via
  // the MagicItem route and embed correctly; these Ability lines are
  // the actions that activate the items, not separate compendium
  // items. Verified against the Revascis Virholt L20 import.
  //   abCrIntSearchMind  : "Crown of Intellect - Search Your Mind (1/hour)"
  //                        activates the Crown of Intellect MagicItem
  //                        (slug crown-of-intellect).
  //   abTatSoarWinFlyGr : "Soaring Wings, Greater - Fly (1/hour)"
  //                        activates the Greater Soaring Wings tattoo
  //                        MagicItem (slug soaring-wings-greater).
  "Ability:abCrIntSearchMind",
  "Ability:abTatSoarWinFlyGr",

  // ---------- Spellbook compset: organisational container, no Foundry item ----------
  // HLO emits Wizard (and other prepared-caster) spellbooks under the
  // "Spellbook" compset with id prefix "gr". Verified against the
  // Berial Jeggare PFS fixture (PF2e Wizard 8, 2026-05-16):
  //   grSpellbook.878  - primary spellbook, 53 nested spells
  //   grSpellbook.1356 - empty backup spellbook
  // PF2e (v8.1.2) and SF2e (v1.1.2) do NOT model the spellbook as a
  // discrete item. PF2e's ITEM_TYPES (pf2e.mjs line 3281-3306) lists
  // a "book" type, but it is a generic PhysicalItemPF2e subtype for
  // in-world tomes (BookPF2e, pf2e.mjs line 55489). The equipment-srd
  // pack ships no entry with a "spellbook" slug or bare "Spellbook"
  // name. The mechanism PF2e uses is the spellcastingEntry item,
  // auto-provisioned by the Wizard class entry's GrantItem rules
  // (the "Wizard Spellcasting" class feature). Imported Wizard actors
  // have NO item named "Spellbook" (verified against the
  // fpGhYbzcmO4HOpfF actor export, 2026-05-16). The contained spells
  // reach the actor through the standard Spell-compset pipeline;
  // anchoring them to the spellcastingEntry happens during class
  // embed.
  //
  // Both Spellbook entries on a Wizard collapse to the same slug
  // (grSpellbook), so one skip entry covers every Spellbook line
  // including backups.
  "Spellbook:grSpellbook",
]);

/**
 * Returns true if the parsed item should be skipped by design rather
 * than searched for in the compendium. The matcher consults this
 * before the canonical lookup.
 */
export function isSkipByDesign(item) {
  if (!item || !item.compset || !item.slug) return false;
  return SKIP_BY_DESIGN.has(`${item.compset}:${item.slug}`);
}

/**
 * Look up an override for a parsed item. Returns the override entry if the
 * matcher should short-circuit; null otherwise. Tries both the slug-keyed
 * form and the name-keyed form, since the legacy changelog mixes the two.
 */
export function lookupOverride(item) {
  if (!item) return null;
  const compset = item.compset;
  if (item.slug) {
    const slugHit = OVERRIDES.get(`${compset}:${item.slug}`);
    if (slugHit) return slugHit;
  }
  if (item.name) {
    const nameHit = OVERRIDES.get(`${compset}:${item.name}`);
    if (nameHit) return nameHit;
  }
  return null;
}
