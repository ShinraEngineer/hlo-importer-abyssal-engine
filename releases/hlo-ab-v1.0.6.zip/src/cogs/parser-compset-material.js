// ============================================================
// COG: parser-compset-material.js - Material normalizer
//                                   (apply-to-parent)
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-29
// Revision: 0.1.1
//           - 0.1.1: Duskwood (the Remaster name for darkwood) added to both material
//             tables (audit A14).
//           - v0.7.1: new cog for HLO's Material compset. HLO emits
//             precious-material variants for weapons and armor as
//             standalone nested items under the parent (containment
//             "Installed"), the same pattern as Rune. PF2e/SF2e
//             Foundry stores material as a field on the parent
//             item's system.material ({ type: "adamantine", grade:
//             "standard" }), not as a standalone item. Bhelroth's
//             EC fixture surfaces the only Material example in the
//             v0.7.0 corpus: mtAdamantineSt.1379 "Adamantine,
//             standard-grade (PF)" nested under wpBastardSword.1363.
//             Without this handler the Material falls through as
//             "Unknown compset" and the bastard sword imports
//             without the adamantine variant.
//
//             The handler does NOT route to a compendium pack
//             (Foundry has no separate compendium entry per material
//             variant; the matcher-slug-table.js precious-material
//             prefix-strip pass relies on the same fact). Instead it
//             emits an `_materialApplyTo` discriminator that the
//             builder layer consumes to merge into the parent's
//             material field. The Material item itself is dropped
//             from the actor's embedded-item list (see
//             STAT_BEARING_COMPSETS in builder-actor-pf2e.js).
//
//             Schema of the emitted patch:
//               _materialApplyTo: {
//                 target:        "weapon" | "armor",
//                 materialName:  string,             // canonical PF2e
//                                                    // slug ("adamantine",
//                                                    // "mithral", "cold-iron")
//                 materialGrade: "standard" | "high" | "low",
//               }
//
//             Target detection: HLO's id prefix "mt" is shared across
//             weapon and armor materials (e.g. mtAdamantineSt is used
//             for both an adamantine longsword and an adamantine
//             breastplate, distinguished only by the parent's
//             compset). Without a per-target prefix, the handler
//             defers target detection to the builder's apply-to-parent
//             merge: target=null in the patch signals "ask the parent."
//             The builder reads parent.compset to set target during
//             merge.

/**
 * Lookup table for the HLO material id suffix to the canonical PF2e
 * Foundry material slug. HLO ids encode the material plus grade in
 * the suffix:
 *   "mtAdamantineSt" -> standard adamantine
 *   "mtAdamantineHi" -> high-grade adamantine
 *   "mtMithralSt"    -> standard mithral
 *   "mtColdIronSt"   -> standard cold iron
 *   etc.
 *
 * The grade suffix follows the material name: "St" = standard,
 * "Hi" = high (also seen as "HG" in some HLO exports), "Lo" = low
 * (rare; some HLO export versions use "LG"). We accept both forms.
 *
 * Coverage: every precious material in PRECIOUS_MATERIALS in
 * matcher-slug-table.js, normalized to the kebab-case slug PF2e/SF2e
 * Foundry uses on system.material.type. The materialName slug is what
 * the PF2e/SF2e schema expects; the builder writes it verbatim.
 */
export const MATERIAL_NAME_SLUGS = {
  Adamantine:     "adamantine",
  Mithral:        "mithral",
  ColdIron:       "cold-iron",
  Orichalcum:     "orichalcum",
  Dawnsilver:     "dawnsilver",
  Darkwood:       "darkwood",
  Duskwood:       "duskwood",
  Silver:         "silver",
  Noqual:         "noqual",
  Inubrix:        "inubrix",
  Abysium:        "abysium",
  Djezet:         "djezet",
  Siccatite:      "siccatite",
  Viridium:       "viridium",
  Keleshite:      "keleshite",
  Sunsilver:      "sunsilver",
  Warpglass:      "warpglass",
  Dragonhide:     "dragonhide",
  Peachwood:      "peachwood",
  SovereignSteel: "sovereign-steel",
};

/**
 * Map of HLO grade-suffix tokens to PF2e Foundry grade values. PF2e
 * uses "low" / "standard" / "high"; HLO uses "St" (standard), "Hi"
 * (high), "Lo" (low), with "HG"/"LG" seen in some export versions.
 * The matcher returns "standard" for an unrecognized suffix so the
 * Foundry schema stays valid even when HLO ships a token we have not
 * seen.
 */
export const MATERIAL_GRADE_SUFFIXES = {
  St: "standard",
  Hi: "high",
  HG: "high",
  Lo: "low",
  LG: "low",
};

/**
 * Parse an HLO Material slug into { materialName, materialGrade }.
 * Walks the MATERIAL_NAME_SLUGS table in longest-key-first order so
 * "SovereignSteel" beats "Steel" alone (though no standalone "Steel"
 * material exists; the longest-first walk is defensive).
 *
 * Returns null if the slug does not begin with "mt" or the suffix
 * does not match any known material.
 */
export function parseMaterialSlug(slug) {
  if (!slug || typeof slug !== "string" || !slug.startsWith("mt")) return null;
  const rest = slug.slice(2);

  const keys = Object.keys(MATERIAL_NAME_SLUGS)
    .slice()
    .sort((a, b) => b.length - a.length);

  for (const key of keys) {
    if (rest.startsWith(key)) {
      const gradeKey = rest.slice(key.length);
      const grade = MATERIAL_GRADE_SUFFIXES[gradeKey] ?? "standard";
      return {
        materialName:  MATERIAL_NAME_SLUGS[key],
        materialGrade: grade,
      };
    }
  }
  return null;
}

/**
 * Name-based fallback classifier. Used when the slug context is not
 * available to the normalizer. HLO display names follow the pattern
 * "<Material>, <grade>-grade (PF)" or "<Material> (PF)".
 *
 *   "Adamantine, standard-grade (PF)" -> { name: "adamantine", grade: "standard" }
 *   "Mithral, high-grade (PF)"        -> { name: "mithral",    grade: "high" }
 *   "Cold Iron, low-grade (PF)"       -> { name: "cold-iron",  grade: "low" }
 */
export function classifyMaterialByName(name) {
  if (!name || typeof name !== "string") return null;
  const lower = name.toLowerCase().trim();

  // Try to find a known material as a prefix of the name (case-fold
  // both sides). The material names are short (one or two words);
  // walking the slug table in display-name form is enough.
  const displayMap = {
    "sovereign steel": "sovereign-steel",
    "cold iron":       "cold-iron",
    adamantine:        "adamantine",
    mithral:           "mithral",
    orichalcum:        "orichalcum",
    dawnsilver:        "dawnsilver",
    darkwood:          "darkwood",
    duskwood:          "duskwood",
    silver:            "silver",
    noqual:            "noqual",
    inubrix:           "inubrix",
    abysium:           "abysium",
    djezet:            "djezet",
    siccatite:         "siccatite",
    viridium:          "viridium",
    keleshite:         "keleshite",
    sunsilver:         "sunsilver",
    warpglass:         "warpglass",
    dragonhide:        "dragonhide",
    peachwood:         "peachwood",
  };

  let materialName = null;
  for (const [display, slug] of Object.entries(displayMap)) {
    if (lower.startsWith(display)) {
      materialName = slug;
      break;
    }
  }
  if (!materialName) return null;

  // Grade comes after the material; HLO formats as "<grade>-grade".
  let materialGrade = "standard";
  if (/\bhigh[-\s]grade\b/.test(lower)) materialGrade = "high";
  else if (/\blow[-\s]grade\b/.test(lower)) materialGrade = "low";

  return { materialName, materialGrade };
}

export const Material = {
  normalize(raw, warnings) {
    const slugHint = raw?._slug ?? null;
    const name = raw?.name ?? "";

    let parsed = parseMaterialSlug(slugHint);
    if (!parsed) {
      parsed = classifyMaterialByName(name);
    }

    if (!parsed) {
      if (Array.isArray(warnings)) {
        warnings.push({
          code: "unknown-material",
          message: `Unrecognized Material item "${name}" (slug hint: ${slugHint ?? "none"}). Foundry material not applied.`,
          context: { name, slugHint },
        });
      }
      return {};
    }

    return {
      _materialApplyTo: {
        // target is null; the builder reads parent.compset during the
        // apply-to-parent merge to decide weapon vs armor. We do not
        // try to guess here because HLO uses the same mt prefix for
        // both, and the parent linkage is authoritative.
        target:        null,
        materialName:  parsed.materialName,
        materialGrade: parsed.materialGrade,
      },
    };
  },
};

export default { id: "parser-compset-material" };
