// ============================================================
// COG: matcher-slug-table.js - HLO compset to Foundry pack map
//                              + slug-candidate generator
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-29
// Revision: 0.5.4
//           - 0.5.4: PRECIOUS_MATERIALS gains silver (listed in the 0.4.0 note but
//             never added) and the Remaster duskwood (audit A14).
//           - 0.5.3: Staff and AlchemicalItem compsets routed to the equipment packs (Staff mirrors Weapon, AlchemicalItem mirrors MagicItem) with prefixes "wp" and "ai"; Staff joins the precious-material strip set. Closes the unknown-compset drops in public issue 2.
//           - 0.5.2: slugCandidates step 3.8 resolves the elemental-ammunition family (HLO "Elemental round, lesser (infused, Cold)" -> elemental-ammunition-lesser-cold) by crossing a grade list with an element list scanned from the name.
//           - 0.5.1: v0.7.1 integration. Two new non-compendium compsets
//             added to COMPSET_TO_PACKS as null entries (Rune,
//             Material) for symmetry with COMPSET_HANDLERS. These
//             feed builder-items.js applyRuneAndMaterialPatches
//             pre-pass via _runeApplyTo / _materialApplyTo
//             discriminators, then are tagged _consumed and
//             filtered out of buildItemReferences. Two new
//             COMPSET_PREFIXES entries (Rune="ru", Material="mt").
//             Resolves the 49+ "Unknown compset Rune" warnings + 1
//             "Unknown compset Material" warning observed in
//             v0.7.0 testing across 5 PF2e characters.
//           - 0.5.0: v0.7.0 integration. Four new compendium-routed compsets
//             added to COMPSET_TO_PACKS (MagicItem, CustomArmor,
//             Wand, GearItem) and four non-compendium compsets added
//             as null entries (Spellbook, Faction, CustomReward,
//             CustomBoon) for symmetry with COMPSET_HANDLERS. Eight
//             new COMPSET_PREFIXES entries; several share prefixes
//             with existing compsets (MagicItem/GearItem/Spellbook
//             share "gr" with GearBasic; CustomArmor shares "ar"
//             with Armor) - dispatch is by compset name, not prefix
//             length, so collisions are safe. STRIPPABLE_COMPSETS
//             expanded to include MagicItem so the precious-material
//             prefix-strip pipeline also applies to magic items.
//             New slugCandidates step 3.7: baseName fallback that
//             consumes either `item.baseName` (CustomArmor.normalize
//             writes this at top level) or `item.runes?.baseName`
//             (Weapon and MagicItem normalize write this under the
//             runes object after util-rune-parser strips the rune
//             prefix). Non-destructive: full-name candidates still
//             win when they're canonical. Together these resolve
//             the 28 silently-dropped items in Berial Jeggare's
//             import (PFS Wizard 8 test fixture).
//           - 0.4.2: Documentation-only: recorded the 2026-05-16 audit
//             finding for PF2e action-pack routing. All five PF2e
//             action categories (general actions, reactions, free
//             actions, exploration actions, downtime actions) live
//             in a single compendium pack, pf2e.actionspf2e (655
//             entries combined across the V14 dumps for pf2e
//             v8.1.2; the per-category split in the log file
//             names is a logger-side classification, not a pack
//             boundary). The Action and Ability compset routings
//             below already point at actionspf2e plus its
//             sf2e-anachronism counterpart, so every "Treat Wounds"
//             (exploration), "Aid" (reaction), "Earn Income"
//             (downtime), "Liberating Step" (reaction), "Delay"
//             (free), etc. resolves through the same route. SF2e
//             mirrors this via sf2e.actions and
//             pf2e-anachronism.actions. No routing change needed.
// Revision: 0.4.1
//           - Registered the FocSpell compset. HLO emits a distinct
//             compset for focus spells (id prefix "fs", e.g.
//             fsHandApprentice for "Hand of the Apprentice"); the
//             2026-05-16 V14 import-log dump caught one falling
//             through as "Unknown compset". FocSpell routes to the
//             same spell packs as Spell (spells-srd /
//             sf2e-anachronism.spells on PF2e, spells /
//             pf2e-anachronism.spells on SF2e) because PF2e and SF2e
//             fold focus spells into the main spell pack alongside
//             cantrips and rituals (verified against the 2026-05-16
//             V14 pf2e focus-spells dump: 457 entries in
//             pf2e.spells-srd, 33 in sf2e-anachronism.spells, every
//             entry carrying the "focus" trait). Slug prefix "fs"
//             added to COMPSET_PREFIXES so hloIdToFoundrySlug strips
//             it before decamelizing. The Spell handler is reused
//             for normalization (FocSpell shares the rank/DC/save
//             schema with prepared/spontaneous spells); the only
//             routing difference is the pack search list, which is
//             identical to Spell. Spell-tradition strings (arcane,
//             divine, occult, primal) are PF2e config traits, not
//             compendium items, so no routing entry is needed for
//             traditions; the four traits are surfaced as part of
//             each focus spell's trait list and consumed by the
//             actor builder rather than the matcher.
// Revision: 0.4.0
//           - PF2e weapons + armor + shields audit (pack-index dumps
//             from 2026-05-16, pf2e v8.1.2 + sf2e-anachronism v2.1.0;
//             973 weapons / 201 armor / 118 shields / 284 attacks).
//             Added step 3.6 to slugCandidates: a precious-material
//             prefix-stripping pass for the Weapon, NaturalWep,
//             Armor, and Ammunition compsets. PF2e Foundry does not
//             ship separate compendium entries for material variants
//             (cold iron, mithral, adamantine, silver, dawnsilver,
//             orichalcum, noqual, inubrix, abysium, dragonhide,
//             sovereign steel, warpglass, djezet, peachwood, darkwood,
//             siccatite, viridium, keleshite, sunsilver); the
//             material lives on the actor item's system.material.type
//             field. HLO emits these as display names like "Cold
//             Iron Longsword" or "Mithral Chain Shirt". The new pass
//             strips a leading precious-material word from the name-
//             derived slug so the matcher can find the canonical
//             base item ("longsword", "chain-shirt"). Verified non-
//             destructive against the equipment index: the only
//             pre-existing slug that starts with one of these words
//             is "dawnsilver-tree" (a unique magic weapon), which
//             still resolves via its full name-derived slug at step
//             3 before the strip-pass fires at step 3.6.
//           - 0.3.0: PF2e equipment audit (pack-index dumps from
//             2026-05-16, pf2e v8.1.2 + sf2e-anachronism v2.1.0
//             across the seven "stuff" packs: equipment, consumables,
//             magic-items, treasure, containers, ammunition,
//             other-items).
//             Added step 3.5 to slugCandidates: when the HLO display
//             name contains a parenthetical, generate an extra
//             candidate that folds the parenthetical back in as a
//             hyphenated suffix on the base name. This is what
//             PF2e/SF2e pack slugs do for every tier and variant
//             ("Antidote (Lesser)" -> antidote-lesser, "Battery
//             (Tactical)" -> battery-tactical, "Knapsack of
//             Halflingkind (Greater)" -> knapsack-of-halflingkind-
//             greater, "Box of Unspoiling (Type I)" -> box-of-
//             unspoiling-type-i). Without this, slugifyName strips
//             the parenthetical entirely and the name-derived
//             candidate misses every tiered alchemical, every
//             upgraded container, and every battery variant. The
//             existing parens-stripping behaviour is preserved as a
//             separate candidate for the common descriptive-paren
//             case ("Treat Wounds (2d8, DC 15)"). HLO's own
//             comma-suffix pattern ("Climbing kit, commercial")
//             already resolves via the name slugifier (comma -> -),
//             so no change there. The "Clothing, winter" -> Clothing
//             (Cold-Weather) case stays in matcher-overrides because
//             the HLO suffix term itself does not match Foundry's
//             term, which no mechanical transform can fix.
// Revision: 0.2.0
//           - Wave 2 of the cog migration. Promoted from
//             src/matcher/slug-table.js. No logic changes; only
//             the file location and header are new.
//           - 0.1.0: Phase 1 (in src/matcher/). HLO compset to
//             Foundry compendium pack mapping plus slug-candidate
//             generation. Lookup happens in matcher-core.js via a
//             resolver; this cog owns the static mapping data and
//             the mechanical slug transformations.

/**
 * Maps an HLO compset to the Foundry compendium pack name(s) for each
 * supported system, in order of decreasing specificity. PF2e and SF2e DO
 * NOT share pack names: PF2e uses legacy logical names (`feats-srd`,
 * `classfeatures`, `actionspf2e`, `spells-srd`, `equipment-srd`,
 * `conditionitems`), while SF2e (built fresh) uses clean kebab-case
 * (`feats`, `class-features`, `actions`, `spells`, `equipment`,
 * `conditions`). The directories on disk are kebab-case in both; the
 * difference is in the `name` field declared in each system.json.
 *
 * Cross-system content is reached via the Anachronism modules. When
 * present, they expose PF2e content as `pf2e-anachronism.<pack>` for SF2e
 * games, and SF2e content as `sf2e-anachronism.<pack>` for PF2e games.
 * The matcher searches the active system's native packs first, then
 * falls back to the Anachronism packs for cross-system content. If a
 * given Anachronism module is not installed, the resolver returns null
 * for its packs and the matcher moves on, so adding them is harmless.
 *
 * Verified against:
 *   Foundry V13.351 with PF2e v7.12.2 and SF2e v0.0.11
 *   Foundry V14.361 with PF2e v8.1.2 and SF2e v1.1.2
 *   pf2e-anachronism v2.1.0 and sf2e-anachronism v2.1.0 (both kebab-case)
 *
 * Entries containing a `.` are treated as already-namespaced pack ids
 * (`<module-id>.<pack-name>`); entries without a `.` get the active
 * system id prepended at lookup time.
 *
 * Multiple packs in a list are tried in order; first slug hit wins.
 */
export const COMPSET_TO_PACKS = {
  Ancestry: {
    pf2e: ["ancestries", "sf2e-anachronism.ancestries"],
    sf2e: ["ancestries", "pf2e-anachronism.ancestries"],
  },
  Heritage: {
    pf2e: ["heritages", "sf2e-anachronism.heritages"],
    sf2e: ["heritages", "pf2e-anachronism.heritages"],
  },
  Class: {
    pf2e: ["classes", "sf2e-anachronism.classes"],
    sf2e: ["classes", "pf2e-anachronism.classes"],
  },
  Deity: {
    pf2e: ["deities", "sf2e-anachronism.deities"],
    sf2e: ["deities"], // pf2e-anachronism does not ship deities
  },
  Feat: {
    pf2e: [
      "feats-srd", "classfeatures", "ancestryfeatures",
      "sf2e-anachronism.feats", "sf2e-anachronism.class-features", "sf2e-anachronism.ancestry-features",
    ],
    sf2e: [
      "feats", "class-features", "ancestry-features",
      "pf2e-anachronism.feats", "pf2e-anachronism.class-features", "pf2e-anachronism.ancestry-features",
    ],
  },
  Action: {
    pf2e: ["actionspf2e", "sf2e-anachronism.actions"],
    sf2e: ["actions", "pf2e-anachronism.actions"],
  },
  Ability: {
    // v0.6.6: extended to include ancestry-features. HLO emits items
    // like Low-Light Vision and Limited Telepathy as Ability compset,
    // but they live in the ancestry-features pack on both systems.
    // Without this extension, the canonical pack-index lookup never
    // indexed ancestry-features for the Ability compset and the
    // matcher fell through with a miss.
    pf2e: ["actionspf2e", "classfeatures", "ancestryfeatures", "sf2e-anachronism.actions", "sf2e-anachronism.class-features", "sf2e-anachronism.ancestry-features"],
    sf2e: ["actions", "class-features", "ancestry-features", "pf2e-anachronism.actions", "pf2e-anachronism.class-features", "pf2e-anachronism.ancestry-features"],
  },
  Spell: {
    pf2e: ["spells-srd", "sf2e-anachronism.spells"],
    sf2e: ["spells", "pf2e-anachronism.spells"],
  },
  FocSpell: {
    // HLO emits focus spells under their own compset ("FocSpell", id
    // prefix "fs"). PF2e and SF2e fold focus spells into the same
    // spell packs as ranked spells and cantrips (verified 2026-05-16
    // against the V14 pf2e focus-spells pack-index dump: 457 entries
    // in pf2e.spells-srd, 33 in sf2e-anachronism.spells), so the
    // routing list mirrors Spell exactly.
    pf2e: ["spells-srd", "sf2e-anachronism.spells"],
    sf2e: ["spells", "pf2e-anachronism.spells"],
  },
  Weapon: {
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  NaturalWep: {
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  Armor: {
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  GearBasic: {
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  Ammunition: {
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  Upgrade: {
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  Staff: {
    // v1.0.6 added (public issue 2). HLO emits quarterstaffs and magic
    // staves under "Staff" with the weapon id prefix (wpStaff.687
    // "Staff"). Both the plain weapon ("staff") and the magic staves
    // ("staff-of-fire-lesser") live in the equipment packs, so the
    // routing mirrors Weapon.
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  AlchemicalItem: {
    // v1.0.6 added (public issue 2). HLO emits elixirs, mutagens,
    // poisons, and alchemical tools under "AlchemicalItem" (id prefix
    // "ai", e.g. aiElixLifeLr.800). PF2e ships them in equipment-srd
    // with consumables-srd as the secondary home, so the routing
    // mirrors MagicItem.
    pf2e: ["equipment-srd", "consumables-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "consumables", "pf2e-anachronism.equipment"],
  },
  Augmentation: {
    // Augmentation is SF2e-specific content; in a PF2e world it lives only
    // in the SF2e Anachronism module's equipment pack.
    pf2e: ["sf2e-anachronism.equipment", "equipment-srd"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  MagicItem: {
    // v0.7.0 added. HLO emits magic equipment (handwraps, mantles,
    // belts, aeon stones, healing potions, spacious pouches) under
    // this compset. Berial's 8 entries spanned weapon/equipment/
    // consumable/backpack Foundry types; the parser-compset-magicitem
    // handler picks the Foundry type by name pattern, then the slug-
    // pipeline strips the rune prefix (util-rune-parser) so the
    // matcher resolves to the BASE item in equipment-srd. Routed
    // across multiple packs because some magic items also live in
    // consumables-srd, magic-items, or containers depending on type.
    pf2e: ["equipment-srd", "consumables-srd", "magic-items", "containers", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "consumables", "magic-items", "containers", "pf2e-anachronism.equipment"],
  },
  CustomArmor: {
    // v0.7.0 added. HLO emits custom/lore-named armor like
    // "Numerian Steel Breastplate" under this compset. The
    // parser-compset-customarmor handler strips the lore prefix to
    // surface the underlying base armor (breastplate, chain-shirt,
    // etc); slugCandidates step 3.7 below consumes the baseName
    // field for the fallback lookup.
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  Wand: {
    // v0.7.0 added. HLO emits "Wand of <spell name>" entries under
    // this compset; PF2e equipment-srd ships matching wand items
    // with kebab-cased slugs ("wand-of-cozy-cabin", etc).
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  GearItem: {
    // v0.7.0 added. HLO emits miscellaneous gear (earplugs, etc.)
    // under this compset when GearBasic's schema doesn't fit; the
    // handler routes to equipment-srd as the catch-all gear pack.
    pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
    sf2e: ["equipment", "pf2e-anachronism.equipment"],
  },
  Background: {
    // PF2e and SF2e both ship a "backgrounds" pack with the kebab-case
    // name. HLO sends the background as a top-level gameValues field
    // (actBackgroundText), not as an item; parser-actor.js synthesizes
    // a Background item so this routing fires through the standard
    // matcher pipeline.
    pf2e: ["backgrounds", "sf2e-anachronism.backgrounds"],
    sf2e: ["backgrounds", "pf2e-anachronism.backgrounds"],
  },
  // Stat-bearing compsets do not map to packs; they update actor fields.
  AbilScore:   null,
  Save:        null,
  Skill:       null,
  ArmorClass:  null,
  Movement:    null,
  Reserves:    null,
  Derived:     null,
  Language:    null,
  ArmorTrait:  null,
  WeaponTrait: null,
  Trait:       null,
  // v0.7.0 non-compendium compsets. Spellbook: SKIP_BY_DESIGN (PF2e
  // auto-provisions via Wizard class GrantItem rules). Faction:
  // routed to actor.system.pfs.reputation via _actorMetadata
  // discriminator. CustomReward/CustomBoon: embedded as
  // campaignFeature items via _homebrewItem discriminator. None
  // pass through the compendium-lookup pipeline.
  Spellbook:    null,
  Faction:      null,
  CustomReward: null,
  CustomBoon:   null,
  // v0.7.1 apply-to-parent compsets. Rune and Material items have no
  // compendium entry of their own (PF2e/SF2e store rune and material
  // data ON the parent weapon/armor's system fields, not as separate
  // items); the builder's applyRuneAndMaterialPatches pre-pass
  // consumes them before buildItemReferences runs.
  Rune:         null,
  Material:     null,
};

/**
 * Resolve the pack list for a compset under a specific system. Returns
 * null for stat-bearing compsets, or an empty array if no packs are
 * configured for that system (treated identically by the matcher).
 */
export function packsFor(compset, systemId) {
  const entry = COMPSET_TO_PACKS[compset];
  if (entry == null) return null;
  if (Array.isArray(entry)) return entry; // backwards-compat shape
  return entry[systemId] ?? [];
}

/**
 * Build the fully-qualified pack id used by `game.packs.get()`. If the
 * pack list entry already contains a namespace dot (e.g. from an
 * Anachronism module: "pf2e-anachronism.feats"), it is used as-is.
 * Otherwise the active system id is prepended (e.g. "feats-srd" under
 * pf2e becomes "pf2e.feats-srd").
 */
export function qualifyPackId(systemId, packBase) {
  if (typeof packBase !== "string" || packBase.length === 0) return null;
  if (packBase.includes(".")) return packBase;
  return `${systemId}.${packBase}`;
}

/**
 * The compset prefix on HLO IDs. Used to strip the prefix before slug
 * generation. Most are two letters; a few are three.
 */
export const COMPSET_PREFIXES = {
  AbilScore:    "as",
  Save:         "sv",
  Skill:        "sk",
  ArmorClass:   "ac",
  Movement:     "mv",
  Reserves:     "rv",
  Ancestry:     "an",
  Heritage:     "hr",
  Language:     "ln",
  Class:        "cl",
  Deity:        "dei",
  Feat:         "ft",
  Action:       "ac",   // collides with ArmorClass; we strip by compset, not by prefix length
  Ability:      "ab",
  Spell:        "sp",
  FocSpell:     "fs",   // HLO focus-spell ids (e.g. fsHandApprentice)
  Weapon:       "wp",
  NaturalWep:   "nw",
  Armor:        "ar",
  ArmorTrait:   "at",
  WeaponTrait:  "wt",
  Ammunition:   "am",
  Staff:        "wp",   // v1.0.6: HLO files staves under the weapon id prefix (wpStaff)
  AlchemicalItem: "ai", // v1.0.6: aiElixLifeLr, aiMutagen*, aiAntidote*
  Upgrade:      "up",
  GearBasic:    "gr",
  Trait:        "trt",
  Augmentation: "au",
  Background:   "bg",
  // v0.7.0 prefixes. Several share an existing prefix (MagicItem,
  // CustomArmor, GearItem, Spellbook) because HLO id-prefixes are
  // not unique per compset; dispatch is by compset, not by prefix
  // length, so collisions are safe. The slug pipeline strips the
  // prefix during candidate generation only when the matcher path
  // is active (compendium-routed compsets).
  MagicItem:    "gr",
  CustomArmor:  "ar",
  Wand:         "wa",
  GearItem:     "gr",
  Spellbook:    "gr",
  Faction:      "fa",
  CustomReward: "bnCustom",
  CustomBoon:   "bnCustomN",
  // v0.7.1 prefixes. Rune: ruWep* (weapon), ruArm* (armor), ruShld*
  // (shield). Material: mtAdamantineSt, mtMithralHi, mtColdIronLo, etc.
  Rune:         "ru",
  Material:     "mt",
};

/**
 * Generate candidate Foundry slugs to try when looking up a parsed HLO item.
 * Returns an ordered list (most specific first); the matcher tries each in
 * turn. The order is:
 *
 *   1. The full HLO id-slug (preserves any SF-suffix variant info).
 *   2. The HLO id-slug with the trailing "SF" stripped (PF2e fallback).
 *   3. The slugified display name (stripped of parentheticals).
 *   4. The traitIds list, slugified one at a time (catches parent-class
 *      promotion for Champion subclasses, alchemist research fields, etc).
 *
 * @param {object} item    Normalized item IR from parse-items.js.
 * @returns {string[]}     Ordered candidate slugs.
 */
export function slugCandidates(item) {
  const out = [];
  const pushUnique = (s) => { if (s && !out.includes(s)) out.push(s); };

  const compset = item.compset;
  const prefix = COMPSET_PREFIXES[compset];

  // 1. ID-derived slug, transformed straight.
  if (item.slug) {
    pushUnique(hloIdToFoundrySlug(item.slug, prefix));
  }

  // 2. SF-suffix stripped variant (PF2e fallback for SF2e-tagged content).
  if (item.slug && /SF$/.test(item.slug)) {
    pushUnique(hloIdToFoundrySlug(item.slug.replace(/SF$/, ""), prefix));
  }

  // 3. Name-derived slug. This catches the truncated-ID case (e.g.
  // `ftDigitalAmbass` for "Digital Ambassador (DC 15)").
  if (item.name) {
    pushUnique(slugifyName(item.name));
  }

  // 3.5. Parenthetical-tier variants. PF2e/SF2e packs canonicalize tier
  // and variant suffixes as hyphenated slug parts: "Antidote (Lesser)"
  // becomes "antidote-lesser", "Battery (Tactical)" becomes
  // "battery-tactical", "Knapsack of Halflingkind (Greater)" becomes
  // "knapsack-of-halflingkind-greater". slugifyName strips parentheticals
  // for the common case where they hold descriptive numbers
  // ("Treat Wounds (2d8, DC 15)"), so we add a second pass that folds
  // the parenthetical contents back in as a suffix. This catches every
  // tier (Lesser/Moderate/Greater/Major), every variant
  // (Commercial/Tactical/Advanced/Superior/Elite), and the Type I/II/III
  // pattern (Box of Unspoiling, Bag of Devouring). Only the FIRST
  // parenthetical is folded; multi-paren names are rare and the first
  // is consistently the tier-bearing one.
  if (item.name) {
    const paren = item.name.match(/\(([^)]+)\)/);
    if (paren) {
      const base = slugifyName(item.name.replace(/\([^)]*\)/g, ""));
      const tier = paren[1]
        .replace(/[‘’']/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "");
      if (base && tier) pushUnique(`${base}-${tier}`);
    }
  }

  // 3.6. Precious-material prefix strip. PF2e Foundry does NOT ship a
  // separate compendium entry per material variant: there is no
  // "longsword-cold-iron" or "chain-shirt-mithral", only the base
  // "longsword" / "chain-shirt", with the material recorded on the
  // actor item's system.material.type field. HLO, however, emits the
  // material in the display name ("Cold Iron Longsword", "Mithral
  // Chain Mail"). Step 3 already produces a name-derived candidate
  // like "cold-iron-longsword" that misses; here we add a second
  // candidate with the leading material word(s) stripped so the
  // base item resolves.
  //
  // Scoped to gear-bearing compsets only to avoid stripping legitimate
  // ability/feat/spell names that happen to begin with one of these
  // words. Pf2e/sf2e Foundry verified 2026-05-16: no equipment-srd
  // base item starts with one of these words AND has a tier suffix
  // that would collide (only "dawnsilver-tree" exists, and it
  // resolves on the unstripped name-derived slug at step 3 before
  // this pass runs).
  const STRIPPABLE_COMPSETS = new Set(["Weapon", "NaturalWep", "Armor", "Ammunition", "MagicItem", "Staff"]);
  if (item.name && STRIPPABLE_COMPSETS.has(compset)) {
    const stripped = stripPreciousMaterial(item.name);
    if (stripped && stripped !== item.name) {
      pushUnique(slugifyName(stripped));
    }
  }

  // 3.7. baseName fallback. v0.7.0 added two handlers that surface a
  // pre-stripped baseName on the IR for slug-pipeline fallback:
  //
  //   * CustomArmor.normalize writes `item.baseName` at top level
  //     ("Numerian Steel Breastplate" -> baseName "breastplate"); the
  //     full-name candidate at step 3 misses, the baseName candidate
  //     here hits the canonical "breastplate" entry.
  //   * MagicItem.normalize (and the v0.7.0 Weapon rune-extension) write
  //     `item.runes.baseName` after stripping the rune prefix ("+1
  //     striking ghost touch handwraps of mighty blows" -> runes.baseName
  //     "handwraps of mighty blows"); the rune-prefix slug from step 3
  //     misses, this baseName candidate hits "handwraps-of-mighty-blows".
  //
  // Both paths are non-destructive: more-specific candidates are tried
  // first, so unique full-name items (dawnsilver-tree, +1 striking
  // wounding bastard sword) still resolve on their full slug if that's
  // canonical.
  const baseName = item.baseName ?? item.runes?.baseName;
  if (baseName) {
    pushUnique(slugifyName(baseName));
  }

  // 3.8. Elemental ammunition family. HLO names it "Elemental round,
  // lesser (infused, Cold)" but Foundry ships one entry per grade per
  // element, slug elemental-ammunition-<grade>-<element>. The "round"
  // -> "ammunition" rename defeats every generic pass, so detect the
  // family by name and build the canonical slug from the grade and
  // element words found anywhere in the name (the parenthetical carries
  // the element; "infused" and other noise words are simply not in the
  // element list, so they fall through harmlessly).
  if (item.name && /elemental\s+(round|ammunition)/i.test(item.name)) {
    const lower = item.name.toLowerCase();
    const grade = ["lesser", "moderate", "greater"].find((g) => lower.includes(g));
    const element = ["acid", "cold", "electricity", "fire", "poison"].find((e) => lower.includes(e));
    if (grade && element) {
      pushUnique(`elemental-ammunition-${grade}-${element}`);
    }
  }

  // 4. Each trait id, transformed. Useful when the primary slug is a
  // subclass and the parent class lives in compendium under the trait id
  // instead.
  if (Array.isArray(item.traitIds)) {
    for (const tid of item.traitIds) {
      pushUnique(hloIdToFoundrySlug(tid, prefix));
    }
  }

  // 5. Singular and plural variants of the candidates so far. Foundry
  // compendia mix the two ("Known Weaknesses" vs "Known Weakness" was a
  // long-running mismatch in zarmstrong's changelog).
  const baseCount = out.length;
  for (let i = 0; i < baseCount; i++) {
    const slug = out[i];
    if (!slug) continue;
    if (slug.endsWith("s") && slug.length > 1) {
      pushUnique(slug.slice(0, -1));
    } else {
      pushUnique(`${slug}s`);
    }
    // Also try "-es" for words like "weakness" -> "weaknesses".
    if (slug.endsWith("ss")) {
      pushUnique(`${slug}es`);
    } else if (slug.endsWith("es") && slug.length > 2) {
      pushUnique(slug.slice(0, -2));
    }
  }

  return out.filter(Boolean);
}

/**
 * Strip the compset prefix from an HLO slug and convert the remainder to
 * Foundry's kebab-case convention. If no prefix is provided (or the slug
 * does not start with it), we fall back to a pure decamelize.
 */
export function hloIdToFoundrySlug(hloSlug, prefix) {
  if (!hloSlug) return null;
  let remainder = hloSlug;
  if (prefix && hloSlug.startsWith(prefix)) {
    remainder = hloSlug.slice(prefix.length);
  }
  if (!remainder) return null;
  return decamelize(remainder);
}

/**
 * Precious-material prefix words that PF2e Foundry stores on the actor
 * item's system.material.type field rather than as part of the
 * compendium slug. HLO emits the material as the leading word(s) of
 * the display name ("Cold Iron Longsword", "Mithral Chain Mail",
 * "Dawnsilver Rapier"). slugCandidates calls stripPreciousMaterial
 * for gear-bearing compsets to produce a second candidate with the
 * material removed, so the matcher can resolve to the canonical
 * base item. Two-word materials ("cold iron", "sovereign steel") are
 * checked first so they get stripped in one pass instead of leaving
 * a dangling "iron" or "steel" on the front of the slug.
 */
const PRECIOUS_MATERIALS = [
  // Two-word materials (must be tried first).
  "cold iron",
  "sovereign steel",
  // Single-word materials.
  "mithral",
  "adamantine",
  "silver",
  "duskwood",
  "orichalcum",
  "dawnsilver",
  "darkwood",
  "noqual",
  "inubrix",
  "abysium",
  "djezet",
  "siccatite",
  "viridium",
  "keleshite",
  "sunsilver",
  "warpglass",
  "dragonhide",
  "peachwood",
];

/**
 * Strip a leading precious-material word (or two-word phrase) from a
 * weapon/armor display name. Returns the stripped name, or the
 * original if no material prefix is found. Case-insensitive on the
 * material; preserves the case of the remainder.
 */
export function stripPreciousMaterial(name) {
  if (!name || typeof name !== "string") return name;
  const lower = name.toLowerCase();
  for (const mat of PRECIOUS_MATERIALS) {
    if (lower.startsWith(`${mat} `)) {
      return name.slice(mat.length).trimStart();
    }
  }
  return name;
}

/**
 * Slugify a display name to PF2e/SF2e Foundry convention: lowercase
 * kebab-case, parentheticals stripped, apostrophes removed, punctuation
 * mapped to hyphens.
 */
export function slugifyName(name) {
  if (!name) return null;
  return name
    .replace(/\([^)]*\)/g, "")
    .replace(/[‘’']/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function decamelize(s) {
  return s
    .replace(/([a-z0-9])([A-Z])/g, "$1-$2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1-$2")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
