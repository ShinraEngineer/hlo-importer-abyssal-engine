// ============================================================
// COG: api-token-cache.js - In-memory HLO access-token cache
//                           (50-min TTL, module-scoped singleton)
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-28
// Revision: 0.2.1
//           - 0.2.1: Records the wait HLO attached to the acquire response and
//             whether the last get() came from the cache; pendingWaitMs() and
//             servedFromCache() let the dialog honour the wait and retry once
//             after a 7100 on a cached token (audit C2, C3).
//           - Wave 4 of the cog migration. Promoted from
//             src/api/access-token-cache.js. Internal import
//             repointed at sibling cog ./api-hlo-client.js. No
//             logic changes.
//           - 0.1.0: Phase 4 (in src/api/). In-memory access
//             token cache. The HLO Public API issues access
//             tokens via /v1/access/acquire-access-token using
//             the user-level JWT refresh token. Access tokens
//             are nominal 1-2 hours; we cache aggressively (50
//             minutes default) to avoid redundant exchange
//             calls during a single Foundry session.
//
// The cache is intentionally module-scoped, not actor-scoped. One user
// account, one access token; element tokens (which are per-character) ride
// on top of the same access token.

import { acquireAccessToken } from "./api-hlo-client.js";

const DEFAULT_TTL_MS = 50 * 60 * 1000;

export class AccessTokenCache {
  #token = null;
  #expiresAt = 0;
  #ttlMs;
  #userToken = null;
  #acquiredAt = 0;
  #waitMs = 0;
  #lastFromCache = false;

  constructor({ ttlMs = DEFAULT_TTL_MS } = {}) {
    this.#ttlMs = ttlMs;
  }

  /**
   * Return a fresh access token, exchanging the user token only when the
   * cache is empty or expired. Pass the same user token each call; if a
   * different user token comes in, the cache is invalidated.
   */
  async get(userToken) {
    if (!userToken) throw new Error("AccessTokenCache.get: userToken is required.");
    const now = Date.now();
    if (this.#token && now < this.#expiresAt && this.#userToken === userToken) {
      this.#lastFromCache = true;
      return this.#token;
    }
    const { accessToken, waitMs } = await acquireAccessToken(userToken);
    this.#token = accessToken;
    this.#expiresAt = now + this.#ttlMs;
    this.#userToken = userToken;
    this.#acquiredAt = Date.now();
    this.#waitMs = waitMs;
    this.#lastFromCache = false;
    return accessToken;
  }

  /**
   * Milliseconds the caller still has to wait before the next HLO call,
   * per the wait HLO attached to the acquire response. Zero once that
   * window has passed or when the last get() was served from the cache.
   */
  pendingWaitMs() {
    if (this.#lastFromCache || !this.#acquiredAt) return 0;
    return Math.max(0, this.#acquiredAt + this.#waitMs - Date.now());
  }

  /** True when the most recent get() returned a cached token. */
  servedFromCache() {
    return this.#lastFromCache;
  }

  invalidate() {
    this.#token = null;
    this.#expiresAt = 0;
    this.#userToken = null;
    this.#acquiredAt = 0;
    this.#waitMs = 0;
    this.#lastFromCache = false;
  }
}

// A module-scoped singleton for convenience. Most callers want this.
export const tokenCache = new AccessTokenCache();
