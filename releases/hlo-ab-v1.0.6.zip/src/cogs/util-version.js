// ============================================================
// COG: util-version.js - Module identity constants
//                        (id, title, version, HLO API base/tool name)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-18
// Revision: 0.5.18
//           - 0.5.18: MODULE_VERSION 1.0.5 -> 1.0.6. Release hosting
//             moved to the public GitHub shell repository: module.json
//             "manifest" and "download" now point at
//             raw.githubusercontent.com (public issue 4, the shinra.cc
//             manifest and zip returning 404). Same lockstep cascade.
//           - 0.5.17: MODULE_VERSION 1.0.0 -> 1.0.1 (PATCH bump: dialog
//             cleanup pass following the v1.0.0 public launch). The
//             "Dump all indexes" bulk-export button was a maintainer
//             convenience that queued ~40+ browser save dialogs in a
//             row for index-table audit work. Useful when seeded a
//             new override table; loud and confusing for anyone else
//             who flipped log level to debug to read parser output.
//             Commented out in templates/import-dialog.hbs alongside
//             the matching action wire in src/cogs/ui-import-dialog.js
//             actions block. The per-category buttons under the
//             collapsible Index Dumps (Dev) disclosure remain
//             available for surgical one-pack dumps. Disclosure stays
//             collapsed-by-default (_indexDumpsExpanded = false) so
//             debug-mode opens stay quiet. _onDumpAllIndexes static
//             method body left intact so re-enabling is a one-line
//             un-comment in two files. No functional change to import
//             pipeline; pure UI noise reduction. Public-launch
//             posture: dialog now ships the same surface to users
//             that maintainers see when they are not actively
//             auditing index tables.
//           - 0.5.16: MODULE_VERSION 0.7.1 -> 1.0.0 (MAJOR bump: alpha-1.0.0
//             public launch milestone). Single-pass audit on the
//             last known bug: PFS chronicle boons silently vanishing
//             from the actor despite the import log claiming success.
//             Root cause was sparse source emission. v0.7.1 emitted
//             only category/slug/description/traits/level on the
//             campaignFeature/feat IR-patch and relied on PF2e's
//             DataModel defaults to fill the rest. PF2e's
//             createDocuments override (pf2e.mjs line 50098-50173)
//             constructs each item via new CONFIG.Item.documentClass
//             inside an inner pipeline; when one item in a batch
//             fails (Devil's Keep with frequency.per: "scenario"),
//             the bulk path throws and the dialog falls back to
//             per-item. PF2e's per-item path has spots that return
//             [] or splice without rethrowing, so the dialog's
//             "succeeded += 1" over-reports. The 8 boons without
//             frequency were silently dropping at coercion time
//             despite the log line "Per-item creation: 112 of 113
//             added; 1 skipped". Fix: parser-compset-customreward
//             0.3.0 emits a fully-mapped boon shape (new
//             mapHloPeriodToFrequencyPer helper translates HLO
//             Period values like "Scenario" / "Session" to PF2e's
//             CONFIG.PF2E.frequencies enum keys; "Scenario" maps to
//             "day" since a PFS scenario is a single session and
//             1/day approximates 1/scenario tracking). builder-
//             actor-pf2e 0.4.2 rewrites buildPfsBoonItems to emit a
//             FULLY-SHAPED FeatPF2e source with every field PF2e's
//             FeatSystemData.defineSchema (pf2e.mjs 74503-74660)
//             names: complete description.value/gm, empty rules,
//             slug, publication, traits.value/otherTags/rarity,
//             level.value/taken, category="pfsboon", onlyLevel1,
//             maxTakable, actionType.value="passive", actions.value,
//             prerequisites.value, subfeatures block, custom
//             thematic icon, pre-initialized flags.pf2e={}. Removes
//             every late-bound coercion path where v0.7.1 lost the
//             items. the design context: PF2e/SF2e compendiums
//             cover maybe 20 boons between them while Paizo's
//             published catalog has hundreds, so boons are character
//             data not compendium-content; the homebrew shape is
//             the right architecture.
//             Verified out-of-Foundry: Berial Jeggare's 9 boons (8
//             CustomReward + 1 CustomBoon) all reach the IR with
//             complete shape. Devil's Keep frequency now maps to
//             { max: 1, per: "day", value: 1 } passing FrequencyField
//             validation. PF2e sheet's prepareFeats (pf2e.mjs
//             38942-38951) will bucket them into actor.pfsBoons for
//             the PFS tab render.
//             ALPHA-1.0.0 LAUNCH READY. All known SF2e and PF2e
//             import paths verified clean against 6 test characters
//             (Noxora L2 + L4 SF2e Operative, Berial PFS Wizard 8,
//             Berial ETT Magus, Bhel'thal Champion 6, Bhelroth EC
//             Fighter 20, Revascis Drow Champion 13, Revascis Virholt
//             Vampire Magus 20). Cog count: 49 functional. 1108
//             cumulative lines added since v0.6.13 across parser
//             extensions + PFS plumbing + rune triad + boon fix.
//           - 0.5.15: MODULE_VERSION 0.7.0 -> 0.7.1. Five-pass audit
//             addressing every issue surfaced by the 5-character
//             V14 verification run of v0.7.0. Issues found:
//             (A) Weapon and armor runes silently dropped: parser
//                 extracted runes from item names correctly but the
//                 builder never wrote them to system.runes. Plus
//                 armor with "+N" prefix (e.g. "+1 padded armor")
//                 had the ENTIRE armor item dropped because parser-
//                 compset-armor didn't call extractRunes. Plus
//                 standalone Rune items (HLO sends ruArmPotency1,
//                 ruArmResilient, ruArmResistFire as separate
//                 items) were silently dropped because no Rune
//                 compset handler existed. Same gap for Material.
//             (B) PFS chronicle boons silently failed schema
//                 validation: v0.7.0 emitted them as
//                 campaignFeature items with category=pfsboon, but
//                 campaignFeature is the Kingmaker item type with
//                 only Kingmaker-specific categories allowed.
//                 pfsboon is a valid category but only for feat
//                 items. PF2e's PFS tab filters
//                 itemTypes.feat where category===pfsboon (verified
//                 against pf2e.mjs line 38946). Fix: emit as feat
//                 type instead.
//             (C) Spell _id collision on re-import: PF2e's
//                 ActorPF2e.createDocuments override flips
//                 operation.keepId=true the instant ANY source item
//                 carries grants, which applies to the entire batch.
//                 Non-grant spells inherit keepId:true and collide
//                 with prior import's compendium _ids. Fix: strip
//                 _id from regular items before bulk-create. Grant-
//                 bearing items in the earlier phase keep their
//                 _ids for grant-graph integrity.
//             (D) MagicItem and Wand items silently dropped:
//                 ui-import-dialog COMPENDIUM_COMPSETS set was
//                 missing the v0.7.0 compsets, so when matchItem
//                 returned null for one of these items, four
//                 gating points in the dialog (debug log,
//                 unmatched count, warn emission, modal collection)
//                 all skipped it. Items vanished with zero
//                 observability. Fix: add MagicItem, CustomArmor,
//                 Wand, GearItem, and FocSpell to
//                 COMPENDIUM_COMPSETS so misses become visible.
//             (E) Override and SKIP_BY_DESIGN batch: 11 new SKIP
//                 entries (7 vampire/undead trait blocks delivered
//                 by Vampire Dedication, 2 magic-item activation
//                 echoes parallel to abWayfinderLight, Arcane
//                 Cascade auto-installed by Magus class chain,
//                 vampire Fangs auto-granted by Vampire Dedication)
//                 plus 2 OVERRIDES entries (Scorching Ray name-
//                 keyed and id-keyed mapping to Remaster-renamed
//                 scorching-rays plural slug). Plus parser-
//                 compset-wand baseName surface for slugCandidates
//                 step 3.7 to produce wand-of-<spell> fallback.
//             Critical insight from pass 2's verification: PF2e's
//             rule-element pipeline only recognizes camelCase rune
//             slugs (ghostTouch, fireResistant, greaterReady) not
//             kebab-case. Writing kebab-case to system.runes.property
//             would have produced the same silent-rune bug one level
//             deeper in the system. util-rune-parser updated to use
//             canonical camelCase.
//             Net surface: 2 new cogs (parser-compset-rune,
//             parser-compset-material), 49 functional cogs total.
//             Six existing cogs modified (parser-compset-armor,
//             parser-compset-customarmor, parser-compset-wand,
//             parser-compset-customreward, builder-actor-pf2e,
//             builder-items, ui-import-dialog, util-rune-parser).
//             All five test characters' v0.7.0 issues addressed.
//           - 0.5.14: MODULE_VERSION 0.6.13 -> 0.7.0 (MINOR bump for new
//             parser-extension surface). Four-pass audit landing
//             the 8 unhandled HLO compsets that silently dropped 28
//             items per PFS-character import in v0.6.13:
//             (A) MagicItem (pass 1) - new parser-compset-magicitem
//                 plus the shared util-rune-parser cog that extracts
//                 PF2e/SF2e rune prefixes (+N potency, striking tiers,
//                 19 property runes including ghost touch / wounding
//                 / frost / shock / flaming / vorpal / holy / disrupt-
//                 ing / returning / grievous / fearsome / undead-bane
//                 / unholy / thundering / corrosive / keen / speed /
//                 spell-storing / anarchic / axiomatic). Same utility
//                 wired into parser-compset-weapons so "+1 striking
//                 wounding bastard sword" no longer drops the runes
//                 in transit. Type detection routes handwraps to
//                 weapon, potions/elixirs/talismans to consumable,
//                 spacious pouches to backpack, default to equipment.
//             (B) CustomArmor / Wand / GearItem (pass 2) - three
//                 new compendium-routed handlers, all targeting
//                 equipment-srd. CustomArmor strips lore-name
//                 prefixes ("Numerian Steel Breastplate" -> base
//                 "breastplate") and surfaces baseName on the IR
//                 for slugCandidates step 3.7 fallback. Wand and
//                 GearItem use the standard name-derived slug path.
//             (C) Spellbook (pass 3) - SKIP_BY_DESIGN. Researched
//                 against pf2e.mjs and template.json: PF2e does not
//                 model the Wizard spellbook as a discrete item.
//                 The spellcastingEntry that anchors a Wizard's
//                 prepared spell list is auto-provisioned by the
//                 Wizard class's GrantItem rules at embed time.
//                 The Spellbook handler returns an empty IR patch;
//                 matcher-overrides has the skip entry with the
//                 reason string. SF2e mirrors the same behavior.
//             (D) Faction / CustomReward / CustomBoon (pass 4) -
//                 three PFS-specific handlers that DO NOT go
//                 through the compendium-lookup pipeline. Faction
//                 emits an _actorMetadata discriminator that
//                 routes to actor.system.pfs.reputation (a flat
//                 object keyed by 2-letter faction codes EA / GA
//                 / HH / VS / RO / VW per pf2e template.json line
//                 106-120). CustomReward and CustomBoon emit
//                 _homebrewItem discriminators that embed as
//                 campaignFeature items with category=pfsboon
//                 (confirmed against pf2e.mjs line 13300). PF2e
//                 sheet renders these in the PFS tab. CustomBoon
//                 piggybacks the CustomReward handler module
//                 because they share the boon shape.
//             Integration: parser-compset-registry.js gained 8
//             new entries (rev 0.3.0), matcher-slug-table.js
//             gained 4 compendium routes + 4 null entries + 8
//             prefix entries + STRIPPABLE_COMPSETS expansion + new
//             step 3.7 baseName fallback (rev 0.5.0).
//             Verified: Berial Jeggare's 28 previously-dropped
//             items all reach their proper destinations after this
//             revision. The Foundry actor will now show his
//             handwraps, mantle, belt, breastplate, wand,
//             spellcastingEntry (auto-provisioned by Wizard class),
//             and 9 PFS boons in the PFS tab.
//           - 0.5.13: MODULE_VERSION 0.6.12 -> 0.6.13. Twenty-pass
//             launch-prep audit (6 SF2e + 14 PF2e + 1 cross-
//             system) against the 2026-05-16 V14 pack-index
//             dumps for pf2e v8.1.2 and sf2e v1.1.2. Net
//             surface: matcher-overrides.js 0.6.7, matcher-
//             slug-table.js 0.4.2, matcher-pack-index.js 0.3.0,
//             parser-compset-registry.js 0.2.0, matcher-mock-
//             resolver.js 0.4.0. Headline fixes:
//             (A) CRITICAL paren-collision wrong-match (pass //             PF2e-C). 23 ancestry-feat variants like Tusks
//             (Orc) and Tusks (Half-Orc) both collapsed to
//             `tusks` via normalizeKey's paren-strip. First-
//             wins routing silently sent the wrong feat to the
//             wrong heritage. Fixed via new preserveParens flag
//             on normalizeKey: lookupCanonical now tries the
//             parens-preserved key first (yields tusks-orc),
//             falls back to stripped only when the parens
//             variant has no canonical hit.
//             (B) FocSpell parser-extension (pass PF2e-J).
//             HLO emits focus spells with compset=FocSpell (id
//             prefix `fs`), not Spell. Every focus spell
//             ("Hand of the Apprentice", every Bloodline /
//             Domain / Order / Patron / Witch-Lesson focus
//             spell) was falling through parser-items as
//             "Unknown compset" and degrading to raw data.
//             Registered FocSpell to the existing Spells.Spell
//             handler in parser-compset-registry (schemas are
//             identical) and added FocSpell to COMPSET_TO_PACKS
//             + COMPSET_PREFIXES in matcher-slug-table. First
//             of PF2e-Final's 10 parser-extension blockers
//             converted from v0.7.0 follow-up to shipped.
//             (C) PRECIOUS_MATERIALS slug fallback (pass //             PF2e-K). PF2e Foundry stores materials on
//             system.material.type, not in per-material slugs.
//             HLO's "Cold Iron Longsword" was producing
//             cold-iron-longsword (does not exist) instead of
//             longsword (does). New step 3.6 in slugCandidates
//             strips 17 known precious materials (cold iron,
//             mithral, adamantine, orichalcum, dawnsilver,
//             darkwood, sovereign steel, noqual, inubrix,
//             abysium, djezet, siccatite, viridium, keleshite,
//             sunsilver, warpglass, dragonhide, peachwood) for
//             Weapon, NaturalWep, Armor, Ammunition compsets.
//             Non-destructive: full-slug candidate runs first,
//             so unique material-named items (dawnsilver-tree)
//             still win.
//             (D) PF2e Remaster identity renames (pass //             PF2e-M). 5 critical heritage / ancestry renames:
//             Aasimar -> nephilim, Tiefling -> nephilim,
//             Half-Elf -> aiuvarin, Half-Orc -> dromaar, Gnoll
//             -> kholo (the entire ancestry). Each legacy
//             slug verified ABSENT and each target slug
//             verified PRESENT in the 2026-05-16 dump. Without
//             these every PF2e character with a half-ancestry
//             or planar-touched heritage breaks on import.
//             (E) PF2e Remaster spell renames (passes PF2e-H
//             + PF2e-I). 22 spell renames covering essentially
//             every iconic PF2e spell touched by the Remaster:
//             L1-3 includes Magic Missile, True Strike, Magic
//             Weapon, Magic Armor, Magic Fang, Hideous
//             Laughter, Touch of Idiocy, Endure Elements,
//             Continual Flame, Comprehend Language, Tongues,
//             See Invisibility, Glitterdust, Searing Light,
//             Disrupt Undead, Flaming Sphere. L4-10 includes
//             Wail of the Banshee, Time Stop, Mind Blank,
//             Plane Shift, Flesh to Stone, True Sight. Each
//             gets two override entries (name-keyed +
//             HLO-id-keyed) for 44 entries total.
//             (F) SF2e-native cross-system routing (pass //             SF2e-B). 4 of the 23 parenthetical heritage
//             overrides added in v0.6.0 were routed to
//             feats-srd, which qualifies to nonexistent
//             sf2e.feats-srd on SF2e characters. Switched
//             Ancestral Weapon Familiarity (Astrazoan),
//             Bioluminescence (Shirren), Gooey Engulf (Entu),
//             and Hang in There (Nu)Friend! to the already-
//             namespaced sf2e-anachronism.feats pack so a
//             PF2e character pulling these SF2e ancestry feats
//             via the Anachronism route resolves correctly.
//             (G) Hellknight Remaster cleanup (pass PF2e-A).
//             Removed Feat:Fencer override (the feat "Fencer
//             Style" was removed entirely in the Remaster).
//             Retargeted Feat:Hellknight Signifier Dedication
//             from the now-defunct hellknight-signifer-
//             dedication slug to the live hellknight-dedication.
//             Added Feat:Hellknight Signifier Preferment ->
//             hellknight-signifer-preferment (note Foundry's
//             persistent "signifer" misspelling - intentional).
//             (H) Slug pipeline step 3.5 (pass PF2e-L). New
//             parens-tier folding: "Antidote (Lesser)" now
//             generates both `antidote` AND `antidote-lesser`
//             slug candidates, so tier-suffixed equipment
//             resolves through whichever form Foundry uses.
//             (I) SF2e gap fillers (passes SF2e-A, SF2e-C +
//             5 stub resolutions). AbadarCorp Rep Dedication
//             CamelCase fix, Anima Invocation, Wayfinder -
//             Light, Clothing winter, plus 3 Resistance skips.
//             (J) Mock-resolver sync (passes SF2e-D, SF2e-E).
//             ~20 new entries in the Noxora test harness so
//             the Node test harness mirrors the live Foundry
//             pack-index lookup result. Catches false-positive
//             misses in CI that the real Foundry resolver
//             never had.
//             (K) Verified-clean audit passes (passes PF2e-B,
//             PF2e-D, PF2e-E/F/G, PF2e-N, SF2e-F). Five
//             documented "no edits needed" audit passes.
//             Header documentation captures HOW existing
//             infrastructure covers each slice so future
//             audits don't re-verify the same ground.
//             Identified blocker for follow-up (PF2e-Final +
//             second confirmation): 9 remaining unknown
//             compsets HLO emits with no handler (Rune,
//             MagicItem, Wand, Spellbook, GearItem, Faction,
//             CustomReward, CustomBoon, CustomArmor). ~38
//             items per PFS-import currently degraded.
//             Recommended as parser-extension work for v0.7.0.
//           - 0.5.12: MODULE_VERSION 0.6.11 -> 0.6.12. Six-pass audit targeting the residual issues v0.6.11's
//             field test surfaced. Four direct fixes + two
//             research-only verifications. (1) Grant resolver
//             HLO match (pass 1): the operative-specialization
//             tag lives on system.traits.otherTags of the
//             FOUNDRY compendium doc, not HLO's traitIds; new
//             pickHloItemForChoiceSetAsync re-checks Foundry-
//             side predicates against the fetched doc, so the
//             "no HLO match; ignoring (fallback)" log line
//             disappears and Infiltrator gets pre-resolved
//             with proper flags.sf2e.grantedBy linkage.
//             (2) Wizard silencer double-fire (pass 2):
//             cause was BOTH renderPickAThingPrompt AND
//             renderApplicationV2 hooks firing for every
//             PickAThingPrompt render (it extends ApplicationV2).
//             New WeakSet silencedInstances gates all three
//             intercept layers (render-hook entry, Layer 1,
//             Layer 2) so each prompt resolves exactly once.
//             (3) Granted-feature ChoiceSet from HLO (pass 3):
//             Infiltrator's own skill-pick ChoiceSet was
//             defaulting to "Acrobatic Performer." New four-
//             pool cascade walks matched-uuids -> hlo-skills
//             (by profLevel) -> label-fallback -> first-
//             choice. Every pick emits a debug line naming
//             the winning pool. Noxora's Stealth/Thievery
//             trained skills will populate Infiltrator's slot
//             instead of the random fallback.
//             (4) Bipod parentItem.id warnings (pass 5):
//             ~30 console fires per import fixed by switching
//             weapon/armor upgrades + ammo from free-floating
//             actor items to parent.system.subitems[] entries.
//             This is the native SF2e/PF2e attachment shape;
//             prepareBaseData constructs each subitem as an
//             ItemProxyPF2e with parentItem set, which is
//             what makes {item|parentItem.id} resolve. Kills
//             the warnings AND cleans up the sheet's item
//             list AND makes upgrades show as attached to
//             their parent weapon.
//             Research-only confirmations (no code change):
//             (5) Sheet "Class Features" tab (pass 6): SAFE.
//             Tab is item-driven via actor.itemTypes.feat,
//             not source-map-driven via class.system.items.
//             Our v0.6.11 {} clear is invisible to the
//             character sheet. (6) Cross-class compatibility
//             (pass 4): all 6 published SF2e classes
//             (Envoy/Mystic/Operative/Soldier/Solarian/
//             Witchwarper) verified shape-compatible with
//             resolver. HIGH confidence on 5; MEDIUM-HIGH on
//             Witchwarper due to a Quantum Field alterations
//             injection token that's untested by evidence
//             but flagged.
//           - 0.5.11: MODULE_VERSION 0.6.10 -> 0.6.11. Six-pass audit, every shipped fix integrated. (1) Import
//             button stretch FINALLY fixed (pass 1) by
//             wrapping the button in a span class="ae-header-
//             btn-wrap" so the wrapper becomes the flex child
//             of .window-header instead of the button. Belt-
//             and-suspenders CSS pins both wrapper AND button
//             to flex:0 0 auto / max-width:max-content with
//             three ascending-specificity selectors so nothing
//             upstream can override. Root cause was parent-
//             imposed flex-grow that five prior revisions of
//             internal-margin tightening never addressed.
//             (2) Index Dumps stragglers (pass 2A): six
//             specs (treasure, containers, ammunition, other-
//             feats, spell-level-10, other-items) were SF2e-
//             only; added pf2e-anachronism cross-system pack
//             symmetrically so the deep PF2e catalog (5635
//             equipment, 5825 feats, etc.) is reachable.
//             (3) Matcher routing gap audit (pass 2B): NO
//             gaps found, all 27 packs reachable, normaliz-
//             ation handles every observed pattern. Doc-only
//             edit to matcher-overrides.js confirming SF2e
//             subclass promotions are not needed.
//             (4) Wizard silencer (pass 3): two-layer
//             render-hook + prototype-monkey-patch defense
//             that intercepts PickAThingPrompt instances
//             during import and auto-resolves to HLO's
//             chosen pick or first-choice fallback. Install/
//             teardown around _runPipeline with try/finally
//             so no leaked patches. (5) SF2e grant resolver
//             (pass 4): NEW cog src/cogs/sf2e-grant-
//             resolver.js (363 LOC) that walks class.system.
//             items, fromUuid's each granted feature, pre-
//             fills ChoiceSet selections, recursively
//             materializes chained grants, writes bidirec-
//             tional flags.sf2e.itemGrants + grantedBy
//             chains, and clears class.system.items={} so
//             SF2e's createGrantedItems early-bails. Covers
//             all 6 published SF2e classes. Cog count 38 ->
//             39. (6) Console "value on number 1" residual
//             (pass 5): sanitizeSystemOrphans() helper that
//             scans 8 orphan-prone system roots, replaces
//             bare-number/boolean depth-1 children with {}
//             before scaffold merge. Same parent/child path
//             collision pattern as v0.6.10's Index Dumps
//             fix; this time inside SF2e's AELikeRuleElement
//             .#applyAELike pipeline.
//           - 0.5.10: MODULE_VERSION 0.6.9 -> 0.6.10. Five-pass audit + integration. Field-test findings from a
//             real Foundry V14 SF2e import: console flooded
//             with errors, HLO feats landing in Bonus Feats
//             slot, wizard still firing, Index Dumps mostly
//             empty (500-700 bytes each), and "Dump all
//             indexes" requested as a one-click bulk action.
//             (1) Bonus Feats slotting fix (pass 5):
//             new assignFeatLocations() in resolveSkeleton
//             ForCreate binds HLO feats to class-N / skill-N
//             / ancestry-N / background-_id slots via
//             system.location + system.level.taken so SF2e
//             routes them to the proper slot. Plumbed
//             reqLevelNet + traitIds through builder-items.js
//             stub. (2) Index Dumps emptiness fix (pass 3):
//             stripParentPaths() dedupe in
//             buildPackCategoryDump kills the
//             setProperty(template, "system.traits", 1) ->
//             "(1).value = 1" collision; CONFIG paths switched
//             to PF2E.* (sf2e is a pf2e fork). (3) "Dump all
//             indexes" button (me): one-click bulk export of
//             every CATEGORY_DUMP_SPECS entry with 75ms
//             inter-save delay. (4) Preselect message
//             correction (pass 2): no longer falsely claims
//             pre-fills happened; reports actual rule-shape
//             outcome instead. DEFERRED to v0.7.0+ (pass 4):
//             SF2e Operative class wizard requires full ABC
//             grant-pipeline pre-pull (~500 LOC, separate
//             session). DEFERRED (pass 1): console "value on
//             number 1" noise from SF2e's uncaught prepare
//             calls on orphan numeric scalars; cosmetic, fix
//             needs verified reproducer before applying the
//             two-step wipe.
//           - 0.5.9: MODULE_VERSION 0.6.8 -> 0.6.9. Three-pass audit + my integration. (A) Replaced v0.6.8's
//             suppressGrantingRules() with prefillGrantingRules
//             () that walks GrantItem and ChoiceSet rules on
//             grant-bearing items, resolves HLO items to
//             Foundry UUIDs via lookupCanonical, and sets
//             preselectChoices on GrantItem rules (or
//             selection on standalone ChoiceSet rules) so
//             SF2e/PF2e's grant pipeline actually fires
//             correctly instead of being silently skipped.
//             Restores flags.sf2e.grantedBy linkage for
//             ancestries/heritages/backgrounds. SF2e classes
//             still fall through to the v0.6.8 ignored:true
//             fallback because SF2e loads class features via
//             system.items + createGrantedItems lifecycle,
//             not via GrantItem rules in system.rules - that
//             fix needs its own session (v0.6.10+).
//             (B) New temporary "Index Dumps (Dev)" panel in
//             the dialog: 42 per-category export buttons in 8
//             groups (Identity, Ancestry/Class Features,
//             Feats, Spells, Equipment, Actions, Sense-of-
//             Character, Character Data) that dump narrow
//             JSON slices of game.packs and CONFIG.PF2E /
//             CONFIG.SF2E. CATEGORY_DUMP_SPECS module map +
//             single _onExportIndexCategory handler dispatch.
//             TEMP feature with cleanup checklist banner;
//             slated for removal before public launch.
//             (C) 14 sense slugs added to SKIP_BY_DESIGN
//             (Darkvision, Tremorsense, Scent, Echolocation,
//             Lifesense, Bloodsense, Truesight, Spiritsense,
//             Wavesense, Magicsense, InfraredVision,
//             MotionSense, ElectromagSense, SeeInvisibility).
//             Verified against pack-index dump: each sense
//             confirmed to have NO compendium entry in any
//             Ability-routed pack. Greater Darkvision and
//             Thoughtsense deliberately LEFT OUT (they DO
//             have real compendium feats).
//             Plus CSS button further tightened (gap 0.05rem,
//             margin 0, padding 0.05rem x 0.1rem - at the
//             practical floor for clickable buttons).
//           - 0.5.8: MODULE_VERSION 0.6.7 -> 0.6.8. Three-pass audit + integration. (1) Wizard suppression via
//             ChoiceSet/GrantItem rule ignoring. pass A's
//             source audit traced the "Select a skill feat"
//             prompt to SF2e's overridden ItemPF2e.create
//             Documents at sf2e.mjs:50101 - fires rule.
//             preCreate() directly outside Foundry's hook bus,
//             which is why noHook:true was structurally unable
//             to reach it. New suppressGrantingRules() helper
//             sets ignored:true on ChoiceSet (silences dialog)
//             and GrantItem (suppresses auto-grant chain) on
//             grant-bearing items in resolveSkeletonForCreate.
//             noHook:true dropped from _createItemsBatch.
//             (2) New ui-unmatched-modal cog + template +
//             integration. End-of-import unmatched items now
//             surface in a blocking ApplicationV2 dialog with
//             I Understand / X dismissal, replacing the
//             easily-missed log warning. (3) matcher-pack-
//             index normalizeKey extended to strip trailing
//             unit suffixes (Limited Telepathy 30 ft. -> hits
//             limited-telepathy). matcher-overrides SKIP_BY_
//             DESIGN += Ability:abLowLightVision (sense not
//             item). Plus CSS button further tightened. Cog
//             count 37 -> 38 with ui-unmatched-modal.
//           - 0.5.7: MODULE_VERSION 0.6.6 -> 0.6.7. V14 API audit
//             pass + three fixes. New docs/FOUNDRY_API_NOTES.md
//             captures the contract-level verdict (documented
//             contract / undocumented-but-stable / wrong) for
//             every Foundry API our cogs depend on, sourced
//             from a five-pass parallel audit against
//             foundryvtt.com/api/v14/. Out of 41 specific
//             assumptions tested, only one was an active code
//             bug; two were already-fixed-historically; the
//             rest were either documented or
//             undocumented-but-stable. Active fixes:
//             (1) matcher-foundry-resolver.js dropped a
//             malformed UUID fallback (Compendium.{packId}.
//             {id} was missing the {Type} segment per V14's
//             canonical UUID format). (2) ui-settings.js
//             comment about pre-registration access corrected
//             (it throws, doesn't return undefined). (3)
//             import-conversion-journal.js swapped magic
//             format:1 for CONST.JOURNAL_ENTRY_PAGE_FORMATS.
//             HTML for readability.
//           - 0.5.6: MODULE_VERSION 0.6.5 -> 0.6.6. Three changes
//             addressing the four genuine unmatched items
//             from the v0.6.5 Noxora log + the user's
//             question about how to share pack-JSON data
//             from inside Foundry. (a) Ability compset
//             routing extended to include ancestry-features
//             pack on both PF2e and SF2e - catches Low-Light
//             Vision and Limited Telepathy via canonical
//             lookup. (b) New SKIP_BY_DESIGN override
//             mechanism for items HLO sends that are NOT
//             compendium-eligible: NaturalWep:nwFist (system
//             auto-grants every actor an unarmed strike) and
//             Ability:abEnvironProtect (activation echo of
//             the matching Upgrade item). Matcher returns
//             strategy="skip" with a reason string; dialog
//             logs each skip with the reason so users see
//             what was deliberately omitted vs accidentally
//             missed. (c) New Dev Export Pack Index button
//             in the dialog (visible at debug log level)
//             that dumps the live game.packs index for every
//             pack the matcher walks. Lets the maintainer
//             see the deterministic-lookup ground truth
//             without LevelDB extraction tooling.
//           - 0.5.5: MODULE_VERSION 0.6.4 -> 0.6.5. Two fixes from
//             user feedback + import log 2026-05-16T01:53:44.
//             (1) Bug fix: stale "ours" variable reference at
//             cogs/ui-import-dialog.js:779 was throwing
//             ReferenceError after Phase 1 delete, killing
//             every import. The v0.5.9 refactor renamed
//             "const ours" to "const targetsToDelete" but
//             missed updating one log message six lines down.
//             Cog architecture made the fix obvious: the
//             crash stack named the exact file:line:column
//             at first glance. Restructured the log message
//             to use the renamed variable and read correctly
//             in both wipe and non-wipe modes.
//             (2) Sheet-header button text changed from
//             "Abyssal-Engine Import" to "AE HeroLab
//             Importer" per user feedback that the previous
//             label was branded but not informative. Same
//             icon-then-label layout; tooltip preserves the
//             Abyssal Engine attribution. CSS margins +
//             padding + gap tightened so the button takes
//             less title-bar real estate.
//           - 0.5.4: MODULE_VERSION 0.6.3 -> 0.6.4. Class key-ability
//             wiring. New cog cogs/builder-class-defaults.js
//             maintains a class-slug -> default-key-ability
//             table covering every published PF2e Player Core
//             2 class plus all Player-Core and Field-Test
//             SF2e classes. builder-actor-pf2e.js's
//             buildDetails now derives system.details.
//             keyability.value from the parsed Class item via
//             keyAbilityForClass(). Without this, SF2e
//             auto-derives every weapon attack and damage
//             modifier against zero (visible in-sheet as +0
//             attack on every weapon). The fixture confirmed
//             this field is set on a properly-built
//             Operative. Plus per-strategy match distribution
//             added to the conversion-log info line so the
//             user can see whether v0.6.0's canonical lookup
//             is firing or falling back to slug/fuzzy.
//           - 0.5.3: MODULE_VERSION 0.6.2 -> 0.6.3. Ground-truth-driven
//             corrections from inspecting two new fixtures:
//             fvtt-actor-bhelthal-operative-lvl1.json and -lvl5
//             .json (Foundry exports of fully-configured SF2e
//             Operatives, not HLO exports). Three fixes:
//             (1) v0.6.2's dedup looked for flags.pf2e.grantedBy
//             on grantees, which the fixtures showed is empty in
//             this system version - SF2e tracks the relationship
//             one-way via flags.sf2e.itemGrants on the granter.
//             Dedup now walks every item, collects all
//             itemGrants[*].id values, and treats referenced
//             items as auto-granted.
//             (2) Scaffold corrected against the real schema:
//             details.languages uses { value, details } not
//             { value, custom }, plus added details.keyability
//             (load-bearing for derived attack/damage modifiers),
//             details.alliance: "party", and details.xp.{min,max}.
//             (3) Two schema-snapshot files added documenting
//             the fixture-derived ground truth so future
//             iterations have a reference: sf2e-character-
//             required-fields.json bumped to schemaVersion 2,
//             new sf2e-item-grant-pattern.json captures the
//             granter-side itemGrants pattern.
//           - 0.5.2: MODULE_VERSION 0.6.1 -> 0.6.2. Post-Phase-1
//             deduplication. v0.6.1 silenced the SF2e wizard
//             prompts via noHook:true on grant-bearing embed,
//             but the auto-grant items still spawn (they fire
//             from the item's _onCreate, which noHook does
//             not suppress). That left visible duplicates:
//             HLO's chosen feat alongside the class's auto-
//             granted version. Fix: between Phase 1 (grant-
//             bearing embed) and Phase 2 (regular embed),
//             observe what the auto-grant pipelines spawned
//             and dedup HLO's pending items by (type, slug).
//             HLO's duplicate gets dropped; the system-
//             granted version stays because it has the proper
//             flags.pf2e.grantedBy linkage and SF2e relies on
//             that for grant-graph integrity.
//           - 0.5.1: MODULE_VERSION 0.6.0 -> 0.6.1. Grant-prompt
//             suppression. Grant-bearing items (ancestry,
//             class, heritage, deity, background) now embed
//             with noHook:true so SF2e/PF2e's auto-grant
//             pipeline does not pop a choice dialog asking
//             the user to pick what HLO already chose. Gated
//             on a new world-scope setting "Suppress grant
//             prompts during import" (default ON). Regular
//             items (feats/equipment/weapons/spells) still
//             embed with full hook firing so their effects
//             apply normally.
//           - 0.5.0: MODULE_VERSION 0.5.9 -> 0.6.0 (MINOR bump for new
//             architecture). Three v0.6.0 deliverables landed in
//             one cycle:
//             (1) Deterministic compendium-index lookup. New cog
//             matcher-pack-index.js walks every pack listed in
//             matcher-slug-table COMPSET_TO_PACKS for the active
//             system and produces a (compset, normalized-key)
//             -> {pack, slug, _id, name} Map. matcher-core
//             consults this map FIRST (strategy="canonical",
//             confidence 1.0) before the override / slug / fuzzy
//             pipeline. Resolves the four landmines from the
//             Noxora log by name match instead of slug guess.
//             (2) Background normalization. parser-actor.js
//             synthesizes a Background item from gameValues.
//             actBackgroundText so HLO's chosen background flows
//             through the standard matcher pipeline.
//             matcher-slug-table.js routes Background to the
//             pf2e.backgrounds / sf2e.backgrounds packs. Closes
//             the long-standing gap where backgrounds were
//             silently dropped.
//             (3) Reset Actor first checkbox in the dialog.
//             When checked, the existing-actor branch wipes
//             EVERY item on the actor (not just our flagged
//             ones) before re-importing. Recovery path for the
//             corrupted-actor case.
//           - 0.4.4: MODULE_VERSION 0.5.8 -> 0.5.9. Comprehensive scaffold
//             expansion + per-item flags.pf2e initialization +
//             resilient-delete on the existing-actor path.
//             Addresses the SF2e prepareActorData crashes from
//             import logs 2026-05-15T17:29:26 and 2026-05-15T18:
//             16:52: Ancestry/Class/Deity/Heritage/Feat items
//             could not embed because their prepare methods read
//             from system fields the scaffold did not include.
//             scaffoldSystemForCharacter() in ui-import-dialog.js
//             now seeds traits.size, details.class/ancestry/
//             heritage/deities/background, build.attributes.
//             boosts, attributes.ac/hp/speed, and several other
//             fields the SF2e prep cycle reads. ensureItemFlags()
//             initializes flags.pf2e on every embedded item.
//             _deleteItemsResilient() applies the same try-bulk-
//             then-per-item pattern as the create path, so the
//             "actor locks up on second import attempt" failure
//             no longer compounds.
//           - 0.4.3: MODULE_VERSION 0.5.7 -> 0.5.8. Cache-bust bump.
//             Something in Foundry Portable's per-module install
//             record cached the previous version string and was
//             refusing to pick up the v0.5.7 zip's three fixes.
//             No code or asset changes vs v0.5.7; this commit
//             only nudges the version label so Foundry's
//             installed-vs-manifest diff sees a delta and
//             re-pulls. Same lockstep cascade across module.json
//             (root + staged) and the shinra-cc-site landing
//             pages.
//           - 0.4.2: MODULE_VERSION 0.5.6 -> 0.5.7. Three field-test
//             fixes: (1) duplicate import button removed (only
//             inject into .window-header, dropping the fallback
//             that matched a body-internal <header>), (2) sheet
//             button locked to the light-gray icon (the dark-
//             purple theme variant rendered washed-out on PF2e/
//             SF2e light-mode headers in field testing), (3)
//             import pipeline made fault-tolerant via per-item
//             createEmbeddedDocuments fallback so a single
//             SF2e prepareActorData crash no longer bricks the
//             actor; and the system scaffold is now always
//             applied (not conditional) and covers a broader
//             set of fields (build.languages.value/granted/max,
//             details.languages.value, etc).
//           - 0.4.1: MODULE_VERSION 0.5.5 -> 0.5.6. Module.json author
//             block gained an "email": "admin@shinra.cc" field
//             for the install-info contact card Foundry surfaces
//             in Module Management. No code changes; metadata
//             only. Bump per the strict rule. Same lockstep
//             cascade across module.json (root + staged copy)
//             and the shinra-cc-site landing pages.
//           - 0.4.0: Wave 6 of the cog migration. Promoted from
//             src/util/version.js. No logic changes; constants
//             are unchanged. Three earlier-wave cogs (api-hlo-
//             client, import-find-existing-actor, import-
//             conversion-journal) and the four other Wave 6
//             cogs all updated to import from ./util-version.js
//             instead of ../util/version.js. main.js bootstrap
//             import also repointed.
//           - 0.3.4: MODULE_VERSION 0.5.3 -> 0.5.4. Wave 3 of
//             the cog migration: src/builder/ removed entirely;
//             5 new cogs added (builder-actor-pf2e, builder-
//             actor-sf2e, builder-attachments, builder-hp,
//             builder-items). builder-actor-sf2e re-imports 11
//             names from builder-actor-pf2e (5 constants + 6
//             helpers); the SF2e cog is intentionally a thin
//             overlay on the
//             PF2e chassis, not a fork. Consumers repointed
//             (src/ui/import-dialog.js + 2 tools/* test scripts).
//             All three test scripts pass. Total cogs in
//             src/cogs/: 26.
//           - 0.3.3: MODULE_VERSION 0.5.2 -> 0.5.3. Wave 2 of the
//             cog migration: src/matcher/ removed entirely; 6 new
//             cogs added (matcher-core, matcher-slug-table,
//             matcher-overrides, matcher-fuzzy, matcher-foundry-
//             resolver, matcher-mock-resolver). All consumers
//             repointed (src/ui/import-dialog.js + 3 tools/* test
//             scripts + 2 comment-only refs in extract-overrides).
//             Internal cog imports use sibling ./matcher-X.js form,
//             same as Wave 1's parser-* cogs. Total cogs in
//             src/cogs/: 21. All three test scripts pass (sanity,
//             parse:noxora, parse:fighter).
//           - 0.3.2: MODULE_VERSION 0.5.1 -> 0.5.2. Side-quest
//             deliverable: FOUNDRY_SUBMISSION.md added at the
//             project root (Foundry package submission plan with
//             field-by-field draft, content-policy compliance notes
//             under the March 18 2026 revision, and Markdown +
//             HTML Description variants). No code changes; bump
//             per the strict rule.
//           - 0.3.1: MODULE_VERSION 0.5.0 -> 0.5.1. Wave 1 of the cog
//             mass-migration: parser/ folder removed entirely; 14
//             new cogs added (parser-portfolio, parser-actor,
//             parser-items, parser-actor-type, parser-compset-
//             registry, plus 9 per-compset cogs). Tests still pass
//             (parse-noxora, parse-pf2e-fighter, sanity-check now
//             import from src/cogs/). Total cogs in src/cogs/: 15.
//           - 0.3.0: MODULE_VERSION 0.4.6 -> 0.5.0 (minor bump). Architectural
//             pivot: started cog migration. system-detection.js is
//             the pilot cog; parse-actor.js and compsets/class.js now
//             import from it instead of duplicating the SF2e class
//             set locally. tools/regenerate-cog-index.mjs scans
//             src/cogs/ at build time. src/schema-snapshots/ kicked
//             off with the SF2e character-required-fields snapshot.
//           - 0.2.5: MODULE_VERSION 0.4.5 -> 0.4.6 per the strict version-bump
//             rule. This release fixes the SF2e Soldier mis-detection
//             (parser SF2E_CLASS_TRAITS was missing clSoldier, so all
//             Soldier characters fell through to the pf2e default and
//             matched zero items) and switches the Download Log button
//             from raw <a download> + blob URL to foundry.utils.
//             saveDataToFile (the blob path was being treated as an
//             Electron navigation, prompting "Get an app to open this
//             blob link" instead of saving).
//           - 0.2.4: MODULE_VERSION 0.4.4 -> 0.4.5 per the strict version-bump
//             rule. Same lockstep cascade. Tooling change this release:
//             deploy-shinra.sh stripped of all rsync/SFTP/automated
//             upload paths (every upload is manual via WinSCP), and
//             stage_uploads now stages only the current version's zip.
//           - 0.2.3: MODULE_VERSION 0.4.3 -> 0.4.4 per the strict version-bump
//             rule. Same lockstep cascade. This release also adds the
//             fileStagingArea/ requirement to the deploy pipeline; the
//             folder is regenerated on every deploy:full so I have
//             a ready-to-drag set of "files that changed this round."
//           - 0.2.2: MODULE_VERSION 0.4.2 -> 0.4.3 per the strict version-bump
//             rule. Same lockstep cascade as before (module.json
//             version + download, shinra-cc-site staged copy and its
//             landing pages).
//           - 0.2.1: MODULE_VERSION 0.4.1 -> 0.4.2 per the strict version-bump
//             rule (every change-cycle bumps). module.json "version"
//             and "download" URL move in lockstep, plus the staged
//             shinra-cc-site copy and its landing-page references.
//           - 0.2.0: Removed MODULE_BUILD. It existed only as a
//             workaround for module.json's "version" being frozen at
//             0.0.1. Now that module.json "version" is bumped on every
//             update (standing rule, 2026-05-14), MODULE_VERSION simply
//             mirrors it and feeds the on-screen badge directly. One
//             version number, no second source of truth that can drift.
//           - 0.1.0: Added MODULE_BUILD as a build tag (now removed).
//           - Phase 0, module identity constants

export const MODULE_ID = "hlo-importer-abyssal-engine";
export const MODULE_TITLE = "HeroLab to Foundry - Powered by Abyssal Engine";

// Keep MODULE_VERSION in lockstep with module.json "version": both are
// bumped on every update so Foundry's module list and the on-screen
// version badge agree on exactly which build is running.
export const MODULE_VERSION = "1.0.6";

// HLO Public API. The tool name is stable (no version numbers, per LWD docs).
// Whatever string is passed when acquiring the access token may be surfaced
// publicly inside HLO, so this is a brand-visible identifier.
export const HLO_API_BASE = "https://api.herolab.online";
export const HLO_TOOL_NAME = "HeroLab to Foundry - Powered by Abyssal Engine";

// Recognized Foundry system ids the module reacts to. The SF2e id is a working
// assumption pending verification against the live Foundry package registry.
export const SUPPORTED_SYSTEMS = Object.freeze(["pf2e", "sf2e"]);
