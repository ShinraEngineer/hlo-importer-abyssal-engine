// ============================================================
// COG: parser-compset-abilities.js - Stat-bearing compset handlers
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-28
// Revision: 0.1.1
//           - 0.1.1: Reserves reads rvMax / rvCurrent, the names HLO exports, with
//             trkMaximum / trkValue as the fallback (audit B5). Until now
//             every Reserves pool parsed as null, so the SF2e focus pool and
//             current hit points never reached the actor.
//           - Migrated from src/parser/compsets/abilities.js as part
//             of the cog architecture pivot. Handles AbilScore, Save,
//             Skill, ArmorClass, Movement, Reserves, Derived.
//
// HLO stat conventions used here:
//   stNet            current total value
//   stAbScModifier   ability score modifier component
//   stDC             derived DC (10 + bonus, or similar)
//   stMiscMod        miscellaneous modifier
//   proLevelBonNet   proficiency + level bonus
//   ProfLevel        "Untrained" | "Trained" | "Expert" | "Master" | "Legendary"

const PROFICIENCY_RANKS = {
  Untrained:   0,
  Trained:     1,
  Expert:      2,
  Master:      3,
  Legendary:   4,
};

function rankFor(profLevel) {
  if (profLevel == null) return null;
  return PROFICIENCY_RANKS[profLevel] ?? null;
}

function baseStats(raw) {
  return {
    stNet:            raw.stNet            ?? null,
    stAbScModifier:   raw.stAbScModifier   ?? null,
    stDC:             raw.stDC             ?? null,
    stMiscMod:        raw.stMiscMod        ?? null,
    proLevelBonNet:   raw.proLevelBonNet   ?? null,
    profLevel:        raw.ProfLevel        ?? null,
    proficiencyRank:  rankFor(raw.ProfLevel),
  };
}

export const AbilScore = {
  normalize(raw, _warnings) {
    // AbilScore is the simplest: stNet is the raw score (10, 14, 18, ...).
    return {
      score: raw.stNet ?? null,
      modifier: raw.stNet != null ? Math.floor((raw.stNet - 10) / 2) : null,
    };
  },
};

export const Save = {
  normalize(raw, _warnings) {
    return baseStats(raw);
  },
};

export const Skill = {
  normalize(raw, _warnings) {
    return baseStats(raw);
  },
};

export const ArmorClass = {
  normalize(raw, _warnings) {
    return baseStats(raw);
  },
};

export const Movement = {
  normalize(raw, _warnings) {
    // Movement uses stNet as the current speed value.
    return {
      speed: raw.stNet ?? null,
      stMiscMod: raw.stMiscMod ?? null,
    };
  },
};

export const Reserves = {
  normalize(raw, _warnings) {
    // Reserves carries pool tracking: Hit Points, Hero Points, Focus
    // Points. HLO exports the pool as rvMax / rvCurrent (verified in the
    // Noxora export: rvHitPoints.256 rvMax 26 rvCurrent 26, rvHeroPoints.54
    // rvMax 3 rvCurrent 1); the trk* names are kept as a fallback. The IR
    // field names stay trkMaximum / trkValue for the existing consumers.
    return {
      trkMaximum: raw.rvMax ?? raw.trkMaximum ?? null,
      trkValue: raw.rvCurrent ?? raw.trkValue ?? null,
    };
  },
};

export const Derived = {
  normalize(raw, _warnings) {
    // Catch-all for computed stats that do not fit a more specific compset.
    return baseStats(raw);
  },
};

export default { id: "parser-compset-abilities" };
