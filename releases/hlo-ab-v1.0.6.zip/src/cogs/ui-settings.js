// ============================================================
// COG: ui-settings.js - Foundry module settings registration
//                       (User Token, fuzzy threshold, log toggle,
//                        grant-prompt suppression)
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-29
// Revision: 0.3.1
//           - 0.3.1: SETTING_USER_TOKEN is config:false (no cleartext text box in
//             the settings sheet) and setUserToken() lets the import dialog
//             persist a pasted token after a successful exchange (audit C7).
//           - v0.6.1: new SETTING_SUPPRESS_GRANT_PROMPTS toggle.
//             When enabled (default), grant-bearing items
//             (ancestry, class, heritage, deity, background)
//             are embedded with noHook:true so SF2e/PF2e's
//             auto-grant pipeline does not pop a choice dialog
//             for each unfilled slot. HLO already chose those,
//             so prompting again duplicates work the user did
//             in HLO. Off-switch is exposed for users who DO
//             want SF2e to walk them through choice dialogs
//             after import.
//           - 0.2.0: Wave 6 of the cog migration. Promoted from
//             src/ui/settings.js. Internal import repointed at
//             sibling cog ./util-version.js. No logic changes.
//           - 0.1.0: Phase 4 (in src/ui/), module settings
//             registration. The HLO External Integration User
//             Token (JWT refresh token) is stored per-client so
//             each Foundry user manages their own credential.
//             Element tokens are per-character and entered fresh
//             at import time, never persisted.

import { MODULE_ID } from "./util-version.js";

export const SETTING_USER_TOKEN = "userToken";
export const SETTING_FUZZY_THRESHOLD = "fuzzyThreshold";
export const SETTING_LOG_TO_JOURNAL = "logToJournal";
export const SETTING_SUPPRESS_GRANT_PROMPTS = "suppressGrantPrompts";

export function registerSettings() {
  game.settings.register(MODULE_ID, SETTING_USER_TOKEN, {
    name: "HLO User Token (JWT)",
    hint:
      "Your HeroLab Online External Integration User Token. Obtain it from " +
      "HLO via Kebab Menu > Export/Integrate > Get User Token. Stored per " +
      "user, on this client only.",
    scope: "client",
    // Hidden from the settings sheet (0.3.1, audit C7): a String setting
    // renders there as a cleartext text box. The import dialog's password
    // field is the entry point; setUserToken persists it after the first
    // successful token exchange.
    config: false,
    type: String,
    default: "",
  });

  game.settings.register(MODULE_ID, SETTING_FUZZY_THRESHOLD, {
    name: "Fuzzy match threshold",
    hint:
      "Minimum similarity (0 to 1) for a fuzzy compendium match. Lower " +
      "values are more permissive; the default of 0.85 catches typos " +
      "without over-matching.",
    scope: "world",
    config: true,
    type: Number,
    default: 0.85,
    range: { min: 0.5, max: 1.0, step: 0.01 },
  });

  game.settings.register(MODULE_ID, SETTING_LOG_TO_JOURNAL, {
    name: "Save conversion log as Journal Entry",
    hint:
      "When enabled, every successful import creates a JournalEntry " +
      "with the full conversion log (matches by strategy, unmatched " +
      "items, warnings). Useful for tracking imports over time and " +
      "diagnosing mismatches after the dialog closes.",
    scope: "client",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register(MODULE_ID, SETTING_SUPPRESS_GRANT_PROMPTS, {
    name: "Suppress grant prompts during import",
    hint:
      "When enabled (default), grant-bearing items (ancestry, class, " +
      "heritage, deity, background) are embedded with hooks suppressed " +
      "so SF2e/PF2e's auto-grant pipeline does not pop a choice dialog " +
      "for each unfilled slot. HLO already gave us those choices, so " +
      "the wizard would be asking you to pick what you already picked. " +
      "Disable only if you want to walk through SF2e's chargen wizard " +
      "after import (e.g., to reconfigure a feat slot HLO did not fill).",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });
}

export function getUserToken() {
  return game.settings.get(MODULE_ID, SETTING_USER_TOKEN) ?? "";
}

/**
 * Persist the user token for this client. Called by the dialog once a
 * pasted token has produced an access token, so the user never has to
 * open the settings sheet (where the value would show in cleartext).
 */
export async function setUserToken(token) {
  await game.settings.set(MODULE_ID, SETTING_USER_TOKEN, String(token ?? ""));
}

export function getFuzzyThreshold() {
  const v = game.settings.get(MODULE_ID, SETTING_FUZZY_THRESHOLD);
  return typeof v === "number" ? v : 0.85;
}

export function getLogToJournal() {
  return Boolean(game.settings.get(MODULE_ID, SETTING_LOG_TO_JOURNAL));
}

export function getSuppressGrantPrompts() {
  // Default true matches the registered default. The undefined-coalesce
  // guard below is dead code in normal operation: v0.6.7 audit (see
  // docs/FOUNDRY_API_NOTES.md, Settings section) confirmed
  // game.settings.get THROWS "This is not a registered game setting"
  // when called pre-registration rather than returning undefined.
  // Guard kept as harmless defense in case any future refactor moves
  // the call site to a path that runs before registerSettings.
  const v = game.settings.get(MODULE_ID, SETTING_SUPPRESS_GRANT_PROMPTS);
  return v === undefined ? true : Boolean(v);
}
