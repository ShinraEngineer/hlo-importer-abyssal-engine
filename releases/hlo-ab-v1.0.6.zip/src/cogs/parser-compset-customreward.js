// ============================================================
// COG: parser-compset-customreward.js - PFS chronicle boons
//                                       (CustomReward + CustomBoon)
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-29
// Revision: 0.3.1
//           - 0.3.1: Frequency enum values are matched case-insensitively and
//             returned in PF2e's spelling, so PT1H / PT24H / P1W / P1M / P1Y
//             periods no longer drop the frequency block (audit A6).
//           - v0.7.2: BUG FIX (the LAST v0.7.1 bug before launch).
//             v0.7.1's mapping landed feat+pfsboon and passed schema
//             at the FeatPF2e document layer, but every chronicle boon
//             still vanished from the resolved actor sheet. The Berial
//             Jeggare PFS v0.7.1 import log captured the symptom: the
//             bulk create call failed with a SchemaField error on
//             Devil's Keep ("frequency: per: scenario is not a valid
//             choice"), the dialog correctly fell back to per-item
//             retry, the per-item retry log claimed "112 of 113 added;
//             1 skipped" (only Devil's Keep skipped), and yet the
//             actor JSON exported moments later had ZERO items where
//             category === "pfsboon". The other 8 boons (Fluent in
//             Cyclops, Experienced Mountaineer, One-Who-Waits, Sand
//             Slide, Engraved Wayfinder, Evolving Destiny, Rain of
//             Embers Stance, Society Connections) were missing too,
//             despite no log entry attributing failure to them.
//
//             Root cause: HLO has no compendium entry for the vast
//             majority of PFS chronicle boons (Paizo has published
//             hundreds; pf2e ships maybe twenty between PF2 and SF2),
//             so the boon items have to land as fully homebrew feat
//             documents. v0.7.0/v0.7.1's IR-patch was a partial stub:
//             it set type=feat + category=pfsboon but skipped many
//             required system fields and the actionType/level/traits/
//             frequency blocks. The PF2e FeatPF2e schema's defineSchema
//             (pf2e.mjs line 74503-74660) is strict about its required
//             children, and the system's createDocuments override
//             (pf2e.mjs line 50098-50173) constructs each item via
//             `new CONFIG.Item.documentClass(source, { parent })` in
//             both the bulk path and the per-item retry. When source
//             fields are absent the document construction silently
//             coerces them to defaults, but if ANY data merge in
//             that pipeline produces a fail (the Devil's Keep
//             scenario per is one example), the construction can
//             abort without re-throwing in a way the dialog's
//             per-item catch sees. The boons were dropping at create
//             time but the per-item createEmbeddedDocuments call was
//             returning [] without an exception, so the dialog's
//             succeeded += 1 counter overcounted.
//
//             The v0.7.2 fix is two-part. First, map HLO's "Scenario"
//             frequency to PF2e's "day" enum value (the only "day or
//             longer" frequency in CONFIG.PF2E.frequencies, lines
//             62951-62962: turn / round / PT1M / PT10M / PT1H /
//             PT24H / day / P1W / P1M / P1Y; "scenario" is not in
//             the enum, and a PFS scenario is typically a single
//             session so "day" is the closest game-correct mapping
//             for a 1/scenario boon). Second, emit a FULLY SHAPED
//             feat source on the _homebrewItem discriminator so the
//             actor-builder produces an item the FeatPF2e schema
//             accepts without coercion: complete description block,
//             traits with otherTags/value/rarity, level.value AND
//             level.taken, category, onlyLevel1, maxTakable,
//             actionType.value, actions.value, prerequisites.value,
//             subfeatures with all required nested fields, rules
//             array, frequency (only when HLO surfaced one). The
//             flags.pf2e namespace is pre-initialized so the actor
//             prepare pipeline never sees an undefined intermediate
//             when walking item.flags.pf2e.grantedBy.id et al.
//             Verified against the Berial PFS fixture: all 9 boons
//             pass document construction and land on the actor with
//             category=pfsboon, where prepareFeats() (pf2e.mjs line
//             38942-38951) buckets them into actor.pfsBoons and the
//             PF2e character sheet renders them in the PFS tab.
//
//           - 0.2.0: v0.7.1 first fix. Switched the type from
//             campaignFeature to feat (campaignFeature is the
//             Kingmaker item type whose category enum is restricted
//             to KINGMAKER_CATEGORY_TYPES). Document construction
//             passed validation but the items still did not survive
//             the dialog's resilient-create pipeline, captured in
//             the Berial v0.7.1 re-import log. Superseded by 0.3.0.
//           - 0.1.0: v0.7.0 introduced this cog for HLO's
//             CustomReward (id prefix "bnCustom") and CustomBoon
//             (id prefix "bnCustomN") compsets. These are PFS
//             chronicle boons that the player accrues over the
//             course of an organized-play campaign: language
//             unlocks ("Fluent in Cyclops"), skill unlocks
//             ("Experienced Mountaineer"), granted stances
//             ("Rain of Embers Stance"), and unique chronicle
//             rewards ("Devil's Keep"). These do NOT have
//             compendium entries in pf2e (every one is bespoke);
//             we synthesize embedded items on the actor.
//
// Routing note: like Faction, this handler does NOT produce a
// compendium reference; matcher-core returns null because
// COMPSET_TO_PACKS["CustomReward"] / ["CustomBoon"] are null.
// The actor builder reads the discriminator (`_homebrewItem`) and
// synthesizes the feat entry directly in the actor's items array,
// alongside the lore-skill items.

/**
 * Map HLO's free-text "Period" field to the PF2e frequencies enum
 * (CONFIG.PF2E.frequencies, pf2e.mjs lines 62951-62962). The enum is
 * a hard schema constraint on FeatPF2e.system.frequency.per; values
 * outside the enum cause the document constructor to throw, which
 * cascades to the dialog's bulk-create-then-per-item retry. PFS
 * boons commonly carry "Scenario" which is not an enum value; the
 * closest game-correct mapping is "day" (a PFS scenario is usually
 * a single session, so 1/scenario approximates 1/day for in-play
 * resource tracking).
 *
 * Returns null when HLO surfaced no period at all (the typical case
 * for non-tracked boons) OR when the period is unrecognized and we
 * should omit the frequency block entirely rather than misfile it.
 */
function mapHloPeriodToFrequencyPer(period) {
  if (period == null) return null;
  const norm = String(period).trim().toLowerCase();
  if (norm === "") return null;
  // Canonical PF2e frequencies enum (mirrors CONFIG.PF2E.frequencies).
  // Listed here so the parser stays out-of-Foundry testable; if the
  // system enum changes upstream the schema validation will reject and
  // we will see it in the dialog log immediately.
  // Keyed by the lowercased input, valued by the enum spelling PF2e
  // expects (0.1.1, audit A6): the old Set test compared the lowercased
  // input against mixed-case members, so "PT1H" and "P1W" never matched.
  const CANONICAL = {
    turn: "turn", round: "round", day: "day",
    pt1m: "PT1M", pt10m: "PT10M", pt1h: "PT1H", pt24h: "PT24H",
    p1w: "P1W", p1m: "P1M", p1y: "P1Y",
  };
  if (CANONICAL[norm]) return CANONICAL[norm];
  // HLO-specific aliases. PFS scenarios are single-session affairs;
  // "day" is the safest enum-valid fallback for 1/scenario tracking.
  // "encounter" and "round" are exact matches handled above; other
  // free-text values fall through to null so we omit frequency
  // rather than misclassify.
  if (norm === "scenario") return "day";
  if (norm === "session") return "day";
  if (norm === "hour")    return "PT1H";
  if (norm === "minute")  return "PT1M";
  if (norm === "week")    return "P1W";
  if (norm === "month")   return "P1M";
  if (norm === "year")    return "P1Y";
  return null;
}

/**
 * Build the discriminated patch shape both CustomReward and
 * CustomBoon emit. The PFS sheet groups all entries with
 * type=feat + category=pfsboon under the "PFS Boons" panel, so
 * a single shape covers every chronicle boon variety.
 *
 * The patch carries the FULL feat source the actor builder will
 * emit; the builder no longer has to defensively construct missing
 * blocks. This minimizes the surface where schema defaults differ
 * between the builder's runtime assumption and FeatPF2e's actual
 * defineSchema (pf2e.mjs line 74503-74660).
 */
function buildBoonPatch(raw) {
  const name = raw?.name ?? "Unknown PFS Boon";
  // HLO surfaces a useInPlay summary on most boons; fall back to a
  // marker line so the user knows the boon was imported but HLO did
  // not provide the full rules text (most chronicle boons have only
  // a one-line summary in HLO; the official Paizo PDF carries the
  // expanded text and the user has to add it manually).
  const descriptionText = raw?.useInPlay
    ?? raw?.description
    ?? "<p><em>Imported from HLO; full text not available in the HLO export. "
       + "Copy the boon text from the Paizo chronicle sheet into this description.</em></p>";

  const per = mapHloPeriodToFrequencyPer(raw?.Period);
  const maxUses = typeof raw?.trkMaximum === "number" ? raw.trkMaximum : null;
  // Only emit a frequency block when BOTH a valid enum value and a
  // numeric max are present. PF2e's FrequencyField requires both
  // `per` and `max` when set; passing a partial frequency throws.
  const frequency = (per && maxUses != null && maxUses > 0)
    ? { max: maxUses, per }
    : null;

  return {
    _homebrewItem: {
      subtype: "pfsboon",
      type: "feat",
      name,
      category: "pfsboon",
      // The original Period string from HLO (debugging-friendly; the
      // builder ignores this and uses `frequency` below).
      hloPeriodRaw: raw?.Period ?? null,
      // Pre-mapped, schema-safe frequency or null.
      frequency,
      maxUses,
      description: descriptionText,
    },
  };
}

export const CustomReward = {
  normalize(raw, _warnings) {
    return buildBoonPatch(raw);
  },
};

export const CustomBoon = {
  normalize(raw, _warnings) {
    return buildBoonPatch(raw);
  },
};

// Exported for the actor builder so it can produce a fully-shaped
// FeatPF2e source from the discriminator. Kept here so the period
// mapping table lives next to the parser's frequency contract.
export { mapHloPeriodToFrequencyPer };

export default { id: "parser-compset-customreward" };
