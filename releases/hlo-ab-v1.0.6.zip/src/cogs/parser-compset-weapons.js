// ============================================================
// COG: parser-compset-weapons.js - Weapon family normalizers
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-28
// Revision: 0.2.1
//           - 0.2.1: Staff normalizer added (public issue 2). HLO files
//             quarterstaffs and magic staves under a separate Staff
//             compset with the wp id prefix; it reuses Weapon.normalize.
//           - Wired util-rune-parser into Weapon.normalize. HLO
//             ships weapons with the runes baked into the display
//             name ("+1 striking wounding bastard sword"); the
//             slug pipeline already strips precious-material
//             prefixes (matcher-slug-table step 3.6), but until
//             now the Weapon handler did not surface the runes,
//             so the resulting Foundry weapon landed with
//             runes.potency=0, runes.striking=0, property=[]
//             (caught 2026-05-16 against Berial Jeggare's bastard
//             sword). The handler now stores parsed runes on the
//             IR as { runes: { potency, striking, propertyRunes,
//             baseName, matchedRunes } } so the builder layer can
//             plumb them through to system.runes on the Foundry
//             item, and the matcher can use baseName as the
//             canonical lookup string. The HLO field grBulk is
//             also surfaced so the builder can use it when
//             populating system.bulk.value, mirroring Armor and
//             GearBasic. The NaturalWep, WeaponTrait, and
//             Ammunition handlers are untouched; natural weapons
//             never carry runes, and traits/ammo do not need them.
//           - 0.1.0: Migrated from src/parser/compsets/weapons.js as part of
//             the cog architecture pivot. Weapon, NaturalWep,
//             WeaponTrait, Ammunition cluster together: Weapon and
//             NaturalWep both produce equipment-pack matches; traits
//             and ammo arrive as nested items that need their own
//             slots in the actor build (typically attached via
//             flags.pf2e.attached on PF2e).

import { extractRunes } from "./util-rune-parser.js";

export const Weapon = {
  normalize(raw, _warnings) {
    const runes = extractRunes(raw?.name ?? "");
    return {
      proLevelBonNet:   raw.proLevelBonNet ?? null,
      grBulk:           raw.grBulk ?? null,
      wpReach:          raw.wpReach ?? null,
      profLevel:        raw.ProfLevel ?? null,
      runes,
    };
  },
};

// HLO files quarterstaffs and magic staves ("Staff", "Staff of Fire
// (Lesser)") under a separate "Staff" compset with the weapon id prefix
// (wpStaff.687). The export shape is the Weapon shape, so the Weapon
// normalizer is reused as is: extractRunes still strips a potency
// prefix, and the slug pipeline resolves "staff" and
// "staff-of-fire-lesser" in the equipment packs.
export const Staff = {
  normalize(raw, warnings) {
    return Weapon.normalize(raw, warnings);
  },
};

export const NaturalWep = {
  normalize(raw, _warnings) {
    return {
      proLevelBonNet:   raw.proLevelBonNet ?? null,
      profLevel:        raw.ProfLevel ?? null,
    };
  },
};

export const WeaponTrait = {
  normalize(raw, _warnings) {
    return {
      components:       raw.components ?? null,
    };
  },
};

export const Ammunition = {
  normalize(raw, _warnings) {
    return {
      stackQty:         raw.stackQty ?? null,
      trkMaximum:       raw.trkMaximum ?? null,
      period:           raw.Period ?? null,
    };
  },
};

export default { id: "parser-compset-weapons" };
