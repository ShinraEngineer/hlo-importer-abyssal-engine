// ============================================================
// COG: parser-compset-feats.js - Feat / Action / Ability normalizers
// ============================================================
// Author:   Shinra CC
// Date:     2026-10-29
// Revision: 0.1.1
//           - 0.1.1: actionCostFor decodes the Action1 / Action2 / Action3 / Reaction
//             / Free codes real HLO exports carry (audit A13).
//           - Migrated from src/parser/compsets/feats.js as part of
//             the cog architecture pivot. All three share the same
//             "discrete game widget on the character" feel and route
//             to the actions or feats compendium packs depending on
//             context.
//
// HLO fields of interest:
//   reqLevelNet         level requirement
//   rePrerequisites     prose prerequisites (e.g. "expert in Society")
//   vaDC                fixed DC if the feat carries one
//   Action              action cost code: "A" (1), "AA" (2), "AAA" (3),
//                       "R" (reaction), "F" (free action)
//   Period              recharge cadence ("Recharge", "Charges", "Daily")
//   trkMaximum          numeric maximum for tracked resources

function actionCostFor(code) {
  // Real exports carry "Action1" / "Action2" / "Action3" / "Reaction" /
  // "Free" (audit A13); the single-letter codes are kept for the
  // synthetic fixtures.
  switch (code) {
    case "A":
    case "Action1":    return 1;
    case "AA":
    case "Action2":    return 2;
    case "AAA":
    case "Action3":    return 3;
    case "R":
    case "Reaction":   return "reaction";
    case "F":
    case "Free":
    case "FreeAction": return "free";
    default:           return null;
  }
}

export const Feat = {
  normalize(raw, _warnings) {
    return {
      reqLevelNet:      raw.reqLevelNet ?? null,
      prerequisites:    raw.rePrerequisites ?? null,
      vaDC:             raw.vaDC ?? null,
      actionCost:       actionCostFor(raw.Action),
      actionRaw:        raw.Action ?? null,
    };
  },
};

export const Action = {
  normalize(raw, _warnings) {
    return {
      actionCost:       actionCostFor(raw.Action),
      actionRaw:        raw.Action ?? null,
      vaDC:             raw.vaDC ?? null,
      vaSave:           raw.vaSave ?? null,
      vaRangeText:      raw.vaRangeText ?? null,
      vaTarget:         raw.vaTarget ?? null,
    };
  },
};

export const Ability = {
  normalize(raw, _warnings) {
    return {
      period:           raw.Period ?? null,
      trkMaximum:       raw.trkMaximum ?? null,
      trkValue:         raw.trkValue ?? null,
      components:       raw.components ?? null,
      vaDC:             raw.vaDC ?? null,
    };
  },
};

export default { id: "parser-compset-feats" };
