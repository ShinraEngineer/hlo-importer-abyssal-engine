// ============================================================
// COG: matcher-mock-resolver.js - In-memory resolver + Noxora
//                                 test index for Node harness
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.4.0
//           - SF2e equipment audit (2026-05-16). Expanded the
//             sf2e.equipment mock from two entries (Plasma Caster,
//             Second Skin) to sixteen so the Noxora harness exercises
//             the full equipment routing path. Weapon, Armor,
//             Augmentation, Upgrade, GearBasic, and Ammunition
//             compsets all now produce slug hits in the harness
//             instead of false-positive misses. Verified against the
//             2026-05-16 V14 sf2e v1.1.2 pack-index dumps that HLO's
//             comma-tier form ("Battery, commercial", "Bipod,
//             tactical", "Filtered rebreather, commercial") slugifies
//             to the same kebab as Foundry's paren form ("Battery
//             (Commercial)", "Bipod (Tactical)", "Filtered Rebreather
//             (Commercial)"), so no overrides are required for any
//             of the seventeen Noxora-emitted equipment items.
//           - 0.3.0: SF2e actions audit (2026-05-16). Populated the test
//             index with the SF2e action / class-feature / ancestry-
//             feature slugs Noxora actually surfaces so the Node
//             harness mirrors the Foundry pack-index lookup result.
//             Specifically: sf2e.actions gains aim / sabotage /
//             treat-wounds (verified present in the 2026-05-16
//             V14 pack-index dumps under sf2e v1.1.2);
//             sf2e.class-features gains infiltrator (Operative
//             class feature); sf2e.ancestry-features gains
//             limited-telepathy (Lashunta-style ancestry feat).
//             These items were appearing in the MISSES section of
//             parse:noxora purely because the mock had no entries
//             for them, not because of a real matcher gap. Inside
//             Foundry the deterministic pack-index lookup hits
//             them via normalizeKey (which strips DC/distance
//             parentheticals like "Treat Wounds (2d8, DC 15)" and
//             "Limited Telepathy 30 ft."). The slug-pipeline name
//             fallback ("Aim", "Sabotage") also resolves them
//             when the deterministic index is unavailable.
//           - 0.2.0: Wave 2 of the cog migration. Promoted from
//             src/matcher/mock-resolver.js. No logic changes;
//             only the file location and header are new.
//           - 0.1.0: Phase 1 (in src/matcher/). In-memory resolver
//             used by the Node test harness. Loads a minimal
//             hand-rolled index for the slugs Noxora is expected
//             to surface so the matcher can be exercised without
//             a live Foundry world. Inside Foundry we use
//             makeFoundryResolver from matcher-foundry-resolver.js
//             instead.

/**
 * Build a mock resolver from a plain object index of the form:
 *
 *   {
 *     "pf2e.ancestries": [{ name: "Human", slug: "human" }, ...],
 *     "sf2e.classes": [{ name: "Operative", slug: "operative" }, ...],
 *     ...
 *   }
 *
 * The resolver answers `bySlug` and `index` calls against this static data.
 */
export function makeMockResolver(packData) {
  const data = packData ?? {};
  return {
    async index(packId) {
      return data[packId] ?? [];
    },
    async bySlug(packId, slug) {
      const entries = data[packId] ?? [];
      return entries.find((e) => e.slug === slug) ?? null;
    },
  };
}

/**
 * A minimal index covering the Phase 1 compsets for Noxora plus a few PF2e
 * classics. Not exhaustive; the goal is to exercise the matcher's slug,
 * fuzzy, and override paths against representative data.
 */
export const NOXORA_TEST_INDEX = {
  // SF2e ancestries / heritages / classes.
  "sf2e.ancestries": [
    { name: "Human",      slug: "human" },
    { name: "Android",    slug: "android" },
    { name: "Kasatha",    slug: "kasatha" },
    { name: "Lashunta",   slug: "lashunta" },
    { name: "Shirren",    slug: "shirren" },
    { name: "Vesk",       slug: "vesk" },
  ],
  "sf2e.heritages": [
    { name: "Prismeni",   slug: "prismeni" },
    { name: "Skilled Heritage", slug: "skilled-heritage" },
    { name: "Versatile Heritage", slug: "versatile-heritage" },
  ],
  "sf2e.classes": [
    { name: "Operative",      slug: "operative" },
    { name: "Technomancer",   slug: "technomancer" },
    { name: "Mystic",         slug: "mystic" },
    { name: "Solarian",       slug: "solarian" },
    { name: "Envoy",          slug: "envoy" },
    { name: "Witchwarper",    slug: "witchwarper" },
  ],
  "sf2e.deities": [
    { name: "Zon-Shelyn",         slug: "zon-shelyn" },
    { name: "Sarenrae",           slug: "sarenrae" },
    { name: "Iomedae",            slug: "iomedae" },
  ],
  "sf2e.feats": [
    { name: "Digital Ambassador", slug: "digital-ambassador" },
    { name: "Skill Training",     slug: "skill-training" },
    { name: "Toughness",          slug: "toughness" },
  ],
  "sf2e.spells": [
    { name: "Electric Arc",       slug: "electric-arc" },
  ],
  // SF2e equipment covers Weapon, Armor, Augmentation, Upgrade,
  // GearBasic, and Ammunition compsets. Entries sampled from the
  // 2026-05-16 V14 sf2e v1.1.2 pack-index dump; the audit verified that
  // HLO's comma-tier form ("Battery, commercial") slugifies to the
  // same kebab as Foundry's paren form ("Battery (Commercial)" ->
  // battery-commercial), so no overrides are needed for these.
  "sf2e.equipment": [
    // Weapons.
    { name: "Plasma Caster",                  slug: "plasma-caster" },
    { name: "Polyglove",                      slug: "polyglove" },
    { name: "Shirren-eye Rifle",              slug: "shirren-eye-rifle" },
    // Armor + shields.
    { name: "Second Skin",                    slug: "second-skin" },
    { name: "Deflecting Field",               slug: "deflecting-field" },
    // Augmentations (biotech/magitech/necrograft families in SF2e).
    { name: "Photosynthetic Skin",            slug: "photosynthetic-skin" },
    { name: "Telepathy Node",                 slug: "telepathy-node" },
    // Upgrades (armor + weapon upgrades; tier suffix in HLO is comma form).
    { name: "Basic Environmental Protection", slug: "basic-environmental-protection" },
    { name: "Filtered Rebreather (Commercial)", slug: "filtered-rebreather-commercial" },
    { name: "Bipod (Tactical)",               slug: "bipod-tactical" },
    // Gear (GearBasic compset; tools, containers, household).
    { name: "Comm Unit",                      slug: "comm-unit" },
    { name: "Container (Ordinary)",           slug: "container-ordinary" },
    { name: "Climbing Kit (Commercial)",      slug: "climbing-kit-commercial" },
    { name: "Explorer's Canteen",             slug: "explorers-canteen" },
    { name: "Hygiene Kit",                    slug: "hygiene-kit" },
    // Ammunition (battery, chem tank, etc; tier suffix as above).
    { name: "Battery (Commercial)",           slug: "battery-commercial" },
  ],

  // SF2e actions (verified present in the 2026-05-16 pack-index dump,
  // sf2e v1.1.2). HLO emits Aim/Sabotage with compset=Action and slug
  // abAimOpr / abSabotageOpr; the slug-pipeline cannot strip the `ab`
  // prefix because Action's prefix is `ac`, so resolution falls through
  // to the name-derived slug ("aim", "sabotage") -- which is the path
  // these entries unblock. Treat Wounds rides the Ability route into
  // sf2e.actions via the deterministic pack index (parentheticals like
  // "(2d8, DC 15)" stripped by normalizeKey).
  "sf2e.actions": [
    { name: "Aim",          slug: "aim" },
    { name: "Sabotage",     slug: "sabotage" },
    { name: "Treat Wounds", slug: "treat-wounds" },
  ],

  // Operative class features. HLO emits abInfiltratorOpr with
  // compset=Ability; the Ability compset routes to class-features in
  // matcher-slug-table.js.
  "sf2e.class-features": [
    { name: "Infiltrator", slug: "infiltrator" },
  ],

  // SF2e ancestry features that HLO surfaces via the Ability compset.
  // Limited Telepathy comes through as "Limited Telepathy 30 ft." and
  // is stripped to "limited-telepathy" by normalizeKey at lookup time.
  "sf2e.ancestry-features": [
    { name: "Limited Telepathy", slug: "limited-telepathy" },
  ],

  // PF2e equivalents (subset, for fallback scenarios and the synthetic
  // PF2e fixture). Pack names use the legacy logical names from PF2e
  // v7.12.2's system.json: feats-srd, spells-srd, equipment-srd,
  // actionspf2e, classfeatures (no hyphen), ancestryfeatures (no hyphen),
  // conditionitems.
  "pf2e.ancestries": [
    { name: "Human",     slug: "human" },
    { name: "Dwarf",     slug: "dwarf" },
    { name: "Elf",       slug: "elf" },
    { name: "Goblin",    slug: "goblin" },
    { name: "Gnome",     slug: "gnome" },
    { name: "Halfling",  slug: "halfling" },
  ],
  "pf2e.heritages": [
    { name: "Ancient-Blooded Dwarf", slug: "ancient-blooded-dwarf" },
    { name: "Versatile Heritage",    slug: "versatile-heritage" },
  ],
  "pf2e.classes": [
    { name: "Champion",     slug: "champion" },
    { name: "Alchemist",    slug: "alchemist" },
    { name: "Rogue",        slug: "rogue" },
    { name: "Investigator", slug: "investigator" },
    { name: "Fighter",      slug: "fighter" },
    { name: "Wizard",       slug: "wizard" },
    { name: "Cleric",       slug: "cleric" },
  ],
  "pf2e.deities": [
    { name: "Torag",        slug: "torag" },
    { name: "Sarenrae",     slug: "sarenrae" },
    { name: "Iomedae",      slug: "iomedae" },
  ],
  "pf2e.feats-srd": [
    { name: "Power Attack",  slug: "power-attack" },
    { name: "Sudden Charge", slug: "sudden-charge" },
    { name: "Toughness",     slug: "toughness" },
  ],
  "pf2e.spells-srd": [
    { name: "Heal",     slug: "heal" },
    { name: "Fireball", slug: "fireball" },
  ],
  "pf2e.equipment-srd": [
    { name: "Warhammer",    slug: "warhammer" },
    { name: "Scale Mail",   slug: "scale-mail" },
  ],
  "pf2e.actionspf2e": [
    { name: "Strike",   slug: "strike" },
    { name: "Stride",   slug: "stride" },
  ],

  // Anachronism cross-system fallback samples. When system=sf2e but the
  // matcher cannot find a PF2e item in sf2e.* packs, it falls back here.
  "pf2e-anachronism.classes": [
    { name: "Wizard",  slug: "wizard" },
    { name: "Fighter", slug: "fighter" },
  ],
  "pf2e-anachronism.feats": [
    { name: "Toughness", slug: "toughness" },
  ],

  // When system=pf2e, SF2e content (Operative, augmentations) is reached
  // via sf2e-anachronism.* packs.
  "sf2e-anachronism.classes": [
    { name: "Operative",    slug: "operative" },
    { name: "Technomancer", slug: "technomancer" },
  ],
  "sf2e-anachronism.equipment": [
    { name: "Plasma Caster",       slug: "plasma-caster" },
    { name: "Photosynthetic Skin", slug: "photosynthetic-skin" },
  ],
};
