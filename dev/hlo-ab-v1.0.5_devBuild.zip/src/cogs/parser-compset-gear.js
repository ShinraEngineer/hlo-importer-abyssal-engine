// ============================================================
// COG: parser-compset-gear.js - GearBasic + Trait normalizers
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - Migrated from src/parser/compsets/gear.js as part of
//             the cog architecture pivot. Anything that does not
//             carry mechanical complexity (a backpack, a hygiene
//             kit, a container) lives here. The matcher routes it
//             to the equipment pack just like weapons and armor.

export const GearBasic = {
  normalize(raw, _warnings) {
    return {
      stackQty:         raw.stackQty ?? null,
      grBulk:           raw.grBulk ?? null,
    };
  },
};

export const Trait = {
  normalize(raw, _warnings) {
    // Standalone Trait items are usually descriptive tags applied at
    // the actor level (e.g., "Medium" creature size). We preserve
    // them but the builder treats them as flavor unless explicitly
    // modeled by Foundry.
    return {};
  },
};

export default { id: "parser-compset-gear" };
