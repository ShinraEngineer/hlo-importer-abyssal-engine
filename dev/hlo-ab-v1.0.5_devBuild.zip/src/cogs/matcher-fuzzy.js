// ============================================================
// COG: matcher-fuzzy.js - Levenshtein + token-overlap fuzzy
//                         name matcher for last-resort lookup
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.2.0
//           - Wave 2 of the cog migration. Promoted from
//             src/matcher/fuzzy.js. No logic changes; only the
//             file location and header are new.
//           - 0.1.0: Phase 1 (in src/matcher/). Fuzzy name matcher,
//             used as the last-resort lookup when slug candidates
//             miss and overrides have not fired. Goal: catch
//             typo'd names (curly apostrophe drift, the
//             "Catacylsm" / "Cataclysm" family) without
//             over-matching.
//
// Strategy: Levenshtein distance, normalized to a similarity ratio in
// [0, 1]. Names are pre-processed to lowercase, parentheticals stripped,
// apostrophes removed, runs of whitespace collapsed. A similarity score at
// or above DEFAULT_FUZZY_THRESHOLD counts as a candidate match.

export const DEFAULT_FUZZY_THRESHOLD = 0.85;

/**
 * Normalize a name for fuzzy comparison. Idempotent.
 */
export function normalizeName(name) {
  if (!name) return "";
  return name
    .replace(/\([^)]*\)/g, "")
    .replace(/[‘’']/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Levenshtein edit distance between two strings.
 */
export function levenshtein(a, b) {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const prev = new Array(b.length + 1);
  const curr = new Array(b.length + 1);
  for (let j = 0; j <= b.length; j++) prev[j] = j;
  for (let i = 1; i <= a.length; i++) {
    curr[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= b.length; j++) prev[j] = curr[j];
  }
  return prev[b.length];
}

/**
 * Similarity ratio in [0, 1], where 1.0 means equal after normalization.
 */
export function similarity(a, b) {
  const na = normalizeName(a);
  const nb = normalizeName(b);
  if (na === nb) return 1;
  const maxLen = Math.max(na.length, nb.length);
  if (maxLen === 0) return 1;
  return 1 - levenshtein(na, nb) / maxLen;
}

/**
 * Token-overlap ratio. Returns the Jaccard index of the normalized token
 * sets, in [0, 1]. Useful for catching word-reorder cases that pure edit
 * distance scores low (e.g. "Bipod, tactical" vs "Tactical Bipod").
 */
export function tokenOverlap(a, b) {
  const ta = new Set(normalizeName(a).split(/[^a-z0-9]+/).filter(Boolean));
  const tb = new Set(normalizeName(b).split(/[^a-z0-9]+/).filter(Boolean));
  if (ta.size === 0 && tb.size === 0) return 1;
  if (ta.size === 0 || tb.size === 0) return 0;
  let intersect = 0;
  for (const t of ta) if (tb.has(t)) intersect += 1;
  return intersect / (ta.size + tb.size - intersect);
}

/**
 * Find the best fuzzy match for `queryName` in `candidates`, where each
 * candidate is a `{ name, slug, pack }`-shaped record from a compendium
 * index. Combines Levenshtein similarity with token overlap and takes the
 * max so word-reorder matches still surface.
 *
 * @param {string} queryName
 * @param {Array<{name: string, slug?: string, pack?: string}>} candidates
 * @param {number} threshold
 * @returns {{ candidate: object, score: number } | null}
 */
export function bestFuzzyMatch(queryName, candidates, threshold = DEFAULT_FUZZY_THRESHOLD) {
  if (!queryName || !Array.isArray(candidates) || candidates.length === 0) return null;
  let best = null;
  for (const candidate of candidates) {
    const lev = similarity(queryName, candidate.name);
    const tok = tokenOverlap(queryName, candidate.name);
    const score = Math.max(lev, tok);
    if (score >= threshold && (best == null || score > best.score)) {
      best = { candidate, score };
    }
  }
  return best;
}
