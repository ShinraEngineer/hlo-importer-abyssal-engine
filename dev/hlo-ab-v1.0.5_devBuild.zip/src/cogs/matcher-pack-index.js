// ============================================================
// COG: matcher-pack-index.js - Deterministic compendium lookup
//                              built from live game.packs at first
//                              import; cached for the session
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.3.0
//           - PF2e ancestry-feats audit fix. lookupCanonical() now
//             tries a parens-PRESERVED normalize FIRST, then falls
//             through to the parens-stripped form. Without this,
//             HLO names like "Tusks (Orc)" and "Tusks (Half-Orc)"
//             both normalised to "tusks" and collided on the same
//             index key, so registerKey's first-wins behaviour
//             meant one heritage's feat silently routed to the
//             other's compendium entry. Verified against the
//             2026-05-16 V14 pf2e ancestry-feats index dump: 23
//             parenthetical heritage variants exist (Tusks (Orc)
//             vs Tusks (Half-Orc), Tree Climber (Elf) vs
//             Tree Climber (Goblin), Eternal Wings (Nephilim) vs
//             Eternal Wings (Sylph), Irrepressible (Halfling) vs
//             Irrepressible (Nephilim), Trample (Centaur) vs
//             Trample (Sarangay), etc). All resolve correctly
//             when the parens-preserved normalize is tried first,
//             because the index already registers them by slug
//             ("tusks-orc", "tusks-half-orc") in addition to the
//             collapsed name key.
//           - 0.2.0: normalizeKey() now strips trailing distance and
//             duration suffixes (e.g. "30 ft.", "60 feet",
//             "1 day", "10 minutes"). HLO appends these to names
//             like "Limited Telepathy 30 ft." but the canonical
//             pack entries omit them ("Limited Telepathy"), so
//             the deterministic lookup missed. Verified safe
//             against the full SF2e + pf2e-anachronism index
//             (21 packs, ~16k entries): no canonical entry uses
//             a trailing unit suffix.
//           - 0.1.0:
//           - v0.6.0 introduces the deterministic lookup the user
//             explicitly asked for: "we have the HeroLab API and
//             we have the Foundry V14 JSON files; why are we
//             matching by guess?" Answer: now we do not. This cog
//             walks every pack listed in matcher-slug-table.js
//             COMPSET_TO_PACKS for the active system, asks each
//             pack for its full index (with system.slug + name +
//             type fields), and builds a Map keyed by (compset,
//             normalized-key) -> {fullPack, slug, _id, name}.
//             matcher-core.js consults this map FIRST, before the
//             override / slug-candidate / fuzzy pipeline. The
//             pre-existing pipeline stays in place as fallback so
//             the four landmines from zarmstrong's changelog
//             (Champion subclass promotion, "Catacylsm" typo,
//             etc.) keep working.
//
// Design notes:
//   - Built lazily on first call, not on Foundry init. Foundry's
//     init hook runs before game.packs is populated; even ready
//     hook can be too early on slow boots. ensurePackIndex() is
//     idempotent: first call kicks off the build and returns the
//     promise; subsequent calls return the cached promise/result.
//   - Index keys are normalized aggressively (lowercase, kebab,
//     parentheticals stripped, apostrophes removed) so
//     "Digital Ambassador (DC 15)" hits "digital-ambassador" the
//     same as "Digital Ambassador" would. We index under both
//     name AND slug so HLO callers can hit by either.
//   - Caching is per-session. Foundry restart rebuilds; that is
//     the right cadence because installed packs can change.

import { COMPSET_TO_PACKS, qualifyPackId, slugifyName } from "./matcher-slug-table.js";
import { logger } from "./util-logger.js";

/** Singleton index map. null until the first build completes. */
let _index = null;

/** In-flight build promise so concurrent ensurePackIndex calls share work. */
let _buildPromise = null;

/** Track which systems we have indexed this session (rebuild if asked again). */
let _indexedSystem = null;

/**
 * Ensure the pack index is built for the given system. Returns a Map
 * keyed by `${compset}:${normalizedKey}` -> {fullPack, slug, _id, name}.
 * Safe to call multiple times: the first call kicks off the build,
 * subsequent calls reuse the cached result.
 */
export async function ensurePackIndex(systemId) {
  if (_index && _indexedSystem === systemId) return _index;
  if (_buildPromise && _indexedSystem === systemId) return _buildPromise;
  _indexedSystem = systemId;
  _buildPromise = buildIndex(systemId).then((idx) => {
    _index = idx;
    _buildPromise = null;
    return idx;
  }).catch((err) => {
    _buildPromise = null;
    logger.error(`Pack-index build failed for ${systemId}:`, err);
    throw err;
  });
  return _buildPromise;
}

/**
 * Look up the canonical Foundry compendium reference for a parsed HLO
 * item. Returns {fullPack, slug, _id, name} or null if no deterministic
 * hit. Caller should fall through to the slug/fuzzy pipeline on null.
 *
 * Tries multiple normalized keys in order: HLO name (full), HLO name
 * with parentheticals stripped, HLO slug, HLO slug with compset prefix
 * stripped. First hit wins.
 */
export function lookupCanonical(item) {
  if (!_index || !item || !item.compset) return null;
  const compset = item.compset;
  // Each entry is [candidate, preserveParens?]. Parens-preserved tries fire
  // first so that "Tusks (Orc)" and "Tusks (Half-Orc)" resolve to their own
  // distinct compendium slugs (tusks-orc vs tusks-half-orc) instead of both
  // collapsing to "tusks" and colliding on whichever was registered first.
  const tries = [];
  if (item.name) {
    tries.push([item.name, true]);
    const stripped = item.name.replace(/\([^)]*\)/g, "").trim();
    if (stripped && stripped !== item.name) tries.push([stripped, false]);
  }
  if (item.slug) {
    tries.push([item.slug, false]);
    const desuffixed = item.slug.replace(/SF$/, "");
    if (desuffixed !== item.slug) tries.push([desuffixed, false]);
  }
  if (Array.isArray(item.traitIds)) {
    for (const tid of item.traitIds) tries.push([tid, false]);
  }
  for (const [candidate, preserveParens] of tries) {
    const key = normalizeKey(candidate, preserveParens);
    if (!key) continue;
    const hit = _index.get(`${compset}:${key}`);
    if (hit) return hit;
  }
  return null;
}

/**
 * Force-rebuild the index. Useful when the user adds a compendium pack
 * mid-session (rare, but possible). Not currently wired to the UI.
 */
export async function rebuildPackIndex(systemId) {
  _index = null;
  _buildPromise = null;
  _indexedSystem = null;
  return ensurePackIndex(systemId);
}

/** Diagnostic helper for the conversion log. */
export function packIndexStats() {
  if (!_index) return { built: false };
  const byCompset = {};
  for (const k of _index.keys()) {
    const compset = k.split(":")[0];
    byCompset[compset] = (byCompset[compset] ?? 0) + 1;
  }
  return { built: true, system: _indexedSystem, totalKeys: _index.size, byCompset };
}

// --- internals ---------------------------------------------------------------

async function buildIndex(systemId) {
  const out = new Map();
  const packIds = collectPackIds(systemId);
  for (const fullPack of packIds) {
    const pack = game?.packs?.get(fullPack);
    if (!pack) continue;
    let entries;
    try {
      entries = await pack.getIndex({ fields: ["system.slug", "type"] });
    } catch (err) {
      logger.warn(`Pack-index: failed to read ${fullPack}:`, err?.message ?? err);
      continue;
    }
    const compsetsForPack = compsetsThatRouteTo(fullPack, systemId);
    for (const entry of entries) {
      const slug = entry.system?.slug ?? slugifyName(entry.name);
      if (!slug) continue;
      const recordValue = {
        fullPack,
        slug,
        _id: entry._id,
        name: entry.name,
        type: entry.type ?? null,
      };
      // Index under EVERY compset that routes to this pack. A pack like
      // "actionspf2e" may serve both Action and Ability compsets; both
      // need to be reachable.
      for (const compset of compsetsForPack) {
        // Index by both name and slug so HLO can match by either.
        const nameKey = normalizeKey(entry.name);
        const slugKey = normalizeKey(slug);
        if (nameKey) registerKey(out, compset, nameKey, recordValue);
        if (slugKey) registerKey(out, compset, slugKey, recordValue);
      }
    }
  }
  logger.info(`[matcher-pack-index] built for ${systemId}: ${out.size} keys across ${packIds.size} pack(s).`);
  return out;
}

/** First wins: do not let a later pack overwrite an earlier hit on the same key. */
function registerKey(map, compset, key, value) {
  const k = `${compset}:${key}`;
  if (!map.has(k)) map.set(k, value);
}

function collectPackIds(systemId) {
  const set = new Set();
  for (const compset of Object.keys(COMPSET_TO_PACKS)) {
    const entry = COMPSET_TO_PACKS[compset];
    if (entry == null) continue;
    const list = Array.isArray(entry) ? entry : (entry[systemId] ?? []);
    for (const p of list) {
      const fullPack = qualifyPackId(systemId, p);
      if (fullPack) set.add(fullPack);
    }
  }
  return set;
}

function compsetsThatRouteTo(fullPack, systemId) {
  const out = [];
  for (const compset of Object.keys(COMPSET_TO_PACKS)) {
    const entry = COMPSET_TO_PACKS[compset];
    if (entry == null) continue;
    const list = Array.isArray(entry) ? entry : (entry[systemId] ?? []);
    for (const p of list) {
      if (qualifyPackId(systemId, p) === fullPack) {
        out.push(compset);
        break;
      }
    }
  }
  return out;
}

/**
 * Normalize a string to a canonical lookup key. Lowercase, parentheticals
 * stripped, apostrophes/curly-quotes removed, trailing distance/duration
 * suffixes stripped ("Limited Telepathy 30 ft." -> "limited-telepathy"),
 * runs of non-alphanumeric collapsed to single hyphens, leading/trailing
 * hyphens trimmed.
 *
 * The trailing-unit strip handles HLO's habit of baking range/duration
 * values into the item name (e.g. abTelepathy comes through as "Limited
 * Telepathy 30 ft."), while canonical pack entries omit the value. We
 * verified against the full SF2e + pf2e-anachronism index dump from
 * 2026-05-15 that no canonical entry trails with a unit suffix, so this
 * is non-destructive.
 */
function normalizeKey(s, preserveParens = false) {
  if (!s || typeof s !== "string") return "";
  let working = s;
  if (!preserveParens) working = working.replace(/\([^)]*\)/g, "");
  return working
    .replace(/[‘’']/g, "")
    .replace(/\s+\d+\s*(?:ft\.?|feet|sq\.?\s*ft\.?|square\s+feet|miles?|mi\.?|days?|hours?|minutes?|min\.?|rounds?|rd\.?)\s*$/i, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
