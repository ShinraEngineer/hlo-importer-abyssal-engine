// ============================================================
// COG: parser-compset-augmentations.js - Starfinder 2e augmentations
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - Migrated from src/parser/compsets/augmentations.js as
//             part of the cog architecture pivot. HLO surfaces
//             augmentations with the Augmentation compset and tags
//             them with traits like trtBiotech, trtCybernetic, etc.
//             SF2e Foundry stores them as equipment items with a
//             specific subtype; the matcher routes to the equipment
//             pack.

export const Augmentation = {
  normalize(raw, _warnings) {
    return {
      stackQty:         raw.stackQty ?? null,
      grBulk:           raw.grBulk ?? null,
    };
  },
};

export default { id: "parser-compset-augmentations" };
