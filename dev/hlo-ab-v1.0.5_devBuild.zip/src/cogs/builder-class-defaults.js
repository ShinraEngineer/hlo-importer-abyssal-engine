// ============================================================
// COG: builder-class-defaults.js - Class slug to default
//                                  key ability mapping +
//                                  other per-class derived
//                                  defaults
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - v0.6.4: introduced. Drives system.details.
//             keyability.value from the parsed class slug.
//             SF2e auto-derives every weapon attack and
//             damage modifier from this field; without it,
//             attacks compute against zero. The
//             fvtt-actor-bhelthal-operative-lvl1 fixture
//             confirmed details.keyability.value is set
//             to "dex" for Operative, "str" for the user's
//             rebuilt character with custom weapon (the
//             user's chosen variant). Standard class
//             defaults below come from Player Core 2 and
//             SF2e Player Core; classes with multiple
//             valid key abilities default to the most
//             common one and let the user override after
//             import.
//
// Tables also include the ability score the class card
// historically lists as the "key ability." Some classes
// (Champion, Fighter, Monk, Magus, Ranger, Witch, etc.)
// support multiple valid key abilities; the table picks
// the most-played default. Users can adjust on the sheet
// after import; this just keeps SF2e from rendering an
// actor with no derived attack modifiers.

/**
 * Per-class default key ability, keyed by the canonical
 * Foundry slug (lowercase kebab-case). Returns null for
 * unknown classes; caller falls back to the global default.
 */
export const CLASS_KEY_ABILITY = {
  // PF2e Player Core 2 classes
  alchemist: "int",
  barbarian: "str",
  bard: "cha",
  champion: "str",        // also dex; default str
  cleric: "wis",
  druid: "wis",
  fighter: "str",         // also dex; default str
  investigator: "int",
  kineticist: "con",
  magus: "int",           // also str; default int (most common spellsword)
  monk: "str",            // also dex; default str
  oracle: "cha",
  ranger: "dex",          // also str; default dex (most common ranged)
  rogue: "dex",           // most subclasses dex; thief is dex
  sorcerer: "cha",
  summoner: "cha",
  swashbuckler: "dex",
  thaumaturge: "cha",
  witch: "int",           // patrons vary; default int (lesson-of-mortality)
  wizard: "int",
  gunslinger: "dex",
  inventor: "int",
  animist: "wis",
  exemplar: "str",        // also dex/cha; default str (most published builds)
  runesmith: "int",

  // SF2e Player Core + Field Test classes
  envoy: "cha",
  mystic: "wis",
  operative: "dex",
  solarian: "cha",        // also str; default cha (most published builds)
  technomancer: "int",
  witchwarper: "int",
  soldier: "con",         // also str; default con (heavy-weapon focus)
  mechanic: "int",
  vanguard: "con",
};

/**
 * Resolve the key ability for a parsed class item. Accepts the
 * raw HLO class slug (with or without the "cl" prefix) or the
 * Foundry-canonical slug. Returns the lowercase three-letter
 * ability code (str/dex/con/int/wis/cha) or null if the class
 * is unknown to the table.
 *
 * @param {string|null|undefined} classSlug
 * @returns {string|null}
 */
export function keyAbilityForClass(classSlug) {
  if (!classSlug || typeof classSlug !== "string") return null;
  const norm = classSlug
    .replace(/^cl/, "")
    .replace(/SF$/i, "")
    .toLowerCase();
  return CLASS_KEY_ABILITY[norm] ?? null;
}
