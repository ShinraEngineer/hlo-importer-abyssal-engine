// ============================================================
// COG: matcher-core.js - Hybrid HLO -> Foundry match orchestrator
//                        (override -> slug -> fuzzy)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.3.0
//           - v0.6.0 deterministic-lookup integration. Added a
//             new top-of-pipeline pass that consults the live
//             pack index built by ./matcher-pack-index.js. The
//             index is populated lazily at first import by
//             ensurePackIndex(systemId); matcher-core does NOT
//             trigger that build, the dialog does. Match
//             strategy is "canonical" with confidence 1.0 when
//             the pack index hits, ahead of override / slug /
//             fuzzy. Override and slug strategies still run as
//             fallbacks for the four landmine families
//             (Champion subclass promotion, Catacylsm typo,
//             etc.) where deterministic lookup is the wrong
//             answer.
//           - 0.2.0: Wave 2 of the cog migration. Promoted from
//             src/matcher/matcher.js. Internal imports now point
//             at sibling cogs (./matcher-slug-table.js,
//             ./matcher-overrides.js, ./matcher-fuzzy.js). No
//             logic changes; this is a file-and-import move only.
//           - 0.1.0: Phase 1 (in src/matcher/). Hybrid match
//             orchestrator. The flow is:
//               1. Check the curated overrides table (highest
//                  confidence).
//               2. Generate slug candidates and try each against
//                  the compendium resolver, ordered by specificity.
//               3. If all slug attempts miss, run a fuzzy name
//                  match against the compendium index for the
//                  relevant pack(s).
//               4. If everything misses, return null with a
//                  structured reason so the UI can surface what
//                  was lost.
//
// The matcher is resolver-agnostic. Inside Foundry the resolver wraps
// `game.packs.get(pack).index` and `pack.getDocument(...)`. Outside Foundry
// (in the Node test harness) a MockResolver provides hand-rolled index data
// for the items we expect Noxora to surface.

import { COMPSET_TO_PACKS, slugCandidates, packsFor, qualifyPackId } from "./matcher-slug-table.js";
import { lookupOverride, isSkipByDesign } from "./matcher-overrides.js";
import { bestFuzzyMatch } from "./matcher-fuzzy.js";
import { lookupCanonical } from "./matcher-pack-index.js";

/**
 * @typedef {Object} CompendiumResolver
 * @property {(packId: string) => Promise<Array<{name: string, slug: string, uuid?: string}>>} index
 *   Returns an array of entries from the named pack.
 * @property {(packId: string, slug: string) => Promise<Object | null>} bySlug
 *   Returns a single entry (or null) for the slug in the pack.
 */

/**
 * Match a parsed HLO item to a Foundry compendium reference.
 *
 * @param {object} item     Normalized item IR from parser-items.js.
 * @param {string} systemId "pf2e" or "sf2e".
 * @param {CompendiumResolver} resolver
 * @returns {Promise<{
 *   strategy: "override" | "slug" | "fuzzy",
 *   pack: string,
 *   slug: string,
 *   confidence: number,
 *   entry?: object,
 * } | null>}
 */
export async function matchItem(item, systemId, resolver) {
  if (!item || !resolver) return null;

  // Pass 0: skip-by-design check. Items HLO sends that are NOT
  // compendium-eligible (system-auto-granted unarmed strikes, the
  // activation echoes of equipment upgrades) get a special skip
  // record so the conversion log can note the deliberate skip
  // without flagging it as a miss. Strategy "skip" so dialog code
  // can branch on it specifically.
  if (isSkipByDesign(item)) {
    return {
      strategy: "skip",
      pack: null,
      slug: item.slug ?? null,
      confidence: 1.0,
      entry: null,
      skipReason: "system-derived or auto-granted; not a compendium item",
    };
  }

  // Pass 1: deterministic pack-index lookup. This is the v0.6.0
  // architecture the user asked for: HLO names + Foundry pack indices
  // are both static data, so matching should be a Map.get(), not a
  // search. The index is built lazily by the dialog at first import.
  // Confidence 1.0 because there is no guesswork: the entry exists
  // in the live pack and the normalized key matched it exactly.
  const canonical = lookupCanonical(item);
  if (canonical) {
    const entry = await resolver.bySlug(canonical.fullPack, canonical.slug);
    return {
      strategy: "canonical",
      pack: canonical.fullPack,
      slug: canonical.slug,
      confidence: 1.0,
      entry: entry ?? null,
    };
  }

  const override = lookupOverride(item);
  if (override) {
    const fullPack = qualifyPackId(systemId, override.pack);
    const entry = await resolver.bySlug(fullPack, override.slug);
    return {
      strategy: "override",
      pack: fullPack,
      slug: override.slug,
      confidence: 1.0,
      entry: entry ?? null,
    };
  }

  const packs = packsFor(item.compset, systemId);
  if (!packs || packs.length === 0) {
    // No compendium lookup applies (stat-bearing or trait-only compset).
    return null;
  }

  const candidates = slugCandidates(item);

  // Slug-first pass. Honors qualifyPackId so already-namespaced entries
  // (Anachronism modules: "pf2e-anachronism.feats", etc.) bypass the
  // system-prefix step.
  for (const packBase of packs) {
    const fullPack = qualifyPackId(systemId, packBase);
    for (const slug of candidates) {
      const entry = await resolver.bySlug(fullPack, slug);
      if (entry) {
        return {
          strategy: "slug",
          pack: fullPack,
          slug,
          confidence: 0.95,
          entry,
        };
      }
    }
  }

  // Fuzzy-name fallback against each candidate pack.
  for (const packBase of packs) {
    const fullPack = qualifyPackId(systemId, packBase);
    const index = await resolver.index(fullPack);
    const match = bestFuzzyMatch(item.name, index);
    if (match) {
      return {
        strategy: "fuzzy",
        pack: fullPack,
        slug: match.candidate.slug,
        confidence: match.score,
        entry: match.candidate,
      };
    }
  }

  return null;
}

/**
 * Match every item on an ActorIR and return a parallel structure annotating
 * each item with its match result (or null). Caller is responsible for
 * deciding how to handle nulls (warning, skip, prompt user, etc.).
 */
export async function matchAll(actorIR, systemId, resolver) {
  const out = [];
  for (const item of actorIR.items) {
    const match = await matchItem(item, systemId, resolver);
    out.push({ item, match });
  }
  return out;
}
