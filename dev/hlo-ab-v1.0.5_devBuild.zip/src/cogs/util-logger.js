// ============================================================
// COG: util-logger.js - Console logging wrapper with module prefix
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - Wave 6 of the cog migration. Promoted from
//             src/util/logger.js. Internal import repointed at
//             sibling cog ./util-version.js. No logic changes.
//           - 0.0.1: Phase 0 (in src/util/), console logging
//             wrapper with module prefix.

import { MODULE_ID } from "./util-version.js";

const PREFIX = `[${MODULE_ID}]`;

export const logger = {
  info(...args) {
    console.log(PREFIX, ...args);
  },
  warn(...args) {
    console.warn(PREFIX, ...args);
  },
  error(...args) {
    console.error(PREFIX, ...args);
  },
  debug(...args) {
    if (CONFIG?.debug?.hooks) console.debug(PREFIX, ...args);
  },
};
