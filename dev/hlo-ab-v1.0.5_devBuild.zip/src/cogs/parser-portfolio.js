// ============================================================
// COG: parser-portfolio.js - Top-level HLO portfolio walker
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - Migrated from src/parser/parse-portfolio.js as part of
//             the cog architecture pivot. parsePortfolio is the single
//             public entry point for converting a raw HLO export into
//             a normalized PortfolioIR. Imports parseActor from the
//             sibling parser-actor cog.
//
// The HLO export shape (verified against Noxora, 2026-05-12):
//   {
//     portfolio: { charId, version, baseline },
//     metadata:  { gameCode, gameName, gameMajor, gameMinor, hloVersion, ... },
//     actors:    { "actor.N": { name, player, gameValues, items } }
//   }

import { parseActor } from "./parser-actor.js";

/**
 * Parse a raw HLO portfolio export into a normalized PortfolioIR.
 * Throws on malformed input rather than silently degrading; downstream
 * code should treat the IR as a trusted contract.
 *
 * @param {object} exportJson - Parsed HLO export (already JSON.parsed).
 * @returns {{
 *   metadata: object,
 *   portfolio: object,
 *   actors: Array<object>,
 *   warnings: Array<{code: string, message: string, context?: object}>
 * }}
 */
export function parsePortfolio(exportJson) {
  if (!exportJson || typeof exportJson !== "object") {
    throw new Error("parsePortfolio: exportJson must be an object.");
  }
  if (!exportJson.portfolio) {
    throw new Error("parsePortfolio: missing top-level 'portfolio' block.");
  }
  if (!exportJson.actors || typeof exportJson.actors !== "object") {
    throw new Error("parsePortfolio: missing top-level 'actors' block.");
  }

  const warnings = [];
  const metadata = normalizeMetadata(exportJson.metadata ?? {}, warnings);
  const portfolio = {
    charId: exportJson.portfolio.charId ?? null,
    version: exportJson.portfolio.version ?? null,
    baseline: exportJson.portfolio.baseline ?? null,
  };

  const actorEntries = Object.entries(exportJson.actors);
  if (actorEntries.length === 0) {
    warnings.push({ code: "no-actors", message: "Portfolio contains zero actors." });
  }

  const actors = actorEntries.map(([key, raw]) => parseActor(raw, key, warnings, { portfolioCharId: portfolio.charId }));

  return { metadata, portfolio, actors, warnings };
}

function normalizeMetadata(raw, warnings) {
  const gameCode = raw.gameCode ?? null;
  // HLO labels both PF2e and SF2e characters with gameCode "pf2" because SF2e
  // sits inside HLO's PF2e content stack. The actor-level class and content
  // tells us which Foundry system to target, not gameCode. Flag it so
  // downstream sees the expectation explicitly.
  if (gameCode && gameCode !== "pf2") {
    warnings.push({
      code: "unexpected-game-code",
      message: `metadata.gameCode is "${gameCode}", expected "pf2". Downstream system detection may need an override.`,
      context: { gameCode },
    });
  }
  return {
    gameCode,
    gameName: raw.gameName ?? null,
    gameMajor: raw.gameMajor ?? null,
    gameMinor: raw.gameMinor ?? null,
    hloVersion: raw.hloVersion ?? null,
    exportVersion: raw.exportVersion ?? null,
    legal: raw.legal ?? null,
  };
}

export default { id: "parser-portfolio" };
