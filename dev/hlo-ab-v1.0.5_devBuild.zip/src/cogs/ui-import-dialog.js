// ============================================================
// COG: ui-import-dialog.js - The HLOImportDialog ApplicationV2
//                            (paste / token / upload modes)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-28
// Revision: 0.25.4
//           - 0.25.4: silencer paren-hint pool reads the player's choice from an HLO item's trailing parenthetical ("Foxfire (Fire)") instead of guessing first-choice (fixes bug 1 wrong damage type).
//           - 0.25.3: second-pass dedup deletes HLO copies of items the system auto-grants during phase 3 embed (fixes bug 7 duplicate-feat console errors).
//           - 0.25.2: v0.7.1 (pass 3, silent-drop fix): COMPENDIUM_COMPSETS
//             extended with the four v0.7.0 compsets (MagicItem,
//             CustomArmor, Wand, GearItem) plus FocSpell that were
//             missing from the per-item debug log + end-of-actor
//             unmatched modal gate. Without these entries, a match
//             that returned null for one of those compsets produced
//             NO warn log, NO modal row, and NO actor item: a true
//             silent drop. Bhelroth EC's 6 unrecognised magic items
//             (Boots of speed, Carved Jade Opium Pipe, Reflection of
//             Life/Light/Stone/Water) all disappeared this way in
//             the v0.7.0 import, and Berial PFS's Wand of cozy cabin
//             vanished by the same path. The fix is one-line: extend
//             the Set so misses route through the existing warn +
//             modal pipeline like every other compset. Items that
//             genuinely have no canonical compendium target now
//             surface to the user instead of disappearing.
//           - 0.25.1: v0.7.1 (Bug 3 of v0.7.1 slice): strip _id from regular
//             items before bulk-create. The Berial PFS re-import log
//             showed 18 spells skipped with "The _id [...] already
//             exists within the parent collection." Root cause:
//             doc.toObject() in the resolver preserves compendium
//             _ids, and PF2e's ActorPF2e.createDocuments override
//             (pf2e.mjs line 50143-50146) flips operation.keepId =
//             true the instant any source item has grants -- which
//             for a Wizard import is unavoidable, since the class
//             grants Hand of the Apprentice and the arcane school's
//             spell list, each carrying compendium _ids that match
//             HLO's own resolved spells. The flip applies to ALL
//             sources in the batch, so non-grant spells inherit
//             keepId:true and collide with the auto-granted siblings.
//             Fix: walk `regular` items and delete _id before passing
//             to createEmbeddedDocuments. Grant-bearing items in the
//             earlier phase are untouched because they legitimately
//             need their pre-wired _ids for the grant graph.
//           - 0.25.0: v0.6.12 wizard-silencer three-pool walker. pickSilencerChoice
//             now walks pools in order: (1) pre-resolved compendium UUIDs
//             from the matcher (matched-items map, threaded into the
//             silencer state per-actor by setSilencerMatchedUuids after
//             matchAll); (2) HLO skill picks for skill ChoiceSets (uses
//             the actor's Skill compset entries with profLevel >= Trained
//             so the Infiltrator class-feature skill grant lands on the
//             skill HLO actually picked, not the alphabetically-first
//             option); (3) the v0.6.11 label / slug / UUID-tail string
//             match; (4) first-choice last-resort. Every silencer pick
//             logs which pool produced the hit at debug level so wrong-
//             pick triage is a one-line audit. Background: v0.6.11 logged
//             "Silenced wizard prompt: 'Infiltrator' - auto-resolved to
//             'Acrobatic Performer'" on the noxora import because the
//             skill ChoiceSet inside the granted class-feature item fell
//             through to first-choice; the new pool 2 routes the same
//             prompt to (e.g.) Stealth or Thievery when HLO's actor has
//             that skill marked Trained. The silencer hloItemPool is
//             also re-scoped per-actor to the parser-normalized IR (so
//             field names lowercase and Skill items carry profLevel)
//             instead of the cross-actor raw-HLO pool from install time.
//           - 0.24.0: New export pickHloItemForChoiceSetAsync. Used by the
//             SF2e grant resolver to verify Foundry-side ChoiceSet
//             filter predicates (e.g. "item:tag:operative-
//             specialization", a tag that lives on the compendium
//             doc's system.traits.otherTags but NEVER on the HLO
//             export) against the actual matched compendium doc.
//             hloMatchesFilters gained a {skipDocSide:true} option
//             that defers item:tag checks to the async picker; the
//             new docMatchesFoundrySideFilters helper re-runs those
//             predicates against a fromUuid result. The sync
//             pickHloItemForChoiceSet keeps its original behavior
//             (callers that cannot await still get the legacy path).
//           - 0.23.0: v0.6.10 follow-up: orphan-scalar sanitization on the
//             matched-actor update path. Before writing scaffoldedSystem
//             onto an existing actor, walk known orphan-prone roots in
//             _source.system (attributes, proficiencies, skills, saves,
//             perception, build, traits, details, resources) and
//             replace any one-level child that is a bare scalar
//             (number / string / boolean) with `{}` so the subsequent
//             mergeObject overlays a proper object shape instead of a
//             primitive. The scalars come from prior AELikeRuleElement
//             writes against undefined paths: setProperty walks
//             `target[p] === undefined ? {} : target[p]`, so the
//             first write that lands `system.X = 1` makes the next
//             write to `system.X.value = N` throw "Cannot create
//             property 'value' on number '1'" because target is now a
//             primitive. The TypeError is caught inside SF2e's
//             AELikeRuleElement.#applyAELike try/catch (sf2e.mjs:
//             44062-65) but the underlying Foundry assertion still
//             surfaces ~16 times per import (~27 in v0.6.9, ~16 after
//             v0.6.10's Index Dumps fix killed 11 of them). Same root
//             cause as the v0.6.10 buildPackCategoryDump fix: parent/
//             child path collisions in setProperty must be avoided.
//             Scalar -> {} replacement (instead of outright deletion)
//             is required because SF2e's prepareBaseData reads
//             `_source.system.skills[key]?.rank` and `_source.system
//             .perception.X` directly (sf2e.mjs:38579, :21216) and
//             undefined parents would crash prepare. The new helper
//             sanitizeSystemOrphans() returns the affected paths so
//             the sanitize patch is built dynamically and the debug
//             log records exactly which scalars were neutralized.
//           - 0.22.0: v0.6.11: Wizard silencer. Brute-force safety net that
//             intercepts every PickAThingPrompt opened during the
//             import pipeline and auto-resolves it without ever
//             showing the dialog to the user. Catches the SF2e
//             Operative-class "Select a specialization" prompt that
//             v0.6.9's prefillGrantingRules cannot reach because the
//             prompt fires from the GRANTED feature's ChoiceSet, not
//             from the parent class's system.rules. Two layers:
//             (1) Hooks.on("renderPickAThingPrompt") + the inheritance-
//             chain backstop "renderApplicationV2" pick an HLO-informed
//             choice (or the first option), write it into app.selection,
//             and call app.close() so the awaiting #resolve callback
//             unblocks with the choice. (2) Belt prototype patch on
//             PickAThingPrompt.prototype.resolveSelection (captured
//             from the first intercepted instance) short-circuits
//             before render for any straggler call. Installed at the
//             top of _runPipeline, torn down in finally so it is
//             active ONLY while we are importing - regular Foundry
//             play still shows wizards normally. Every silenced
//             prompt is logged at info level so the user can audit.
//             NEVER falls back to "cancel" / no-selection because
//             that would leave a grant slot empty and cascade into
//             broken state per spec.
// Revision: 0.21.0
//           - Index Dumps (Dev) panel: fix v0.6.9 emptiness regression.
//             Most pack-source category dumps came out at 545-700 bytes
//             with the error "Cannot create property 'value' on number
//             '1'", because buildPackCategoryDump merged a shallow
//             baseFields list (["system.level", "system.category",
//             "system.traits", ...]) with each spec's leaf-path fields
//             (["system.level.value", "system.traits.value", ...]) into
//             a single indexFields Set. Foundry V14's server-side index
//             projection builds a template object via setProperty for
//             each field, and when both "system.traits" and "system.
//             traits.value" land in the same Set the parent path
//             overwrites traits with scalar 1, then the child path
//             tries to assign (1).value = 1 and throws, killing the
//             whole pack request. CONFIG-source dumps for skills /
//             languages / abilities / proficiencies / spell-traditions
//             also returned "(missing)" because they were hard-coded to
//             read from CONFIG.SF2E.* even though SF2e v1.1 ships as a
//             PF2e fork and exposes everything under CONFIG.PF2E (there
//             is no CONFIG.SF2E object). Fix: trim baseFields back to
//             ["system.slug", "type"] (matching the matcher-pack-index
//             precache so the call is a cache hit when no extra fields
//             are needed), add a stripParentPaths() pass that drops any
//             dotted path that is a strict prefix of another path in
//             the same Set, and route every config-source spec to
//             CONFIG.PF2E.* on both systems (PF2E.skills instead of
//             PF2E.skillList, both pf2e and sf2e read from the same
//             namespace). All filter helpers (featCategoryOf,
//             actionCategoryOf, spellIsFocus, spellLevelInRange) now
//             route through unified categoryOf / levelOf / traitsOf
//             accessors so they tolerate both the flat-scalar and
//             {value: X} index shapes.
//           - 0.20.0: v0.6.9: pre-fill ChoiceSet / GrantItem selections
//             from HLO ground truth instead of suppressing them.
//             v0.6.8 silenced the wizard prompts by setting
//             ignored:true on every ChoiceSet+GrantItem rule on
//             grant-bearing items, but the side effect was loss
//             of flags.sf2e.grantedBy linkage: HLO's chosen
//             items were created as orphans, never connected to
//             their parent class/ancestry/heritage. The proper
//             fix is to PRE-FILL the choice so SF2e's grant
//             pipeline actually fires WITH the correct selection
//             already in place, producing the proper grantedBy
//             chain. New prefillGrantingRules(obj, hloItems)
//             helper walks system.rules on grant-bearing items
//             and for each GrantItem with a chained ChoiceSet
//             (linked by `flag`), looks up the HLO-matched item
//             and writes preselectChoices = { [flag]: UUID } on
//             the GrantItem rule. SF2e then propagates that into
//             the granted item's ChoiceSet via the system's own
//             #applyChoicePreselections at sf2e.mjs:48393. For
//             standalone ChoiceSet rules (not paired with a
//             GrantItem), selection is written directly. If no
//             HLO match for a slot, falls back to v0.6.8's
//             ignored:true behavior so the prompt is still
//             suppressed; no regression to wizard popups. The
//             hloItems list is threaded from _runPipeline through
//             resolveSkeletonForCreate to the helper. Every
//             preselect decision is recorded in the conversion
//             log at debug level for traceability. Net result:
//             actors imported via HLO carry the same item-grant
//             chain SF2e/PF2e would produce natively, so level-
//             up wizard reruns see the slots as filled, and the
//             grant-deletion machinery walks the chain correctly
//             on re-import.
//           - 0.19.0: Index Dumps (Dev) panel. TEMPORARY maintainer
//             feature: ~40 per-category export buttons gated
//             behind debug log level + a disclosure toggle.
//             Each button dumps a focused subset of pack-index
//             or CONFIG data (Ancestry Feats, Cantrips, Skills,
//             Vitals, etc.) so the maintainer (Shinra CC) can
//             inspect specific slices without re-exporting the
//             full ~3 MB pack-index JSON every time. Pack-based
//             categories walk the relevant pack(s) and apply an
//             optional filter (trait / category / level range);
//             non-compendium categories read from CONFIG.PF2E /
//             CONFIG.SF2E (skillList, magicTraditions, etc.).
//             ONE dispatching handler _onExportIndexCategory
//             reads target.dataset.category and looks up the
//             recipe in CATEGORY_DUMP_SPECS. Slated for removal
//             or comment-out before public launch; see the
//             TEMP markers on the spec map, handler, and
//             template block.
//           - 0.18.0: v0.6.8: ChoiceSet + GrantItem rule suppression on
//             grant-bearing items. The audit sweep (pass A)
//             traced the "Select a skill feat" wizard prompt to
//             SF2e's overridden ItemPF2e.createDocuments at sf2e.
//             mjs:50101 which fires rule.preCreate() directly,
//             OUTSIDE Foundry's hook bus. v0.6.1's noHook:true
//             was structurally unable to reach these prompts.
//             New suppressGrantingRules() helper sets ignored:
//             true on every ChoiceSet (silences the dialog) and
//             GrantItem (suppresses the auto-grant chain) rule
//             of grant-bearing items (class/ancestry/heritage/
//             deity/background) before resolveSkeletonForCreate
//             pushes them into the embed batch. HLO supplies
//             the chosen items directly so the actor still gets
//             every pick - just without grant-chain linkage to
//             the parent class. Dropped the noHook:true option
//             from _createItemsBatch (it was a no-op) but kept
//             the dedup pass as defensive.
//           - 0.17.0:
//           - End-of-import unmatched-items modal. The per-item
//             `_pushLog("warn", "Unmatched ...")` lines were
//             easy to miss; users would close the dialog without
//             realizing 4-6 items needed manual addition. The
//             warn entries STAY (debug-level users still want
//             the per-item record + the override-stub extractor
//             still parses them via extractFromLogRecords), but
//             we now ALSO open a blocking ApplicationV2 modal
//             above the actor sheet listing every unmatched
//             item with compset / name / HLO slug / suggested
//             pack. The user must click "I Understand" or hit
//             the X to dismiss. New cog at src/cogs/ui-
//             unmatched-modal.js + template at templates/
//             unmatched-modal.hbs + CSS in styles/import-dialog
//             .css. Per-actor (multi-actor imports show one
//             modal per actor sequentially via the await on
//             showUnmatchedModal()). suggestPackFor() is now
//             exported from import-extract-overrides.js so the
//             modal and the stub renderer share one compset
//             table.
//           - 0.16.0: v0.6.6: three changes addressing the four genuine
//             unmatched items from the v0.6.5 import log
//             (Low-Light Vision, Limited Telepathy, Basic
//             Environmental Protection, Fist) plus the user's
//             question about how to share pack-JSON data from
//             Foundry. (a) matcher-slug-table.js Ability
//             routing extended to include ancestry-features
//             pack on both systems - catches Low-Light Vision
//             and Limited Telepathy via the canonical lookup.
//             (b) matcher-overrides.js gains a SKIP_BY_DESIGN
//             set + isSkipByDesign() helper for items HLO
//             sends that are NOT compendium-eligible (Fist is
//             system-auto-granted; the env-protection Ability
//             is the activation echo of the Upgrade item).
//             matcher-core.js consults isSkipByDesign() at the
//             very top of matchItem() and returns strategy=
//             "skip" so the dialog can distinguish a
//             deliberate skip from a real miss. builder-items
//             .js suppresses ref emission for strategy="skip".
//             (c) New Dev Export Pack Index button in the
//             dialog (visible at debug log level). Walks every
//             pack listed in COMPSET_TO_PACKS for the active
//             system and dumps {pack, _id, name, slug, type}
//             for every entry as JSON via foundry.utils.
//             saveDataToFile. Lets the maintainer (Shinra CC)
//             see the deterministic-lookup ground truth
//             without LevelDB extraction tooling. Answers
//             user's question: "is there something I can do
//             from inside the software to help with you not
//             being able to see the JSON ID Values?"
//           - 0.15.0: v0.6.5 bugfix: stale-variable reference. The
//             v0.5.9 refactor that introduced _wipeBeforeImport
//             mode renamed `const ours = existing.items.filter(
//             ...)` to `const targetsToDelete = ...` but missed
//             updating one log message six lines down that
//             still read `Removed ${ours.length}`. Result:
//             ReferenceError ("ours is not defined") fired
//             AFTER Phase 1 delete completed but BEFORE the
//             update/embed could run, throwing the whole
//             import. The cog architecture made finding this
//             trivial: the crash stack named cogs/ui-import-
//             dialog.js:779:57 directly, so the fix was a
//             three-line edit. Restructured the log message
//             to use the renamed variable AND to read
//             correctly in both wipe and non-wipe modes
//             (different semantics: "wiped ALL" vs "removed
//             previously-imported").
//           - 0.14.0: v0.6.4: per-strategy match distribution added to
//             the conversion-log info line. The matcher
//             pipeline runs four strategies in order
//             (canonical -> override -> slug -> fuzzy); the
//             info line now reads "X matched (canonical=N1,
//             slug=N2, ...), Y unmatched" so the user can
//             confirm v0.6.0's deterministic canonical lookup
//             is firing and what the fallback rate looks like.
//             If canonical=0, either the pack index failed to
//             build or the normalization keys do not match
//             HLO's names; both are signals worth surfacing.
//           - 0.13.0: v0.6.3: ground-truth-driven fixes from inspecting
//             two new fixtures the user added (data/test-
//             fixtures/fvtt-actor-bhelthal-operative-lvl1.json
//             and -lvl5.json, exported from a fully-configured
//             SF2e Operative built in Foundry, not from HLO).
//             Three corrections: (a) dedup walks
//             flags.sf2e.itemGrants on every item to build the
//             auto-granted ID set, instead of looking for
//             flags.pf2e.grantedBy on grantees (which the
//             fixtures showed is empty - SF2e tracks the grant
//             one-way from the granter via itemGrants, the
//             grantee has no back-reference); (b) scaffold
//             updated to match the real schema -
//             details.languages uses { value, details } NOT {
//             value, custom }, plus added details.keyability
//             (load-bearing for derived attack/damage),
//             details.alliance: "party", details.xp.{min,max};
//             (c) two schema-snapshot files documented from
//             the fixtures for future iterations to reference.
//           - 0.12.0: v0.6.2: post-Phase-1 deduplication against system
//             auto-grants. v0.6.1 silenced the wizard PROMPTS
//             via noHook:true on grant-bearing embed, but the
//             auto-grant ITEMS still spawn (they fire from the
//             item's _onCreate lifecycle, which noHook does not
//             suppress). That left duplicates: HLO's chosen
//             "Digital Ambassador" + class's auto-granted
//             "Digital Ambassador". Fix: snapshot the actor's
//             items list before Phase 1 (grant-bearing embed),
//             diff it after, find the new items that are NOT
//             ours and DO carry flags.pf2e.grantedBy. Those
//             are auto-grants. Then dedup the remaining HLO
//             items against the auto-grant set by (type, slug),
//             dropping HLO's duplicate and preserving the
//             system-granted version (which has the proper
//             grant-chain linkage). Tied to the same
//             SETTING_SUPPRESS_GRANT_PROMPTS toggle: dedup
//             only fires when prompt-suppression does, since
//             they are semantically related (trust HLO over
//             SF2e wizards vs trust SF2e wizards over HLO).
//           - 0.11.0: v0.6.1: grant-prompt suppression. The "pick two
//             skill feats" wizard fires from SF2e/PF2e's auto-
//             grant pipeline when grant-bearing items embed
//             (ancestry/class/heritage/deity/background). HLO
//             already chose those for the user, so the prompt
//             is asking for choices that have already been
//             made. _createItemsResilient now segments items
//             into grant-bearing vs regular; grant-bearing get
//             noHook:true (suppresses the choice-set hooks),
//             regular embed normally so feat/spell/equipment
//             effects still fire. Behavior is gated on the new
//             SETTING_SUPPRESS_GRANT_PROMPTS world setting
//             (default ON, off-switch in module settings for
//             users who do want SF2e's chargen wizard).
//           - Inner _createItemsBatch helper carved out of
//             _createItemsResilient so both the noHook:true and
//             full-hook batches share the same try-bulk-then-
//             per-item retry logic.
//           - 0.10.0: v0.6.0: deterministic-lookup integration + Reset
//             Actor mode + Background routing.
//           - Pipeline now calls ensurePackIndex(systemId) before
//             matchAll. The pack index walks every pack listed
//             in matcher-slug-table COMPSET_TO_PACKS for the
//             active system and produces a (compset, normalized-
//             key) -> {pack, slug, _id, name} map. matcher-core
//             consults this map FIRST before the override / slug
//             / fuzzy pipeline; strategy="canonical", confidence
//             1.0 on hit. Resolves the four landmines from the
//             Noxora log (Low-Light Vision, Limited Telepathy,
//             Basic Environmental Protection, Fist) by name
//             match instead of slug guess.
//           - New "Reset Actor first" checkbox in the template.
//             When checked, the existing-actor branch wipes
//             EVERY item on the actor (not just our flagged
//             ones) before re-importing. Recovery path for the
//             corrupted-actor case where prior failed imports
//             left dangling grant references.
//           - Background compset added to COMPENDIUM_COMPSETS.
//             parser-actor.js synthesizes a Background item
//             from gameValues.actBackgroundText; matcher-slug-
//             table.js routes Background to pf2e.backgrounds /
//             sf2e.backgrounds packs; the new pack index then
//             resolves it. Closes the long-standing gap where
//             HLO's actBackgroundText ("Hitchhiker", etc) was
//             silently dropped.
//           - 0.9.0: Comprehensive scaffold expansion + flags.pf2e
//             initialization on every embedded item. Crash
//             signatures from import logs 2026-05-15T17:29:26
//             and 2026-05-15T18:16:52 named the missing fields
//             one by one: AncestryPF2e wanted system.traits.
//             size, ClassPF2e wanted system.details.class,
//             DeityPF2e wanted system.details.deities.primary,
//             HeritagePF2e wanted system.details.heritage,
//             FeatPF2e wanted item.flags.pf2e.grantedBy.
//             scaffoldSystemForCharacter() now seeds all of
//             them (plus build.attributes.boosts for level
//             choices, traits.senses, attributes.ac, etc).
//             ensureItemFlags() is a new pre-embed helper that
//             initializes flags.pf2e = {} on every item; this
//             prevents the dot-chain crash on items the
//             compendium did not pre-flag.
//           - Resilient delete on the existing-actor path. The
//             second-attempt crash that locks up re-imports
//             (processGrantDeletions -> "Cannot read properties
//             of undefined (reading 'grantedBy')") happens
//             when SF2e's grant cleanup walks an item's grant
//             chain to a referent that no longer exists. The
//             bulk deleteEmbeddedDocuments now tries-then-per-
//             items the same way createEmbeddedDocuments does;
//             a single broken grant chain no longer blocks the
//             whole cleanup.
//           - 0.8.0: Fault-tolerant item creation. The atomic
//             createEmbeddedDocuments call has been replaced
//             with a "try bulk, fall back to per-item" wrapper.
//             Bulk path stays fast for the happy path; per-item
//             path isolates failures. If a single Feat trips
//             SF2e's prepareActorData crash (the long-running
//             "Cannot read properties of undefined (reading
//             'languages')" landmine, see import log
//             2026-05-15T17:29:26 against Noxora), the OTHER
//             33 items still land. The user gets a partial-
//             import warning in the conversion log naming each
//             skipped item; the actor stays openable instead of
//             being bricked beyond a delete-and-recreate.
//           - Always-apply scaffold. The previous defensive
//             scaffold only patched system.build / proficiencies
//             / perception when missing; this turned out to be
//             the wrong default because Foundry's deep-merge
//             during update() can silently drop nested fields
//             we did not explicitly include in our overrides.
//             The scaffold now ALWAYS adds the SF2e fields the
//             prepare pipeline expects (build.languages.value,
//             build.languages.granted, build.languages.max,
//             details.languages.value), with mergeObject overlay
//             so any actual data on the existing actor wins.
//             Same scaffold now applied on the new-actor path
//             too (previously only the existing-actor path did).
//           - 0.7.0: Wave 6 of the cog migration. Promoted from
//             src/ui/import-dialog.js. All cog imports
//             repointed to sibling cogs in src/cogs/ (no more
//             ../cogs/, ../util/, or ./settings.js paths). No
//             behavior changes; only the file location and
//             import paths.
//           - 0.6.1: Download Log button now uses foundry.utils.saveDataToFile
//             instead of the raw <a download> + blob URL pattern.
//             Inside Electron, the blob URL was being treated as a
//             navigation, prompting Windows "Get an app to open this
//             'blob' link" instead of saving the file. The Foundry
//             helper handles the Electron path correctly.
//           - 0.6.0: Version badge moved INTO the dialog (bottom-left of the
//             dialog window), via {{moduleVersion}} in the template.
//             It only shows while the import window is open.
//           - New "Download Log" button in the conversion-log header,
//             visible only when log level is "debug". Exports the full
//             conversion log as a .txt file (one line per entry, with
//             level prefix and an export timestamp header).
//           - When the dialog is opened from a sheet (this.options.
//             document is an Actor), the import targets THAT actor
//             unconditionally instead of running findExistingHloActor.
//             Fixes the "click button on Sheet X but a different actor
//             gets populated" bug. Standalone-opened dialogs still fall
//             back to flag/name search.
//           - Defensive system.build scaffold on the existing-actor
//             update path. SF2e's Feat.prepareActorData crashes if
//             actor.system.build.languages is undefined; if the target
//             actor lacks build / proficiencies / perception, we add
//             empty-defaults to the update so the prepare cycle has
//             the shape it expects.
//           - 0.5.0: findExistingHloActor now also matches by exact name as a
//             fallback. Previously, importing onto a manually-created
//             actor silently produced a duplicate at the bottom of the
//             actor list because only flag-tagged actors were visible.
//             Match origin ("flag" vs "name") is logged so the user
//             can confirm we hit the right target.
//           - New-actor creation now uses a two-phase pattern: create
//             a blank actor with just name+type+flags so the system's
//             default-and-prepare cycle runs on a clean slate, then
//             update with our system overrides, then add items. The
//             single-call Actor.create form was leaving derived fields
//             unscaffolded, causing sheet render to crash silently.
//           - Re-import (existing actor) now removes our previously-
//             imported items before creating fresh ones, instead of
//             stacking duplicates on top. Items the user added by hand
//             are left alone (we filter on our module flag). This both
//             fixes the duplicate-items UX problem and avoids the SF2e
//             Class.getLinkedItems crash that happened when item count
//             roughly doubled and one was mid-defaulted.
//           - Resolver now defensively initializes flags.pf2e = {} on
//             every emitted item. Compendium-pulled items already have
//             it; builder pass-through items (lores, custom actions)
//             did not, and PF2e/SF2e system code dot-chains into
//             item.flags.pf2e.grantedBy.id during preparation.
//           - Removed the 14-character element-token guard. It was based
//             on a misread of the HLO docs; real tokens in the wild are
//             13 characters and POST cleanly. The bad warning was
//             misleading users during debugging.
//           - The infinite-poll behavior that the warning was trying to
//             explain has been fixed in hlo-client.js 0.3.0; the cause
//             was status semantics, not token length.
//           - Fix stuck "Working..." button: the early-return branch in
//             _onImport was rendering before _isBusy was reset in finally,
//             so the disabled/spinning state never cleared after a failed
//             fetch. Restructured so the post-finally render always runs.
//           - Default conversion log level changed from "info" to "debug"
//             while we are stabilizing the API path. Hides nothing.
//           - Per-poll debug entries now include a truncated raw response
//             dump so the user can see the literal HLO body, not just a
//             keys-and-status summary.
//
// Flow:
//   - Paste mode: read the textarea, JSON.parse, pipe through the parser
//     pipeline, resolve compendium refs, Actor.create.
//   - Token mode: read user JWT from settings (or the password field),
//     element token from the text field, exchange JWT for an access token
//     via the cache, fetch the character via the API client, then pipe
//     through the same parser pipeline.

import { MODULE_ID, MODULE_VERSION } from "./util-version.js";
import { logger } from "./util-logger.js";
import { parsePortfolio } from "./parser-portfolio.js";
import { matchAll } from "./matcher-core.js";
import { makeFoundryResolver } from "./matcher-foundry-resolver.js";
import { buildActorSkeleton } from "./builder-actor-pf2e.js";
import { buildActorSkeletonSf2e } from "./builder-actor-sf2e.js";
import { buildSpellcastingEntries, getEntryPlan, buildPreparedSlots } from "./builder-spellcasting.js";
import { buildAttachmentPlan, applyAttachmentPlan } from "./builder-attachments.js";
import { findExistingHloActor } from "./import-find-existing-actor.js";
import { tokenCache } from "./api-token-cache.js";
import { getCharacter, HLOApiError } from "./api-hlo-client.js";
import { getUserToken, getLogToJournal } from "./ui-settings.js";
import { createConversionJournal } from "./import-conversion-journal.js";
import { extractFromLogRecords, renderStubsAsSource, suggestPackFor } from "./import-extract-overrides.js";
import { ensurePackIndex, packIndexStats, lookupCanonical } from "./matcher-pack-index.js";
import { slugifyName } from "./matcher-slug-table.js";
import { getSuppressGrantPrompts } from "./ui-settings.js";
import { showUnmatchedModal } from "./ui-unmatched-modal.js";
import { resolveSf2eClassGrants } from "./sf2e-grant-resolver.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

// ============================================================
// TEMP: Index Dumps (Dev) - category spec maps + builders
// ------------------------------------------------------------
// Maintainer-only dev tooling. Each CATEGORY_DUMP_SPECS entry
// describes how to assemble a focused JSON dump for one
// category. Three source kinds:
//
//   "pack":  walk one or more compendium packs (qualified or
//            short ids resolved via qualifyPackId). Optional
//            `filter(entry, systemId)` predicate trims the
//            results. `fields` extends pack.getIndex's fields
//            arg. The default per-entry projection is
//            {_id, name, slug, type, category, level, traits}.
//   "config": read from CONFIG.PF2E. `configPath` is a dotted
//            lookup ("PF2E.skills"); the dump transforms the
//            resulting object/array into {key, label} pairs.
//            SF2e ships as a PF2e fork and shares CONFIG.PF2E,
//            so both systems point at the same paths.
//   "unsupported": no source yet; the dump writes a note
//            instead. Used for categories that have no clean
//            CONFIG mapping AND no obvious pack (e.g. SF2e
//            Vitals).
//
// INDEX_DUMP_CATEGORY_GROUPS controls the on-screen grouping
// + button order. Each entry pulls its label from the spec
// map, so changing a label or adding a button only requires
// touching one of these two structures.
//
// Slated for removal / comment-out before public launch.
// See the cleanup checklist at the top of the TEMP block
// inside HLOImportDialog.
// ============================================================

/**
 * Per-category dump recipes. Keyed by the kebab-case category id used in
 * data-category. The handler reads target.dataset.category and looks up
 * the spec here.
 */
export const CATEGORY_DUMP_SPECS = {
  // --- Ancestry / Class structural items --------------------------------
  "ancestry-features": {
    label: "Ancestry Features",
    source: "pack",
    packs: { pf2e: ["ancestryfeatures"], sf2e: ["ancestry-features"] },
  },
  "class-features": {
    label: "Class Features",
    source: "pack",
    packs: { pf2e: ["classfeatures"], sf2e: ["class-features"] },
  },

  // --- Feats by type ----------------------------------------------------
  // PF2e ships the feats catalog as a single pack (feats-srd) with a
  // system.category discriminator ("class", "ancestry", "skill", "general",
  // etc). SF2e splits ancestry / class features out into their own packs
  // but still mixes the rest in a single `feats` pack with the same
  // category discriminator. Anachronism modules layer hundreds more feats
  // on top of either system; without them an SF2e world only sees ~1.8k of
  // its real ~7.6k feat catalog, so we walk both packs and union the
  // results. So the per-type dumps walk the same pack and filter by
  // category.
  "ancestry-feats": {
    label: "Ancestry Feats",
    source: "pack",
    packs: { pf2e: ["feats-srd", "sf2e-anachronism.feats"],
             sf2e: ["feats", "pf2e-anachronism.feats"] },
    fields: ["system.category", "system.traits.value", "system.level.value"],
    filter: (e) => featCategoryOf(e) === "ancestry"
                  || (traitsOf(e)).includes("ancestry"),
  },
  "class-feats": {
    label: "Class Feats",
    source: "pack",
    packs: { pf2e: ["feats-srd", "sf2e-anachronism.feats"],
             sf2e: ["feats", "pf2e-anachronism.feats"] },
    fields: ["system.category", "system.traits.value", "system.level.value"],
    filter: (e) => featCategoryOf(e) === "class",
  },
  "skill-feats": {
    label: "Skill Feats",
    source: "pack",
    packs: { pf2e: ["feats-srd", "sf2e-anachronism.feats"],
             sf2e: ["feats", "pf2e-anachronism.feats"] },
    fields: ["system.category", "system.traits.value", "system.level.value"],
    filter: (e) => featCategoryOf(e) === "skill"
                  || (traitsOf(e)).includes("skill"),
  },
  "general-feats": {
    label: "General Feats",
    source: "pack",
    packs: { pf2e: ["feats-srd", "sf2e-anachronism.feats"],
             sf2e: ["feats", "pf2e-anachronism.feats"] },
    fields: ["system.category", "system.traits.value", "system.level.value"],
    filter: (e) => featCategoryOf(e) === "general"
                  || (traitsOf(e)).includes("general"),
  },
  "other-feats": {
    label: "Other Feats",
    source: "pack",
    packs: { pf2e: ["feats-srd", "sf2e-anachronism.feats"],
             sf2e: ["feats", "pf2e-anachronism.feats"] },
    fields: ["system.category", "system.traits.value", "system.level.value"],
    // Catches archetype, bonus, deity, curse, etc. anything that's not
    // one of the four canonical category buckets above.
    filter: (e) => {
      const cat = featCategoryOf(e);
      return cat != null && !["ancestry", "class", "skill", "general"].includes(cat);
    },
  },

  // --- Sense-of-character (effects, skills, proficiencies) -------------
  "effects": {
    label: "Effects",
    source: "pack",
    // PF2e ships effect items under several packs (feat-effects, spell-
    // effects, action-effects, equipment-effects, ancestryfeatures, etc).
    // We pull the ones whose pack id starts with "*-effects" plus the
    // single "feat-effects" pattern. Anachronism modules mirror this.
    packs: {
      pf2e: ["feat-effects", "spell-effects", "action-effects", "equipment-effects",
             "sf2e-anachronism.feat-effects", "sf2e-anachronism.spell-effects"],
      sf2e: ["feat-effects", "spell-effects", "action-effects", "equipment-effects",
             "pf2e-anachronism.feat-effects", "pf2e-anachronism.spell-effects"],
    },
  },
  "skills": {
    label: "Skills",
    source: "config",
    // PF2e v8 / SF2e v1.1 both expose the skill enum at CONFIG.PF2E.skills
    // (renamed from the older `skillList`). SF2e is built as a PF2e fork and
    // shares the PF2E namespace: there is no CONFIG.SF2E object, so both
    // systems read from the same path.
    configPath: { pf2e: "PF2E.skills", sf2e: "PF2E.skills" },
  },
  "proficiencies": {
    label: "Proficiencies",
    source: "config",
    // CONFIG.PF2E.proficiencyLevels in both PF2e v8 and SF2e v1.1.
    configPath: { pf2e: "PF2E.proficiencyLevels", sf2e: "PF2E.proficiencyLevels" },
  },

  // --- Spells by level --------------------------------------------------
  // Spell packs follow the same dual-source pattern as feats: each system
  // ships a baseline pack and Anachronism layers the larger PF2e catalog
  // on top. Walking only the system pack hides hundreds of spells from
  // dev triage on whichever system uses Anachronism.
  "focus-spells": {
    label: "Focus Spells",
    source: "pack",
    packs: { pf2e: ["spells-srd", "sf2e-anachronism.spells"],
             sf2e: ["spells", "pf2e-anachronism.spells"] },
    fields: ["system.level.value", "system.traits.value", "system.category", "system.cast.focus"],
    filter: (e) => spellIsFocus(e),
  },
  "cantrips": {
    label: "Cantrips",
    source: "pack",
    packs: { pf2e: ["spells-srd", "sf2e-anachronism.spells"],
             sf2e: ["spells", "pf2e-anachronism.spells"] },
    fields: ["system.level.value", "system.traits.value"],
    filter: (e) => traitsOf(e).includes("cantrip") || levelOf(e) === 0,
  },
  "spell-levels-1-3": {
    label: "Spell Levels 1-3",
    source: "pack",
    packs: { pf2e: ["spells-srd", "sf2e-anachronism.spells"],
             sf2e: ["spells", "pf2e-anachronism.spells"] },
    fields: ["system.level.value", "system.traits.value"],
    filter: (e) => spellLevelInRange(e, 1, 3),
  },
  "spell-levels-4-6": {
    label: "Spell Levels 4-6",
    source: "pack",
    packs: { pf2e: ["spells-srd", "sf2e-anachronism.spells"],
             sf2e: ["spells", "pf2e-anachronism.spells"] },
    fields: ["system.level.value", "system.traits.value"],
    filter: (e) => spellLevelInRange(e, 4, 6),
  },
  "spell-levels-7-9": {
    label: "Spell Levels 7-9",
    source: "pack",
    packs: { pf2e: ["spells-srd", "sf2e-anachronism.spells"],
             sf2e: ["spells", "pf2e-anachronism.spells"] },
    fields: ["system.level.value", "system.traits.value"],
    filter: (e) => spellLevelInRange(e, 7, 9),
  },
  "spell-level-10": {
    label: "Spell Level 10",
    source: "pack",
    packs: { pf2e: ["spells-srd", "sf2e-anachronism.spells"],
             sf2e: ["spells", "pf2e-anachronism.spells"] },
    fields: ["system.level.value", "system.traits.value"],
    filter: (e) => levelOf(e) === 10,
  },
  // Bonus: spell traditions reference dump (small but useful).
  "spell-traditions": {
    label: "Spell Traditions",
    source: "config",
    // CONFIG.PF2E.magicTraditions in both systems (SF2e shares PF2E ns).
    configPath: { pf2e: "PF2E.magicTraditions", sf2e: "PF2E.magicTraditions" },
  },

  // --- Equipment by type ------------------------------------------------
  // SF2e's own equipment pack is intentionally slim (537 items, no
  // treasure, no kits) because it ships only the SF2e-specific catalog;
  // the bulk Pathfinder catalog comes from pf2e-anachronism.equipment
  // (5635 items including all 153 treasure entries and the two kits).
  // Walking both packs makes the per-type dumps reflect what an actual
  // SF2e + Anachronism world exposes to character builds. PF2e mirrors
  // the same pattern via sf2e-anachronism.equipment for symmetry.
  "weapons": {
    label: "Weapons",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.traits.value", "system.category"],
    filter: (e) => e.type === "weapon",
  },
  "shields": {
    label: "Shields",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.traits.value", "system.category"],
    filter: (e) => e.type === "shield"
                  || (e.type === "armor" && categoryOf(e) === "shield"),
  },
  "armor": {
    label: "Armor",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.traits.value", "system.category"],
    filter: (e) => e.type === "armor" && categoryOf(e) !== "shield",
  },
  "equipment": {
    label: "Equipment (gear)",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.traits.value"],
    filter: (e) => e.type === "equipment",
  },
  "consumables": {
    label: "Consumables",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.category", "system.traits.value"],
    filter: (e) => e.type === "consumable" && categoryOf(e) !== "ammo",
  },
  "ammunition": {
    label: "Ammunition",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.category", "system.traits.value"],
    filter: (e) => (e.type === "consumable" && categoryOf(e) === "ammo")
                  || e.type === "ammo",
  },
  "treasure": {
    label: "Treasure",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.traits.value"],
    filter: (e) => e.type === "treasure",
  },
  "containers": {
    label: "Containers",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.traits.value"],
    filter: (e) => e.type === "backpack",
  },
  "magic-items": {
    label: "Magic Items",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.traits.value"],
    filter: (e) => {
      const t = traitsOf(e);
      return t.includes("magical") || t.includes("invested");
    },
  },
  "other-items": {
    label: "Other Items",
    source: "pack",
    packs: { pf2e: ["equipment-srd", "sf2e-anachronism.equipment"],
             sf2e: ["equipment", "pf2e-anachronism.equipment"] },
    fields: ["type", "system.traits.value"],
    // Catches anything that did not land in one of the typed buckets
    // above. Useful for spotting new equipment subtypes the matcher does
    // not yet know about. With both equipment packs in scope this
    // currently surfaces the two PF2e `kit` items.
    filter: (e) => !["weapon", "armor", "shield", "equipment", "consumable",
                     "backpack", "treasure", "ammo"].includes(e.type),
  },

  // --- Actions by type --------------------------------------------------
  // Same dual-pack pattern as feats/spells/equipment: both the system pack
  // and the cross-Anachronism pack contribute. SF2e ships 226 actions, the
  // PF2e Anachronism pack ships 443 more; without that union the action-
  // subcategory dumps badly under-report what's available.
  "attacks": {
    label: "Attacks",
    source: "pack",
    packs: { pf2e: ["actionspf2e", "sf2e-anachronism.actions"],
             sf2e: ["actions", "pf2e-anachronism.actions"] },
    fields: ["system.actionType.value", "system.actionCategory.value", "system.category", "system.traits.value"],
    filter: (e) => actionCategoryOf(e) === "offensive"
                  || traitsOf(e).includes("attack"),
  },
  "actions": {
    label: "Actions (general)",
    source: "pack",
    packs: { pf2e: ["actionspf2e", "sf2e-anachronism.actions"],
             sf2e: ["actions", "pf2e-anachronism.actions"] },
    fields: ["system.actionType.value", "system.traits.value"],
    filter: (e) => (e.system?.actionType?.value ?? null) === "action",
  },
  "reactions": {
    label: "Reactions",
    source: "pack",
    packs: { pf2e: ["actionspf2e", "sf2e-anachronism.actions"],
             sf2e: ["actions", "pf2e-anachronism.actions"] },
    fields: ["system.actionType.value", "system.traits.value"],
    filter: (e) => (e.system?.actionType?.value ?? null) === "reaction",
  },
  "free-actions": {
    label: "Free Actions",
    source: "pack",
    packs: { pf2e: ["actionspf2e", "sf2e-anachronism.actions"],
             sf2e: ["actions", "pf2e-anachronism.actions"] },
    fields: ["system.actionType.value", "system.traits.value"],
    filter: (e) => (e.system?.actionType?.value ?? null) === "free",
  },
  "exploration-actions": {
    label: "Exploration Actions",
    source: "pack",
    packs: { pf2e: ["actionspf2e", "sf2e-anachronism.actions"],
             sf2e: ["actions", "pf2e-anachronism.actions"] },
    fields: ["system.actionCategory.value", "system.category", "system.traits.value"],
    filter: (e) => actionCategoryOf(e) === "exploration"
                  || traitsOf(e).includes("exploration"),
  },
  "downtime-actions": {
    label: "Downtime Actions",
    source: "pack",
    packs: { pf2e: ["actionspf2e", "sf2e-anachronism.actions"],
             sf2e: ["actions", "pf2e-anachronism.actions"] },
    fields: ["system.actionCategory.value", "system.category", "system.traits.value"],
    filter: (e) => actionCategoryOf(e) === "downtime"
                  || traitsOf(e).includes("downtime"),
  },

  // --- Character data (CONFIG-based) ------------------------------------
  "languages": {
    label: "Languages",
    source: "config",
    // CONFIG.PF2E.languages in both systems (SF2e shares the PF2E namespace).
    configPath: { pf2e: "PF2E.languages", sf2e: "PF2E.languages" },
  },
  "attributes": {
    label: "Attributes",
    source: "config",
    // PF2e/SF2e expose the canonical attribute list under CONFIG.PF2E.abilities
    // (key to label map). SF2e shares this namespace (no CONFIG.SF2E exists
    // in the SF2e v1.1 system bundle).
    configPath: { pf2e: "PF2E.abilities", sf2e: "PF2E.abilities" },
  },
  "vitals": {
    label: "Vitals",
    source: "unsupported",
    note: "Vitals (HP, Stamina, Resolve, Wounds, etc) are computed actor.system.attributes paths on the active actor, not a CONFIG-level enum. The Pack Index export has no useful slice to dump here. Inspect actor.system.attributes on a live character instead. (Placeholder kept so the button is present.)",
  },

  // --- Identity items ---------------------------------------------------
  "deities": {
    label: "Deities",
    source: "pack",
    packs: { pf2e: ["deities", "sf2e-anachronism.deities"], sf2e: ["deities"] },
  },
  "backgrounds": {
    label: "Backgrounds",
    source: "pack",
    packs: { pf2e: ["backgrounds", "sf2e-anachronism.backgrounds"],
             sf2e: ["backgrounds", "pf2e-anachronism.backgrounds"] },
  },
  "ancestries": {
    label: "Ancestries",
    source: "pack",
    packs: { pf2e: ["ancestries", "sf2e-anachronism.ancestries"],
             sf2e: ["ancestries", "pf2e-anachronism.ancestries"] },
  },
  "heritages": {
    label: "Heritages",
    source: "pack",
    packs: { pf2e: ["heritages", "sf2e-anachronism.heritages"],
             sf2e: ["heritages", "pf2e-anachronism.heritages"] },
  },
  "classes": {
    label: "Classes",
    source: "pack",
    packs: { pf2e: ["classes", "sf2e-anachronism.classes"],
             sf2e: ["classes", "pf2e-anachronism.classes"] },
  },

  // --- Extras (discovered while building the spec map) ------------------
  "conditions": {
    label: "Conditions",
    source: "pack",
    // PF2e ships these under "conditionitems"; SF2e cleaned up to "conditions".
    packs: { pf2e: ["conditionitems"], sf2e: ["conditions"] },
  },
};

/**
 * Display grouping for the on-screen button grid. Each entry is rendered
 * as a labelled section in the disclosure panel; items[] pulls the human-
 * readable label off the spec map so the template never duplicates strings.
 */
export const INDEX_DUMP_CATEGORY_GROUPS = [
  {
    label: "Identity",
    items: makeGroupItems(["ancestries", "heritages", "backgrounds", "classes", "deities"]),
  },
  {
    label: "Ancestry / Class Features",
    items: makeGroupItems(["ancestry-features", "class-features"]),
  },
  {
    label: "Feats",
    items: makeGroupItems(["ancestry-feats", "class-feats", "skill-feats", "general-feats", "other-feats"]),
  },
  {
    label: "Spells",
    items: makeGroupItems(["cantrips", "spell-levels-1-3", "spell-levels-4-6", "spell-levels-7-9", "spell-level-10", "focus-spells", "spell-traditions"]),
  },
  {
    label: "Equipment",
    items: makeGroupItems(["weapons", "shields", "armor", "equipment", "consumables", "ammunition", "treasure", "containers", "magic-items", "other-items"]),
  },
  {
    label: "Actions",
    items: makeGroupItems(["attacks", "actions", "reactions", "free-actions", "exploration-actions", "downtime-actions"]),
  },
  {
    label: "Sense-of-Character",
    items: makeGroupItems(["effects", "skills", "proficiencies", "conditions"]),
  },
  {
    label: "Character Data",
    items: makeGroupItems(["languages", "attributes", "vitals"]),
  },
];

function makeGroupItems(keys) {
  return keys.map((key) => {
    const spec = CATEGORY_DUMP_SPECS[key];
    return {
      key,
      label: spec?.label ?? key,
      title: describeSpec(key, spec),
    };
  });
}

function describeSpec(key, spec) {
  if (!spec) return `Unknown category: ${key}`;
  if (spec.source === "pack") {
    const sysPacks = spec.packs?.pf2e ?? spec.packs?.sf2e ?? [];
    const sample = sysPacks.length > 0 ? sysPacks[0] : "(no pack)";
    return `Dev: dump ${spec.label} (pack ${sample}${spec.filter ? ", filtered" : ""}).`;
  }
  if (spec.source === "config") {
    const path = spec.configPath?.pf2e ?? spec.configPath?.sf2e ?? "(no path)";
    return `Dev: dump ${spec.label} from CONFIG.${path}.`;
  }
  if (spec.source === "unsupported") {
    return `Dev: ${spec.label} has no source mapped yet. Writes a placeholder JSON note.`;
  }
  return `Dev: dump ${spec.label}.`;
}

// --- shared per-entry projection + filter helpers --------------------------

/**
 * Pack-index entries arrive as a sparse object whose deep shape mirrors the
 * fields requested in getIndex({fields:[...]}). PF2e/SF2e store category
 * either as a flat string (newer items) or under `.value` (older items),
 * and the index projection preserves whichever shape the document used.
 * Normalize to a single string (or null).
 */
function categoryOf(entry) {
  const raw = entry?.system?.category;
  if (raw == null) return null;
  if (typeof raw === "object") return raw?.value ?? null;
  return raw;
}

/**
 * `system.level` is sometimes a flat number on items where the field is a
 * scalar (NPCs, conditions, etc.) and sometimes `{value: N}` on items that
 * use the leveled-thing DataModel (feats, spells). The index returns the
 * stored shape verbatim.
 */
function levelOf(entry) {
  const raw = entry?.system?.level;
  if (raw == null) return null;
  if (typeof raw === "object") return raw?.value ?? null;
  return raw;
}

/**
 * Traits live at system.traits.value as an array of strings on items that
 * derive from the trait-bearing DataModel. Returns the array verbatim or
 * an empty list for items with no traits container.
 */
function traitsOf(entry) {
  return entry?.system?.traits?.value ?? [];
}

/**
 * PF2e and SF2e expose the feat category on slightly different system paths
 * (system.category vs system.featType.value). Normalize.
 */
function featCategoryOf(entry) {
  return categoryOf(entry)
      ?? entry?.system?.featType?.value
      ?? null;
}

/**
 * PF2e/SF2e action category lives under system.actionCategory.value or
 * system.category depending on the system + version. Returns the first hit
 * (lowercased) or null.
 */
function actionCategoryOf(entry) {
  const raw = entry?.system?.actionCategory?.value
           ?? categoryOf(entry);
  return raw ? String(raw).toLowerCase() : null;
}

/**
 * Detect a focus spell. PF2e marks the cast type ("focus") under
 * system.cast.focus or as a trait ("focus"). SF2e mirrors the trait usage.
 */
function spellIsFocus(entry) {
  if (entry?.system?.cast?.focus === true) return true;
  if (categoryOf(entry) === "focus") return true;
  return traitsOf(entry).includes("focus");
}

/**
 * Spell level range inclusive (skips cantrips, which are 0).
 */
function spellLevelInRange(entry, lo, hi) {
  const lvl = levelOf(entry);
  return typeof lvl === "number" && lvl >= lo && lvl <= hi;
}

/**
 * Walk one or more compendium packs and apply the spec's filter (if any).
 * Returns { packs: [{pack, count}], entries: [...], entryCount }. Each
 * entry uses the shared projection {pack, _id, name, slug, type, category,
 * level, traits} so the dumped files share a consistent shape.
 *
 * Field projection: matcher-pack-index pre-caches every pack with the
 * shallow fields ["system.slug", "type"] via ensurePackIndex(). Any
 * subsequent pack.getIndex({fields:[...]}) call passes a Set-union of the
 * already-cached fields and the new ones to Foundry's CompendiumCollection.
 * V14's server-side projection builder uses setProperty() to construct an
 * object template ({system: {category: 1, ...}}) for the leveldb query.
 * setProperty() walks dotted paths with `target[p] === undefined ? {} :
 * target[p]`, so if BOTH "system.traits" AND "system.traits.value" appear in
 * the same Set, the parent path overwrites traits with a scalar 1 and then
 * the child path throws "Cannot create property 'value' on number '1'".
 * That bug killed every v0.6.9 pack-source category dump that had a
 * non-empty `fields` (weapons, armor, feats, actions, spells); the only
 * pack categories that survived were the ones with NO `fields` at all
 * (effects, conditions, ancestries, heritages, backgrounds, classes, ...).
 *
 * The fix here: trim the spec's requested fields to leaf paths only by
 * dropping any field that is a strict prefix of another field, then start
 * the baseFields from the same shallow pair the cache already uses
 * (["system.slug", "type"]). The result is a parent/child-collision-free
 * indexFields Set, and the V14 setProperty walk no longer crashes.
 */
async function buildPackCategoryDump(systemId, spec) {
  const { qualifyPackId, slugifyName } = await import("./matcher-slug-table.js");
  const packList = spec.packs?.[systemId] ?? [];
  // baseFields MUST match the precache (matcher-pack-index.js) so the
  // CompendiumCollection treats this call as a no-op when no extra fields
  // are needed. Anything beyond these two will widen the cache.
  const baseFields = ["system.slug", "type"];
  const requested = Array.from(new Set([...baseFields, ...(spec.fields ?? [])]));
  const fields = stripParentPaths(requested);
  const result = {
    packs: [],
    entries: [],
    entryCount: 0,
    packCount: 0,
    requestedFields: fields,
  };
  for (const p of packList) {
    const full = qualifyPackId(systemId, p);
    if (!full) continue;
    const pack = game?.packs?.get(full);
    if (!pack) {
      result.packs.push({ pack: full, missing: true, count: 0 });
      continue;
    }
    let idx;
    try {
      idx = await pack.getIndex({ fields });
    } catch (err) {
      result.packs.push({ pack: full, error: err?.message ?? String(err), count: 0 });
      continue;
    }
    let kept = 0;
    for (const e of idx) {
      if (typeof spec.filter === "function" && !spec.filter(e, systemId)) continue;
      const projected = {
        pack: full,
        _id: e._id,
        name: e.name,
        slug: e.system?.slug ?? slugifyName(e.name),
        type: e.type ?? null,
        category: categoryOf(e),
        level: levelOf(e),
        traits: traitsOf(e),
      };
      result.entries.push(projected);
      kept += 1;
    }
    result.packs.push({ pack: full, count: kept });
    result.packCount += 1;
  }
  result.entryCount = result.entries.length;
  result.entries.sort((a, b) => (a.name ?? "").localeCompare(b.name ?? ""));
  return result;
}

/**
 * Drop any dotted path that is a strict prefix of another dotted path in
 * the same list. Foundry's V14 server-side index projection collapses if
 * the indexFields Set contains both "system.traits" and "system.traits.
 * value": the parent is written as scalar 1, then setProperty() on the
 * child path tries to call (1).value = 1 and throws. Stripping the parent
 * lets the child path build its nested template cleanly.
 */
function stripParentPaths(fields) {
  const sorted = [...fields].sort();
  const keep = [];
  for (const f of sorted) {
    // Drop f if any other field starts with `${f}.` (f is a strict prefix).
    if (sorted.some((g) => g !== f && g.startsWith(`${f}.`))) continue;
    keep.push(f);
  }
  return keep;
}

/**
 * Dump a CONFIG-derived enum (skills, languages, attributes, etc) as a
 * sorted {key, label} list. PF2e/SF2e expose these as plain object maps.
 */
function buildConfigCategoryDump(systemId, spec) {
  const path = spec.configPath?.[systemId];
  if (!path) {
    return {
      entries: [],
      entryCount: 0,
      note: `No CONFIG path mapped for system ${systemId}.`,
    };
  }
  const value = resolveConfigPath(path);
  if (value == null) {
    return {
      entries: [],
      entryCount: 0,
      note: `CONFIG.${path} is missing on this system. Check the active world's CONFIG namespace.`,
      configPath: path,
    };
  }
  let entries;
  if (Array.isArray(value)) {
    entries = value.map((v, i) => ({ key: String(i), label: String(v) }));
  } else if (typeof value === "object") {
    entries = Object.entries(value).map(([key, label]) => ({
      key,
      label: typeof label === "string" ? label : (label?.label ?? JSON.stringify(label)),
    }));
  } else {
    entries = [{ key: path, label: String(value) }];
  }
  entries.sort((a, b) => a.key.localeCompare(b.key));
  return {
    configPath: path,
    entryCount: entries.length,
    entries,
  };
}

function resolveConfigPath(dottedPath) {
  if (!dottedPath || typeof globalThis.CONFIG !== "object") return null;
  const parts = dottedPath.split(".");
  let cur = globalThis.CONFIG;
  for (const p of parts) {
    if (cur == null) return null;
    cur = cur[p];
  }
  return cur;
}

// ============================================================
// END TEMP block (Index Dumps spec maps + helpers)
// ============================================================

export class HLOImportDialog extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "hlo-importer-dialog",
    classes: ["abyssal-engine", "hlo-importer"],
    tag: "div",
    window: {
      title: "Import from HeroLab Online",
      icon: "fa-solid fa-cloud-arrow-down",
      resizable: true,
    },
    position: { width: 720, height: "auto" },
    actions: {
      // NOTE on action names: ApplicationV2 (V13) reserves a handful of
      // action keys for its built-in framework behavior. "tab" in
      // particular collides with the V13 TABS navigation delegate and
      // gets silently intercepted, so we use "selectMode" instead.
      // "close" is also framework-recognized but happens to match our
      // intent (close the application), so we keep that one.
      import: HLOImportDialog._onImport,
      close: HLOImportDialog._onCloseAction,
      selectMode: HLOImportDialog._onTabChange,
      testConnection: HLOImportDialog._onTestConnection,
      copyOverrides: HLOImportDialog._onCopyOverrides,
      toggleFilters: HLOImportDialog._onToggleFilters,
      setLogLevel: HLOImportDialog._onSetLogLevel,
      downloadLog: HLOImportDialog._onDownloadLog,
      toggleWipe: HLOImportDialog._onToggleWipe,
      exportPackIndex: HLOImportDialog._onExportPackIndex,
      // TEMP (Index Dumps): two actions for the dev-only category dump
      // panel. toggleIndexDumps shows / hides the grid; exportIndexCategory
      // is the single dispatching handler that reads dataset.category and
      // looks up the recipe in CATEGORY_DUMP_SPECS. Remove these wires
      // when the panel is removed before public launch.
      toggleIndexDumps: HLOImportDialog._onToggleIndexDumps,
      exportIndexCategory: HLOImportDialog._onExportIndexCategory,
      // v1.0.1: dumpAllIndexes wire commented out alongside its button in
      // import-dialog.hbs. Per-category exportIndexCategory remains for
      // surgical dumps. _onDumpAllIndexes method definition is kept intact
      // below so re-enabling is a single-line un-comment here.
      // dumpAllIndexes: HLOImportDialog._onDumpAllIndexes,
    },
  };

  static PARTS = {
    body: {
      template: `modules/${MODULE_ID}/templates/import-dialog.hbs`,
    },
  };

  _log = [];
  // Default to the token tab since the API path is the headline UX. Paste
  // and Upload remain one click away for users who prefer the air-gapped
  // flow or are working from a downloaded export file.
  _mode = "token";

  // In-flight input values, preserved across re-renders within the same
  // dialog lifetime. Cleared naturally when the dialog instance is
  // discarded on close. Captured by _snapshotInputs() before any action
  // that triggers a re-render (Test Connection, Tab Change, Copy Stubs,
  // Import). Without these, the template's value="{{userToken}}" path
  // would always pull from saved settings on re-render, and the Element
  // Token input (which has no settings backing) would clear entirely.
  _currentUserToken = "";
  _currentElementToken = "";
  _currentPastedJson = "";
  // Guard against rapid-fire clicks on Fetch and Import / Test Connection
  // while a previous request is still in flight. Set true at the start of
  // an async action, false when it completes. The template disables the
  // primary action buttons while this is true.
  _isBusy = false;
  // Conversion-log level filter. "debug" (default during stabilization)
  // surfaces every entry; "info" hides debug entries. Header is clickable
  // and expands to show radio buttons that toggle this.
  _logLevel = "debug";
  _filtersExpanded = false;
  // TEMP (Index Dumps): disclosure state for the dev-only category dump
  // panel. Collapsed by default so the dialog does not show a 40-button
  // grid every time the user opens debug mode. Remove with the rest of
  // the Index Dumps feature before public launch.
  _indexDumpsExpanded = false;
  // When true, the existing-actor branch wipes EVERY item on the actor
  // (not just our flagged ones) before re-importing. Useful when a
  // prior failed import left dangling grant references that crash the
  // sheet on re-render. Off by default; user opts in via the dialog
  // checkbox. Reset on every dialog open.
  _wipeBeforeImport = false;

  async _prepareContext(_options) {
    const logCounts = { info: 0, warn: 0, error: 0, debug: 0 };
    for (const r of this._log) {
      if (logCounts[r.level] != null) logCounts[r.level] += 1;
    }
    // Filter the displayed log by current level: info hides debug
    // entries; debug shows everything. Errors and warnings always show.
    const visibleLog = this._log.filter((r) =>
      this._logLevel === "debug" ? true : r.level !== "debug",
    );
    // User Token: prefer the in-flight value the user just typed; if they
    // have not typed anything yet this render, fall back to the saved
    // module setting (so opening the dialog cold prefills from settings).
    const userToken = this._currentUserToken || getUserToken();
    return {
      log: visibleLog,
      logCounts,
      mode: this._mode,
      userToken,
      elementToken: this._currentElementToken,
      pastedJson: this._currentPastedJson,
      isBusy: this._isBusy,
      logLevel: this._logLevel,
      filtersExpanded: this._filtersExpanded,
      wipeBeforeImport: this._wipeBeforeImport,
      // Surface module version so the dialog template can render the
      // bottom-left version badge inside its own window (replacing the
      // viewport-fixed badge that used to live in main.js).
      moduleVersion: MODULE_VERSION,
      // TEMP (Index Dumps): surface the disclosure state + the grouped
      // category list so the template can render the 40-button grid
      // without hard-coding each label. Remove with the rest of the
      // Index Dumps feature before public launch.
      indexDumpsExpanded: this._indexDumpsExpanded,
      indexDumpCategories: INDEX_DUMP_CATEGORY_GROUPS,
    };
  }

  /**
   * Push a structured log entry. The dialog re-renders to show it on
   * the next render call. Debug-level entries are hidden by default;
   * the user reveals them via the Conversion log radio toggle.
   */
  _pushLog(level, message) {
    this._log.push({ level, message });
  }

  /**
   * Convenience for debug-level entries so callers do not have to
   * remember the literal level string.
   */
  _pushDebug(message) {
    this._log.push({ level: "debug", message });
  }

  /**
   * Read the current input values out of the DOM and stash them on the
   * instance. Call this before any action that triggers app.render(false)
   * so the user's in-progress typing survives the re-render.
   */
  _snapshotInputs() {
    const root = this.element;
    if (!root) return;
    const userTokenInput = root.querySelector("#hlo-user-token");
    if (userTokenInput) this._currentUserToken = userTokenInput.value ?? "";
    const elementTokenInput = root.querySelector("#hlo-element-token");
    if (elementTokenInput) this._currentElementToken = elementTokenInput.value ?? "";
    const pastedInput = root.querySelector("#hlo-json-input");
    if (pastedInput) this._currentPastedJson = pastedInput.value ?? "";
  }

  static async _onCopyOverrides(_event, _target) {
    const app = this;
    app._snapshotInputs();
    const stubs = extractFromLogRecords(app._log);
    const source = renderStubsAsSource(stubs);
    if (stubs.length === 0) {
      app._pushLog("info", "No unmatched items in the current log; nothing to copy.");
      app.render(false);
      return;
    }
    try {
      await navigator.clipboard.writeText(source);
      app._pushLog("info", `Copied ${stubs.length} override stub(s) to clipboard. Paste into src/cogs/matcher-overrides.js and replace PUT-FOUNDRY-SLUG-HERE with the real slug.`);
    } catch (err) {
      app._pushLog("warn", `Clipboard copy failed (${err?.message ?? err}). Stubs below.`);
      for (const line of source.split("\n")) {
        if (line.trim().length > 0) app._pushLog("info", line);
      }
    }
    app.render(false);
  }

  static async _onTestConnection(_event, _target) {
    const app = this;
    if (app._isBusy) return;
    app._snapshotInputs();
    const userToken = app._currentUserToken.trim() || getUserToken();
    if (!userToken) {
      app._pushLog("error", "Cannot test connection: User Token is empty.");
      app.render(false);
      return;
    }
    app._isBusy = true;
    app.render(false);
    try {
      app._pushLog("info", "Testing connection: exchanging user token...");
      // Bypass the cache so the test reflects the current token's validity,
      // not a previously-cached access token from a different value.
      tokenCache.invalidate();
      const accessToken = await tokenCache.get(userToken);
      const shortened = (accessToken ?? "").slice(0, 8);
      app._pushLog("info", `Connection OK. Access token received (prefix ${shortened}...).`);
    } catch (err) {
      if (err instanceof HLOApiError) {
        app._pushLog("error", `Connection test failed [${err.kind}]: ${err.message}`);
      } else {
        app._pushLog("error", `Connection test failed: ${err?.message ?? err}`);
      }
    } finally {
      app._isBusy = false;
    }
    app.render(false);
  }

  static async _onTabChange(_event, target) {
    const next = target?.dataset?.mode;
    if (!next || next === this._mode) return;
    this._snapshotInputs();
    this._mode = next;
    this._log = [];
    this.render(false);
  }

  static async _onToggleFilters(_event, _target) {
    const app = this;
    app._snapshotInputs();
    app._filtersExpanded = !app._filtersExpanded;
    app.render(false);
  }

  static async _onExportPackIndex(_event, _target) {
    const app = this;
    app._snapshotInputs();
    const systemId = game?.system?.id ?? "unknown";
    app._pushLog("info", "Dev: building / re-using pack index for export...");
    app.render(false);
    try {
      // ensurePackIndex builds (or returns cached) and we then dump
      // the actual Map by rebuilding our own snapshot from
      // packIndexStats + a fresh getIndex per pack. Simpler: walk
      // game.packs directly here since this is a dev helper.
      await ensurePackIndex(systemId);
      const dump = await app._buildPackIndexDump(systemId);
      const ts = new Date().toISOString().replace(/[:.]/g, "-");
      const filename = `pack-index-${systemId}-${ts}.json`;
      foundry.utils.saveDataToFile(
        JSON.stringify(dump, null, 2),
        "application/json",
        filename,
      );
      app._pushLog("info",
        `Dev: exported pack index to ${filename} (${dump.entryCount} entries across ${dump.packs.length} pack(s)). ` +
        `Commit to data/test-fixtures/ if sharing with the maintainer.`);
    } catch (err) {
      app._pushLog("error", `Pack-index export failed: ${err?.message ?? err}`);
      if (err?.stack) app._pushDebug(`Stack: ${err.stack.split("\n").slice(0, 4).join(" | ")}`);
    }
    app.render(false);
  }

  /**
   * Walk every pack listed in matcher-slug-table.js COMPSET_TO_PACKS
   * for the active system and produce a flat array of
   * {pack, _id, name, slug, type} records. Used by the Dev Export
   * Pack Index button so the maintainer (Shinra CC) can see the
   * deterministic-lookup ground truth without needing the LevelDB
   * extraction tooling.
   */
  async _buildPackIndexDump(systemId) {
    const { COMPSET_TO_PACKS, qualifyPackId, slugifyName } =
      await import("./matcher-slug-table.js");
    const packSet = new Set();
    for (const compset of Object.keys(COMPSET_TO_PACKS)) {
      const entry = COMPSET_TO_PACKS[compset];
      if (entry == null) continue;
      const list = Array.isArray(entry) ? entry : (entry[systemId] ?? []);
      for (const p of list) {
        const full = qualifyPackId(systemId, p);
        if (full) packSet.add(full);
      }
    }
    const out = {
      _comment: "Per-pack entry list extracted from Foundry's live game.packs. Use as ground truth for matcher-pack-index normalization and routing-table extension work. Generated by the Dev: Export Pack Index button in the HLO Importer dialog.",
      generatedAt: new Date().toISOString(),
      systemId,
      systemVersion: game?.system?.version ?? "unknown",
      foundryVersion: game?.version ?? "unknown",
      moduleVersion: MODULE_VERSION,
      packs: [],
      entryCount: 0,
    };
    for (const fullPack of [...packSet].sort()) {
      const pack = game?.packs?.get(fullPack);
      if (!pack) {
        out.packs.push({ pack: fullPack, missing: true, entries: [] });
        continue;
      }
      let idx;
      try {
        idx = await pack.getIndex({ fields: ["system.slug", "type"] });
      } catch (err) {
        out.packs.push({ pack: fullPack, error: err?.message ?? String(err), entries: [] });
        continue;
      }
      const entries = [];
      for (const e of idx) {
        entries.push({
          _id: e._id,
          name: e.name,
          slug: e.system?.slug ?? slugifyName(e.name),
          type: e.type ?? null,
        });
      }
      entries.sort((a, b) => (a.name ?? "").localeCompare(b.name ?? ""));
      out.packs.push({ pack: fullPack, count: entries.length, entries });
      out.entryCount += entries.length;
    }
    return out;
  }

  // ============================================================
  // TEMP: Index Dumps (Dev) - per-category JSON exports
  // ------------------------------------------------------------
  // Maintainer-only panel for inspecting focused slices of pack-
  // index or CONFIG data without exporting the full ~3 MB pack
  // index every time. ONE dispatching handler dispatches all ~40
  // buttons via target.dataset.category + the CATEGORY_DUMP_SPECS
  // map at module scope. Slated for removal / comment-out before
  // public launch. To remove cleanly:
  //   1. Drop the toggleIndexDumps + exportIndexCategory action
  //      wires in DEFAULT_OPTIONS.actions.
  //   2. Drop the _indexDumpsExpanded field + the surfacing of
  //      indexDumpsExpanded / indexDumpCategories in
  //      _prepareContext.
  //   3. Drop this section (toggle + dispatcher + builders).
  //   4. Drop CATEGORY_DUMP_SPECS + INDEX_DUMP_CATEGORY_GROUPS
  //      at module scope.
  //   5. Drop the .ae-index-dumps* block in import-dialog.hbs
  //      and the matching CSS in styles/import-dialog.css.
  // ============================================================

  static async _onToggleIndexDumps(_event, _target) {
    const app = this;
    app._snapshotInputs();
    app._indexDumpsExpanded = !app._indexDumpsExpanded;
    app.render(false);
  }

  /**
   * TEMP: single dispatching handler for every Index Dump button.
   * Reads target.dataset.category and looks up the recipe in
   * CATEGORY_DUMP_SPECS. Pack-based specs walk one or more packs
   * (optionally filtered); CONFIG-based specs read from CONFIG.PF2E
   * / CONFIG.SF2E. Filename pattern:
   *   pack-index-{system}-{category}-{ISO timestamp}.json
   */
  static async _onExportIndexCategory(_event, target) {
    const app = this;
    app._snapshotInputs();
    const category = target?.dataset?.category;
    if (!category) {
      app._pushLog("error", "Dev: exportIndexCategory called without a data-category.");
      app.render(false);
      return;
    }
    const spec = CATEGORY_DUMP_SPECS[category];
    if (!spec) {
      app._pushLog("error", `Dev: no CATEGORY_DUMP_SPECS entry for "${category}".`);
      app.render(false);
      return;
    }
    const systemId = game?.system?.id ?? "unknown";
    app._pushLog("info", `Dev: building ${spec.label} dump for ${systemId}...`);
    app.render(false);
    try {
      // Pack-based categories need the pack-index cache primed (cheap if
      // already built). CONFIG-based categories skip this and dump straight
      // from the active system's CONFIG object.
      if (spec.source === "pack") await ensurePackIndex(systemId);
      const dump = await app._buildCategoryDump(systemId, category, spec);
      const ts = new Date().toISOString().replace(/[:.]/g, "-");
      const filename = `pack-index-${systemId}-${category}-${ts}.json`;
      foundry.utils.saveDataToFile(
        JSON.stringify(dump, null, 2),
        "application/json",
        filename,
      );
      app._pushLog("info",
        `Dev: exported ${spec.label} dump to ${filename} (${dump.entryCount} entries).`);
    } catch (err) {
      app._pushLog("error", `Dev: ${spec.label} dump failed: ${err?.message ?? err}`);
      if (err?.stack) app._pushDebug(`Stack: ${err.stack.split("\n").slice(0, 4).join(" | ")}`);
    }
    app.render(false);
  }

  /**
   * TEMP: Dump every CATEGORY_DUMP_SPECS entry in one click. User still
   * has to approve each browser file-save dialog (Foundry has no way to
   * suppress them) but they do not have to click 42+ buttons one at a
   * time. v0.6.10 addition per user request: "clicking all 42 of those
   * button dumps was a pain in the ass." Sequential await + a small
   * inter-save sleep keeps the browser's download queue from coalescing
   * the files. Slated for removal with the rest of the dev tooling
   * before public launch.
   */
  static async _onDumpAllIndexes(_event, _target) {
    const app = this;
    app._snapshotInputs();
    const systemId = game?.system?.id ?? "unknown";
    const categories = Object.keys(CATEGORY_DUMP_SPECS);
    app._pushLog("info",
      `Dev: bulk-dumping ${categories.length} categor${categories.length === 1 ? "y" : "ies"} for ${systemId}. ` +
      `Approve each browser save dialog as they appear.`);
    app.render(false);
    // Prime the pack index once instead of on every per-category call.
    try {
      await ensurePackIndex(systemId);
    } catch (err) {
      app._pushLog("warn", `Dev: pack-index prime failed (${err?.message ?? err}); ` +
        `per-category dumps will rebuild as needed.`);
    }
    let succeeded = 0;
    let failed = 0;
    for (const category of categories) {
      const spec = CATEGORY_DUMP_SPECS[category];
      try {
        const dump = await app._buildCategoryDump(systemId, category, spec);
        const ts = new Date().toISOString().replace(/[:.]/g, "-");
        const filename = `pack-index-${systemId}-${category}-${ts}.json`;
        foundry.utils.saveDataToFile(
          JSON.stringify(dump, null, 2),
          "application/json",
          filename,
        );
        succeeded += 1;
        app._pushDebug(`Dev bulk: ${category} -> ${filename} (${dump.entryCount} entries)`);
      } catch (err) {
        failed += 1;
        app._pushLog("warn", `Dev bulk: ${spec.label} failed: ${err?.message ?? err}`);
      }
      // Small inter-save delay so the browser's download queue handles
      // each file as its own action instead of coalescing rapid bursts.
      // 75ms is short enough not to be annoying, long enough that each
      // saveDataToFile call gets its own browser turn.
      await new Promise((resolve) => setTimeout(resolve, 75));
    }
    app._pushLog("info",
      `Dev: bulk dump complete. ${succeeded} succeeded, ${failed} failed.`);
    app.render(false);
  }

  /**
   * TEMP: build a category-specific dump object. Delegates to one of two
   * builders based on spec.source ("pack" walks compendium packs; "config"
   * reads from CONFIG.PF2E / CONFIG.SF2E). Returns the same wrapper shape
   * as _buildPackIndexDump (header metadata + entries + entryCount) so the
   * downloaded JSON files share a consistent shape with the full dump.
   */
  async _buildCategoryDump(systemId, category, spec) {
    const base = {
      _comment: `Index dump for category "${category}" (${spec.label}). TEMP dev-only maintainer feature; not in the public-launch build. Source: ${spec.source}.`,
      generatedAt: new Date().toISOString(),
      systemId,
      systemVersion: game?.system?.version ?? "unknown",
      foundryVersion: game?.version ?? "unknown",
      moduleVersion: MODULE_VERSION,
      category,
      label: spec.label,
      sourceKind: spec.source,
    };
    if (spec.source === "pack") {
      return { ...base, ...(await buildPackCategoryDump(systemId, spec)) };
    }
    if (spec.source === "config") {
      return { ...base, ...buildConfigCategoryDump(systemId, spec) };
    }
    if (spec.source === "unsupported") {
      return {
        ...base,
        note: spec.note ?? "No source for this category in V14; needs research.",
        entryCount: 0,
        entries: [],
      };
    }
    throw new Error(`Unknown spec.source "${spec.source}" for category "${category}".`);
  }

  // ============================================================
  // END TEMP block (Index Dumps)
  // ============================================================

  static async _onToggleWipe(_event, target) {
    const app = this;
    app._snapshotInputs();
    app._wipeBeforeImport = !!(target?.checked ?? !app._wipeBeforeImport);
    app.render(false);
  }

  static async _onSetLogLevel(_event, target) {
    const app = this;
    app._snapshotInputs();
    const next = target?.value;
    if (next === "info" || next === "debug") {
      app._logLevel = next;
      app.render(false);
    }
  }

  /**
   * Export the full conversion log as a downloadable .txt file. Visible
   * only when log level is "debug" (template gates the button). Includes
   * an export-time header, then one line per entry: [LEVEL] message.
   */
  static async _onDownloadLog(_event, _target) {
    const app = this;
    if (!app._log || app._log.length === 0) {
      app._pushLog("info", "Conversion log is empty; nothing to download.");
      app.render(false);
      return;
    }
    const stamp = new Date().toISOString();
    const lines = [
      `# HLO Importer conversion log`,
      `# Exported: ${stamp}`,
      `# Module:   v${MODULE_VERSION}`,
      `# Entries:  ${app._log.length}`,
      ``,
    ];
    for (const r of app._log) {
      const level = String(r.level ?? "info").toUpperCase().padEnd(5, " ");
      lines.push(`[${level}] ${r.message ?? ""}`);
    }
    // Use Foundry's helper instead of the raw <a download> + blob URL
    // pattern. Inside Electron, an <a download> with a blob: href can
    // get treated as a navigation - Windows then prompts "Get an app
    // to open this 'blob' link" instead of saving the file.
    // foundry.utils.saveDataToFile handles the Electron path correctly
    // (this is the same call chat-message export uses for log dumps).
    const safeStamp = stamp.replace(/[:.]/g, "-");
    foundry.utils.saveDataToFile(
      lines.join("\n"),
      "text/plain",
      `hlo-import-log-${safeStamp}.txt`,
    );
    app._pushLog("info", `Conversion log exported (${app._log.length} entries).`);
    app.render(false);
  }

  static async _onImport(_event, _target) {
    const app = this;
    if (app._isBusy) return;
    app._snapshotInputs();
    app._isBusy = true;
    app.render(false);
    try {
      app._pushDebug(`_onImport entered: mode=${app._mode}`);
      let exportJson = null;
      if (app._mode === "token")       exportJson = await app._fetchViaApi();
      else if (app._mode === "upload") exportJson = await app._readUploadedFile();
      else                              exportJson = app._readPastedJson();
      app._pushDebug(`Input acquired: ${exportJson ? "got JSON" : "no JSON (aborting)"}`);
      if (exportJson) await app._runPipeline(exportJson);
    } catch (err) {
      logger.error("Import failed", err);
      app._pushLog("error", `Import failed: ${err?.message ?? err}`);
      if (err?.stack) app._pushDebug(`Stack: ${err.stack.split("\n").slice(0, 6).join(" | ")}`);
    } finally {
      app._isBusy = false;
    }
    // Single render after _isBusy is reset. The previous structure had an
    // early return INSIDE the try with its own render() call, which painted
    // the dialog while _isBusy was still true and then never repainted
    // after `finally` cleared it. The button stayed "Working..." forever.
    app.render(false);
  }

  async _readUploadedFile() {
    const fileInput = this.element.querySelector("#hlo-json-file");
    const file = fileInput?.files?.[0];
    if (!file) {
      this._pushLog("error", "Choose a JSON file before clicking Import.");
      return null;
    }
    let text;
    try {
      text = await file.text();
    } catch (err) {
      this._pushLog("error", `Failed to read file: ${err.message ?? err}`);
      return null;
    }
    try {
      return JSON.parse(text);
    } catch (err) {
      this._pushLog("error", `JSON parse failed: ${err.message}`);
      return null;
    }
  }

  static _onCloseAction(_event, _target) {
    return this.close();
  }

  // --- helpers ---------------------------------------------------------------

  _readPastedJson() {
    const textarea = this.element.querySelector("#hlo-json-input");
    const raw = textarea?.value?.trim();
    if (!raw) {
      this._pushLog("error", "Paste an HLO export before clicking Import.");
      return null;
    }
    try {
      return JSON.parse(raw);
    } catch (err) {
      this._pushLog("error", `JSON parse failed: ${err.message}`);
      return null;
    }
  }

  async _fetchViaApi() {
    const userTokenInput = this.element.querySelector("#hlo-user-token");
    const elementTokenInput = this.element.querySelector("#hlo-element-token");
    const userToken = (userTokenInput?.value ?? "").trim() || getUserToken();
    const elementToken = (elementTokenInput?.value ?? "").trim();

    if (!userToken) {
      this._pushLog("error", "User Token is required. Save it in module settings or paste it above.");
      return null;
    }
    if (!elementToken) {
      this._pushLog("error", "Element Token is required.");
      return null;
    }

    try {
      this._pushLog("info", "Exchanging user token for access token...");
      this._pushDebug(`User token length: ${userToken.length}, JWT-like: ${/^ey[A-Za-z0-9_-]/.test(userToken)}`);
      this._pushDebug(`Element token: "${elementToken}" (length ${elementToken.length})`);
      const accessToken = await tokenCache.get(userToken);
      this._pushLog("info", "Access token acquired. Fetching character...");
      this._pushDebug(`Access token length: ${accessToken?.length ?? 0}, prefix: ${(accessToken ?? "").slice(0, 12)}`);
      const exportJson = await getCharacter(accessToken, elementToken, {
        onPoll: (iteration, data) => {
          const keys = Object.keys(data ?? {});
          const summary = `poll #${iteration}: keys=[${keys.join(", ")}], result=${JSON.stringify(data?.result)}, severity=${JSON.stringify(data?.severity)}, status=${JSON.stringify(data?.status)}, wait=${JSON.stringify(data?.wait)}, hasExport=${data?.export != null}`;
          this._pushDebug(summary);
          // Dump the literal HLO response body (capped) so the user sees
          // exactly what the server returned, not just our parsed view.
          // Without this, debugging "stuck on status=1" requires guessing.
          let raw;
          try { raw = JSON.stringify(data); } catch { raw = String(data); }
          if (raw && raw.length > 0) {
            const capped = raw.length > 1200 ? `${raw.slice(0, 1200)}... [truncated, total ${raw.length} chars]` : raw;
            this._pushDebug(`poll #${iteration} raw body: ${capped}`);
          }
          // Re-render so the user sees each poll line during the wait,
          // not just one big silent block until timeout.
          this.render(false);
        },
      });
      this._pushLog("info", "Character fetched.");
      const topKeys = Object.keys(exportJson ?? {});
      const charId = exportJson?.portfolio?.charId;
      const actors = Object.keys(exportJson?.actors ?? {});
      this._pushDebug(`HLO export top-level keys: [${topKeys.join(", ")}]; portfolio.charId=${charId}; actors=[${actors.join(", ")}]`);
      return exportJson;
    } catch (err) {
      if (err instanceof HLOApiError) {
        this._pushLog("error", `[${err.kind}] ${err.message}`);
        if (err.body != null) {
          let bodyStr;
          try {
            bodyStr = JSON.stringify(err.body);
          } catch {
            bodyStr = String(err.body);
          }
          // Cap at ~1.5 KB so a huge response doesn't blow up the log UI.
          const capped = bodyStr.length > 1500 ? `${bodyStr.slice(0, 1500)}... [truncated, total ${bodyStr.length} chars]` : bodyStr;
          this._pushDebug(`HLO error body: ${capped}`);
        }
        if (err.status != null) this._pushDebug(`HTTP status: ${err.status}`);
        if (err.cause)         this._pushDebug(`Underlying cause: ${err.cause?.message ?? err.cause}`);
      } else {
        this._pushLog("error", `API failure: ${err.message ?? err}`);
        if (err?.stack) this._pushDebug(`Stack: ${err.stack.split("\n").slice(0, 5).join(" | ")}`);
      }
      return null;
    }
  }

  async _runPipeline(exportJson) {
    // v0.6.11: brute-force wizard silencer wraps the WHOLE pipeline.
    // Even with v0.6.9's prefillGrantingRules, SF2e classes that load
    // features via system.items + createGrantedItems (Operative et al)
    // can still surface a PickAThingPrompt during embed: the prompt
    // fires from the GRANTED feature's ChoiceSet, not from the parent
    // class's system.rules where prefill operates. The silencer is a
    // belt-and-suspenders safety net that intercepts any prompt that
    // appears DURING import and auto-resolves it to an HLO-informed
    // choice or, failing that, the first option, so the user is not
    // interrupted mid-walkaway. Outside of import the silencer is
    // fully uninstalled, so normal Foundry play still shows the
    // wizard as designed. try/finally guarantees teardown even if
    // the pipeline throws.
    const actorsBag = exportJson?.actors;
    const actorsList = Array.isArray(actorsBag)
      ? actorsBag
      : (actorsBag && typeof actorsBag === "object" ? Object.values(actorsBag) : []);
    const hloItemsForSilencer = actorsList.flatMap((a) => {
      const items = a?.items;
      if (Array.isArray(items)) return items;
      if (items && typeof items === "object") return Object.values(items);
      return [];
    });
    installWizardSilencer({
      pushLog: (lvl, msg) => this._pushLog(lvl, msg),
      pushDebug: (msg) => this._pushDebug(msg),
      hloItems: hloItemsForSilencer,
    });
    try {
      return await this._runPipelineImpl(exportJson);
    } finally {
      uninstallWizardSilencer();
    }
  }

  async _runPipelineImpl(exportJson) {
    // Build the deterministic pack index before parsing so matchAll
    // can hit it on the first item. Idempotent + cached for the
    // session, so reruns are cheap.
    const systemId = game?.system?.id;
    if (systemId) {
      try {
        await ensurePackIndex(systemId);
        const stats = packIndexStats();
        if (stats.built) {
          this._pushDebug(
            `Pack index ready: ${stats.totalKeys} keys for ${stats.system}; ` +
            `top compsets: ${Object.entries(stats.byCompset).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([c,n])=>`${c}=${n}`).join(", ")}.`
          );
        }
      } catch (err) {
        this._pushLog("warn", `Pack index build failed (${err?.message ?? err}); ` +
          `matcher will fall back to slug/fuzzy/override pipeline.`);
      }
    }
    const ir = parsePortfolio(exportJson);
    this._pushLog("info", `Parsed portfolio: ${ir.actors.length} actor(s), ${ir.actors.reduce((n, a) => n + a.items.length, 0)} item(s).`);
    this._pushDebug(`Portfolio metadata: ${JSON.stringify(ir.metadata)}`);
    this._pushDebug(`Portfolio: ${JSON.stringify(ir.portfolio)}`);
    for (const w of ir.warnings) this._pushLog("warn", `[${w.code}] ${w.message}`);

    const resolver = makeFoundryResolver();
    for (const actor of ir.actors) {
      this._pushDebug(`Actor "${actor.name}" (${actor.key}): system=${actor.inferredSystem}, actorType=${actor.actorType}${actor.minionSubtype ? `(${actor.minionSubtype})` : ""}, level=${actor.gameValues?.levelNet}, race=${actor.gameValues?.race}, class=${actor.gameValues?.classText}, items=${actor.items.length}`);
      // Compset distribution
      const compsetCounts = {};
      for (const it of actor.items) compsetCounts[it.compset] = (compsetCounts[it.compset] ?? 0) + 1;
      this._pushDebug(`Compset distribution: ${Object.entries(compsetCounts).sort((a,b)=>b[1]-a[1]).map(([c,n])=>`${c}=${n}`).join(", ")}`);

      const matched = await matchAll(actor, actor.inferredSystem, resolver);
      // v0.6.12: feed the silencer the matched-UUID pool BEFORE embed so
      // any ChoiceSet prompt that fires during createEmbeddedDocuments
      // can prefer a pre-resolved UUID over a label heuristic. Also
      // overwrite hloItemPool with the parsed-IR items for THIS actor
      // (which carry lowercase `profLevel` + the rest of the parser-
      // normalized shape) so pool 2 (HLO skill picks) is scoped to the
      // actor currently embedding instead of the raw cross-actor pool
      // from install time.
      setSilencerMatchedUuids(matched);
      if (_wizardSilencerState) {
        _wizardSilencerState.hloItemPool = actor.items;
      }
      const hits = matched.filter((m) => m.match).length;
      const misses = matched.filter((m) => !m.match && COMPENDIUM_COMPSETS.has(m.item.compset)).length;
      // Per-strategy distribution so the user can see the canonical-
      // lookup hit rate (added in v0.6.0) vs the legacy slug/fuzzy/
      // override fallbacks. v0.6.6 adds "skip" for items HLO sends
      // that are not compendium-eligible (Fist, env-protection echo).
      const byStrategy = { canonical: 0, override: 0, slug: 0, fuzzy: 0, skip: 0 };
      for (const { match } of matched) {
        if (!match) continue;
        if (byStrategy[match.strategy] != null) byStrategy[match.strategy] += 1;
      }
      const distribution = Object.entries(byStrategy)
        .filter(([, n]) => n > 0)
        .map(([s, n]) => `${s}=${n}`)
        .join(", ");
      // Real hits exclude skips (they did not produce embed items).
      const realHits = hits - byStrategy.skip;
      this._pushLog("info",
        `${actor.name}: ${realHits} matched (${distribution || "none"}), ${misses} unmatched (compendium-eligible).`);

      // Per-item match detail at debug level
      for (const { item, match } of matched) {
        if (match) {
          if (match.strategy === "skip") {
            this._pushDebug(`  skip  [${item.compset}] "${item.name}" (slug ${item.slug}) - ${match.skipReason ?? "by design"}`);
          } else {
            this._pushDebug(`  match [${item.compset}] "${item.name}" -> ${match.pack}/${match.slug} (${match.strategy}, c=${match.confidence.toFixed(2)})`);
          }
        } else if (COMPENDIUM_COMPSETS.has(item.compset)) {
          this._pushDebug(`  miss  [${item.compset}] "${item.name}" (slug ${item.slug})`);
        }
      }

      const skeleton = (actor.inferredSystem === "sf2e")
        ? buildActorSkeletonSf2e(actor, matched, actor.inferredSystem)
        : buildActorSkeleton(actor, matched, actor.inferredSystem);
      this._pushDebug(`Skeleton items: ${skeleton.items?.length ?? 0} (refs + lores). System keys: ${Object.keys(skeleton.system ?? {}).join(", ")}`);
      const attachmentPlan = buildAttachmentPlan(actor);
      this._pushDebug(`Attachment plan: ${attachmentPlan.length} operations`);
      const resolvedActorData = await resolveSkeletonForCreate(
        skeleton,
        attachmentPlan,
        actor.items,
        (msg) => this._pushDebug(msg),
      );
      this._pushDebug(`Resolved actor data: items=${resolvedActorData.items?.length ?? 0}, type=${resolvedActorData.type}, name="${resolvedActorData.name}"`);

      // Target the dialog's source actor if it was opened from a sheet
      // (main.js passes app.actor as the document option). "Click button
      // on Sheet X should populate Sheet X" is the user expectation;
      // running flag/name search instead would silently target a
      // different actor. Standalone-opened dialogs fall through to the
      // flag/name search and then to creating a fresh actor.
      const sourceDoc = this.options?.document;
      const match = sourceDoc instanceof Actor
        ? { actor: sourceDoc, matchedBy: "current sheet" }
        : findExistingHloActor(actor.portfolioCharId, actor.key, resolvedActorData.name);
      let resultActor;
      // Apply the SF2e/PF2e defensive scaffold to OUR overrides before
      // either path uses them. Done once here so both branches benefit.
      const scaffoldedSystem = scaffoldSystemForCharacter(
        resolvedActorData.system ?? {},
      );
      // Ensure flags.pf2e exists on every item. Required to prevent
      // FeatPF2e.prepareActorData from crashing on flags.pf2e.grantedBy
      // dot-chain access during embed.
      ensureItemFlags(resolvedActorData.items);
      if (match) {
        const { actor: existing, matchedBy } = match;
        // Re-import semantics: remove items WE previously added (those
        // carrying our module flag), then create the fresh set. User-
        // added items are left alone. This avoids stacking duplicates
        // and avoids the SF2e Class.getLinkedItems crash that happens
        // when createEmbeddedDocuments runs against a live actor with
        // items mid-default.
        // Wipe-before-import mode: clear EVERY item on the actor, not
        // just ours. Used to recover from a corrupted state where prior
        // imports left dangling grant references that crash the prepare
        // pipeline. Otherwise we only delete items we created (preserves
        // user-added items the way the dialog has always done).
        const targetsToDelete = this._wipeBeforeImport
          ? existing.items.contents
          : existing.items.filter((i) => i.getFlag(MODULE_ID, "importedFrom")
              || i.getFlag(MODULE_ID, "sourceCompset")
              || i.getFlag(MODULE_ID, "hloSlug"));
        if (this._wipeBeforeImport && targetsToDelete.length > 0) {
          this._pushLog("warn",
            `Reset Actor mode: wiping ALL ${targetsToDelete.length} item(s) ` +
            `on "${existing.name}" before re-importing. User-added items will ` +
            `be removed; the import only restores items HLO knows about.`);
        }
        if (targetsToDelete.length > 0) {
          await this._deleteItemsResilient(existing, targetsToDelete.map((i) => i.id));
        }
        // Match log message phrasing to the actual operation that
        // happened: in wipe mode we removed EVERYTHING; in default
        // mode we removed only our prior imports and left user-added
        // items alone.
        const removalNote = this._wipeBeforeImport
          ? `wiped ALL ${targetsToDelete.length} prior item(s) on the actor`
          : `removed ${targetsToDelete.length} previously-imported item(s); user-added items left alone`;
        this._pushLog("warn",
          `Matched existing actor "${existing.name}" (id ${existing.id}) by ${matchedBy} ` +
          `(charId ${actor.portfolioCharId}). ${removalNote}. Re-applying fresh import.`);
        // Sanitize orphan numeric scalars at known nesting points before
        // re-applying the scaffold. Foundry's setProperty walks parents
        // with `target[p] === undefined ? {} : target[p]`, so a prior
        // write of `system.X = 1` (e.g. an AELikeRuleElement upgrading
        // an undefined path) leaves a bare number that the NEXT
        // import's setProperty("system.X.value", N) throws on with
        // "Cannot create property 'value' on number '1'" because target
        // is a primitive. The TypeError is caught inside SF2e's
        // AELikeRuleElement.#applyAELike try/catch (sf2e.mjs:44062-65)
        // but the underlying Foundry assertion still surfaces ~16 times
        // per import. Same root cause as v0.6.10's buildPackCategoryDump
        // fix (setProperty parent/child path collisions).
        //
        // Strategy: walk every leaf at the known orphan-prone roots and,
        // if the existing _source has a scalar (number / string / null)
        // where the system expects an object, replace it with `{}` so
        // the upcoming mergeObject overlays a proper object shape
        // instead of a primitive. Deleting the parent outright is not
        // safe because SF2e's prepareBaseData reads from `_source.system
        // .skills[key]?.rank` (sf2e.mjs:38579) and `_source.system
        // .perception.X` (sf2e.mjs:21216 et al) directly; an undefined
        // intermediate would crash prepare. Replacing scalars with `{}`
        // is the minimal change that keeps the source data shape valid
        // AND eliminates the parent/child collision.
        try {
          const sanitizedRoots = sanitizeSystemOrphans(existing._source?.system);
          if (sanitizedRoots.length > 0) {
            this._pushDebug(
              `Sanitized ${sanitizedRoots.length} orphan numeric scalar(s) in actor _source ` +
              `before re-import update: ${sanitizedRoots.join(", ")}`);
            const sanitizePatch = { system: {} };
            for (const path of sanitizedRoots) {
              const segs = path.split(".");
              let cursor = sanitizePatch.system;
              for (let i = 0; i < segs.length - 1; i++) {
                cursor[segs[i]] ??= {};
                cursor = cursor[segs[i]];
              }
              cursor[segs[segs.length - 1]] = {};
            }
            await existing.update(sanitizePatch, { render: false, diff: false });
          }
        } catch (stripErr) {
          this._pushLog("warn",
            `Pre-import orphan-scalar sanitization failed (${stripErr?.message ?? stripErr}); ` +
            `continuing with merge-only update. Console may show "Cannot create property ` +
            `'value' on number" errors during item embed; the import should still complete.`);
        }
        await existing.update({
          name: resolvedActorData.name,
          system: scaffoldedSystem,
          flags: resolvedActorData.flags,
        });
        await this._createItemsResilient(existing, resolvedActorData.items, {
          systemId: actor.inferredSystem,
          actorLevel: actor.gameValues?.levelNet ?? 1,
          hloItems: actor.items,
        });
        resultActor = existing;
      } else {
        // Two-phase create: build a blank SF2e/PF2e character first so
        // the system runs its full default-and-prepare cycle on a clean
        // slate, then layer our system overrides and items on top. The
        // single-call form (Actor.create with full system) sometimes
        // leaves the actor with derived structures missing, which made
        // sheet rendering crash silently. The two-phase form gives the
        // system two prepare passes to scaffold required fields.
        const blank = await Actor.create({
          name: resolvedActorData.name,
          type: resolvedActorData.type,
          flags: resolvedActorData.flags,
        });
        await blank.update({ system: scaffoldedSystem });
        await this._createItemsResilient(blank, resolvedActorData.items, {
          systemId: actor.inferredSystem,
          actorLevel: actor.gameValues?.levelNet ?? 1,
          hloItems: actor.items,
        });
        resultActor = blank;
      }
      this._pushLog("info", `${match ? "Updated" : "Created"} actor: ${resultActor.name} (id ${resultActor.id}).`);

      if (getLogToJournal()) {
        const journal = await createConversionJournal({
          records: this._log.slice(),
          actorName: resultActor.name,
          charId: actor.portfolioCharId,
          importedActor: resultActor,
        });
        if (journal) {
          this._pushLog("info", `Conversion log saved as JournalEntry "${journal.name}".`);
        }
      }

      // Collect unmatched-compendium items for both the conversion-
      // log warn entries (kept so debug-level users still get the
      // line-per-miss record) AND for the end-of-import modal that
      // surfaces the same list above the actor sheet so users
      // cannot miss it the way they missed the log-only warning.
      const unmatchedForModal = [];
      for (const { item, match } of matched) {
        if (!match && COMPENDIUM_COMPSETS.has(item.compset)) {
          this._pushLog("warn", `Unmatched ${item.compset}: ${item.name} (slug ${item.slug}). Add manually.`);
          unmatchedForModal.push({
            compset: item.compset,
            name: item.name,
            slug: item.slug,
            suggestedPack: suggestPackFor(item.compset),
          });
        }
      }
      // v0.6.6: surface deliberate skips so the user knows we did
      // not silently drop the item; we acknowledge it but the
      // system provides it (Fist is auto-granted; env-protection
      // echo lives on the upgrade).
      const skips = matched.filter((m) => m.match?.strategy === "skip");
      for (const { item, match } of skips) {
        this._pushLog("info", `Skipped ${item.compset}: ${item.name} (slug ${item.slug}) - ${match.skipReason}. No compendium item needed.`);
      }
      // End-of-actor modal: if anything went unmatched, block on
      // the user acknowledging the list before we continue to the
      // next actor (or, on a single-actor import, before the
      // pipeline reports "Import complete"). The modal resolves
      // immediately when the list is empty, so this is safe to
      // call unconditionally. Awaiting it means a multi-actor
      // import will show one modal per actor in sequence rather
      // than stacking N windows the user has to dismiss in
      // arbitrary order.
      if (unmatchedForModal.length > 0) {
        await showUnmatchedModal(unmatchedForModal, {
          actorName: resultActor?.name ?? actor.name,
          systemId: actor.inferredSystem,
        });
      }
    }
    this._pushLog("info", "Import complete.");
  }

  /**
   * Delete items resiliently. Same try-bulk-then-per-item pattern as
   * the create path. SF2e's processGrantDeletions can throw "Cannot
   * read properties of undefined (reading 'grantedBy')" when the
   * actor carries items from a previous half-failed import whose
   * grant chain references items that no longer exist. The bulk
   * delete then atomic-fails. Per-item fallback isolates each
   * deletion so the surviving items still get cleaned up; broken
   * grant references are logged but do not block the import.
   */
  async _deleteItemsResilient(actor, itemIds) {
    if (!Array.isArray(itemIds) || itemIds.length === 0) return;
    try {
      await actor.deleteEmbeddedDocuments("Item", itemIds);
      this._pushDebug(`Bulk-deleted ${itemIds.length} prior item(s).`);
      return;
    } catch (bulkErr) {
      this._pushLog("warn",
        `Bulk delete of prior items failed (${bulkErr?.message ?? bulkErr}). ` +
        `Falling back to per-item delete so one broken grant chain does not ` +
        `block the cleanup.`);
      if (bulkErr?.stack) {
        this._pushDebug(`Bulk-delete stack: ${bulkErr.stack.split("\n").slice(0, 4).join(" | ")}`);
      }
    }
    let succeeded = 0;
    const failures = [];
    for (const id of itemIds) {
      try {
        await actor.deleteEmbeddedDocuments("Item", [id]);
        succeeded += 1;
      } catch (err) {
        const item = actor.items.get(id);
        failures.push({ name: item?.name ?? `(id ${id})`, message: err?.message ?? String(err) });
      }
    }
    this._pushLog("info",
      `Per-item delete: ${succeeded} of ${itemIds.length} prior item(s) removed; ${failures.length} skipped.`);
    for (const f of failures) {
      this._pushLog("warn", `  Could not delete prior item "${f.name}": ${f.message}.`);
    }
  }

  /**
   * Embed items resiliently. Tries the bulk createEmbeddedDocuments call
   * first (fast path); on any failure, falls back to per-item creation
   * so a single bad item cannot block the rest. Failures are logged to
   * the conversion log with the item name + the underlying error
   * message; the actor stays openable instead of being half-built and
   * unrecoverable. The user can then manually drag-and-drop the
   * skipped item from the compendium browser.
   *
   * Why this matters: SF2e's prepare pipeline (FeatPF2e.prepareActorData
   * et al) reads from the parent actor during embed. If the actor is
   * missing a field the system expects (build.languages.value, etc.),
   * the WHOLE bulk createDocuments call throws and zero items get
   * added. The user is left with a sheet that has updated system data
   * but no items, and depending on what got partially applied the
   * sheet may not even open. Per-item fallback lets us isolate the
   * single bad item and ship the other thirty-three.
   */
  async _createItemsResilient(actor, items, ctx = {}) {
    if (!Array.isArray(items) || items.length === 0) return;
    // Three-phase embed pipeline:
    //   Phase 0 (NEW v0.6.11): if SF2e and a Class is present, the
    //            sf2e-grant-resolver pre-pulls every class feature
    //            (system.items map) and wires the bidirectional
    //            flags.sf2e.itemGrants/grantedBy chain ourselves.
    //            The class then gets system.items cleared so SF2e's
    //            ABCItemPF2e.createGrantedItems is a no-op, and the
    //            pre-resolved features ride along in the same Phase 1
    //            batch with keepId:true so the pre-wired IDs survive.
    //   Phase 1: embed grant-bearing items (ancestry/class/heritage/
    //            deity/background) + any synthetic class features
    //            from Phase 0 with keepId:true. Wizard prompts do not
    //            fire because the choices are pre-filled and the
    //            class's system.items is empty.
    //   Phase 2: snapshot the actor's items list before/after Phase 1
    //            to detect what the auto-grant pipelines created.
    //            Items that newly appeared, are NOT ours, AND carry
    //            flags.pf2e.grantedBy are auto-grants from the class/
    //            ancestry/etc.
    //   Phase 3: dedup the remaining HLO items against the auto-grant
    //            set by (type, slug). HLO's duplicates get dropped;
    //            the auto-granted version stays because it has the
    //            proper grant-chain linkage. Then embed the survivors
    //            normally so their effects/conditions/active-rules
    //            still fire.
    const suppressGrants = getSuppressGrantPrompts();
    const grantBearingTypes = new Set(["ancestry", "class", "heritage", "deity", "background"]);
    const grantBearing = [];
    const spellEntries = [];
    let regular = [];
    for (const it of items) {
      if (it.type === "spellcastingEntry") spellEntries.push(it);
      else if (suppressGrants && grantBearingTypes.has(it.type)) grantBearing.push(it);
      else regular.push(it);
    }

    // Phase 0: SF2e class grant pre-pull. The class item (if any) in
    // grantBearing gets replaced with its patched form (system.items
    // emptied) and the resolved feature sources get prepended to
    // grantBearing so they all embed in the same call with keepId:true.
    // PF2e classes skip this branch and fall through to the existing
    // prefillGrantingRules path that ran on resolvedItems upstream.
    let syntheticAdded = 0;
    if (suppressGrants && ctx.systemId === "sf2e") {
      const classIdx = grantBearing.findIndex((it) => it?.type === "class");
      if (classIdx >= 0) {
        const classSource = grantBearing[classIdx];
        try {
          const { patchedClass, syntheticFeatures } = await resolveSf2eClassGrants(
            classSource,
            ctx.hloItems ?? [],
            ctx.actorLevel ?? 1,
            (msg) => this._pushDebug(msg),
          );
          if (patchedClass) {
            grantBearing[classIdx] = patchedClass;
            // Push features AFTER the class so SF2e's createDocuments
            // override sees the class first and processes preCreate
            // deletions of any old class before the feature wave.
            grantBearing.push(...syntheticFeatures);
            syntheticAdded = syntheticFeatures.length;
            this._pushLog("info",
              `SF2e grant resolver: pre-resolved ${syntheticAdded} class feature(s) for ` +
              `${patchedClass.name}; SF2e wizard cascade bypassed.`);
          }
        } catch (err) {
          this._pushLog("warn",
            `SF2e grant resolver failed (${err?.message ?? err}); falling back to ` +
            `the v0.6.9 prefill path. Choice wizard prompts may appear.`);
          if (err?.stack) {
            this._pushDebug(`Grant resolver stack: ${err.stack.split("\n").slice(0, 4).join(" | ")}`);
          }
        }
      }
    }

    // Snapshot before any embed so we can diff against the result and
    // attribute new items to either us or to system auto-grants.
    const idsBeforeAnyEmbed = new Set(actor.items.contents.map((i) => i.id));

    if (grantBearing.length > 0) {
      // v0.6.11: when the SF2e grant resolver fired, every synthetic
      // feature has a pre-assigned _id that the bidirectional flag
      // chain depends on. Embedding with keepId:true is mandatory in
      // that case; SF2e's createDocuments override at sf2e.mjs:50146
      // honors the operation.keepId flag, otherwise it rewrites _id
      // and the grant graph snaps.
      const grantedTypes = grantBearing.map((i) => `${i.name} (${i.type})`).join(", ");
      this._pushLog("info",
        `Embedding ${grantBearing.length} grant-bearing item(s): ${grantedTypes}.` +
        (syntheticAdded > 0
          ? ` Includes ${syntheticAdded} pre-resolved SF2e class feature(s).`
          : ` PF2e/SF2e ancestry/heritage/background pre-fill via prefillGrantingRules; SF2e classes use the sf2e-grant-resolver path when present.`));
      // keepId:true only when we actually pre-wired IDs. For the
      // legacy path (no synthetics) leave Foundry free to assign
      // fresh ones to avoid colliding with anything weirdly preset
      // upstream.
      const batchOpts = syntheticAdded > 0 ? { keepId: true } : {};
      await this._createItemsBatch(actor, grantBearing, batchOpts);

      // Phase 2: detect auto-grants. With v0.6.9's preselect approach
      // SF2e's GrantItem rules now DO fire (with our preselected choices)
      // so genuine auto-grants WILL appear in the diff. The dedup logic
      // below catches those and drops HLO's duplicate copy in favor of
      // the system-granted version (which carries proper grantedBy
      // linkage). This restores the behavior that v0.6.8 disabled.
      if (suppressGrants) {
        regular = this._dedupAgainstAutoGrants(actor, idsBeforeAnyEmbed, regular);
      }
    }

    // Embed spellcasting entries before the spells that reference them,
    // with keepId so the _id the builder assigned (and that each spell's
    // system.location.value points at) survives. Spells stay in `regular`
    // and keep their location.value through the _id strip below; the
    // post-embed finalizer re-affirms anchors and wires prepared slots.
    if (spellEntries.length > 0) {
      await this._createItemsBatch(actor, spellEntries, { keepId: true });
      this._pushLog("info",
        `Created ${spellEntries.length} spellcasting entr${spellEntries.length === 1 ? "y" : "ies"} for the actor's spells.`);
    }

    if (regular.length > 0) {
      // v0.7.1 (Bug 3 of v0.7.1 slice): strip _id from every regular
      // item before embed. Background: doc.toObject() on a compendium
      // pull preserves the compendium document's _id (e.g. Force
      // Barrage spell carries _id "gKKqvLohtrSJj3BM" verbatim). PF2e's
      // ActorPF2e.createDocuments override (pf2e.mjs line 50098-50173)
      // does randomize _id when operation.keepId is false, BUT line
      // 50146 flips operation.keepId = true the moment any item in
      // the batch carries grants -- and on a PFS wizard import, both
      // the Wizard class (auto-grants Hand of the Apprentice and the
      // arcane school's spells) and many other granters are present.
      // The flip applies to the ENTIRE source array, so spells whose
      // compendium _id collides with any item already on the actor
      // (most commonly an auto-granted spell from the prior phase, or
      // a survivor of a previous import that lacked our module flag)
      // is rejected by the server backend with "The _id [...] already
      // exists within the parent collection" (server-backend.mjs).
      //
      // The Berial Jeggare (PFS) re-import log captured 18 such
      // collisions, all on spells that the Wizard class grant chain
      // had already placed using the same compendium _id our pipeline
      // emits. Stripping _id here forces Foundry to assign fresh ones
      // regardless of how PF2e's createDocuments flips keepId. Grant-
      // bearing items in the earlier phase are untouched because they
      // legitimately need their pre-wired _ids for the grant graph.
      for (const item of regular) {
        delete item._id;
      }
      await this._createItemsBatch(actor, regular, {});
      if (suppressGrants) {
        await this._dedupAfterFullEmbed(actor);
      }
    }

    if (spellEntries.length > 0) {
      await this._finalizeSpellcasting(actor);
    }
  }

  /**
   * Post-embed spellcasting finalizer. Spells embed with fresh _ids, so
   * prepared slots (which reference those _ids) can only be wired now.
   * For every entry we created: re-affirm each anchored spell's location
   * (self-healing if Foundry reassigned the entry _id), finish the
   * proficiency rank from the live actor level, build prepared slots, and
   * seed the focus pool.
   */
  async _finalizeSpellcasting(actor) {
    const entries = actor.items.filter(
      (i) => i.type === "spellcastingEntry" && getEntryPlan(i));
    if (entries.length === 0) return;
    const actorLevel = Number(actor.system?.details?.level?.value ?? actor.level ?? 1) || 1;
    let focusTotal = 0;

    for (const entry of entries) {
      const plan = getEntryPlan(entry);
      if (!plan) continue;
      const idBySlug = new Map();
      const spellUpdates = [];
      let anchorFixes = 0;
      for (const it of actor.items) {
        if (it.type !== "spell") continue;
        if (!this._spellBelongsToEntry(it, plan, entries)) continue;
        const slug = it.system?.slug ?? null;
        if (slug) idBySlug.set(slug, it.id);
        if (it.system?.location?.value !== entry.id) {
          spellUpdates.push({ _id: it.id, "system.location.value": entry.id });
          anchorFixes += 1;
        }
      }
      if (spellUpdates.length > 0) {
        await actor.updateEmbeddedDocuments("Item", spellUpdates);
      }

      // PF2e proficiency bonus = level + 2*rank, so rank = (bonus-level)/2.
      let profRank = 1;
      if (plan.profBonus > 0) {
        profRank = Math.min(4, Math.max(1, Math.round((plan.profBonus - actorLevel) / 2)));
      }
      const entryUpdate = { _id: entry.id, "system.proficiency.value": profRank };
      if (plan.kind === "prepared") {
        entryUpdate["system.slots"] = buildPreparedSlots(plan, idBySlug);
      }
      await actor.updateEmbeddedDocuments("Item", [entryUpdate]);

      if (plan.kind === "focus") focusTotal += Number(plan.focusCount ?? idBySlug.size) || 0;
      this._pushDebug(
        `Finalized ${plan.kind} entry "${entry.name}": ${idBySlug.size} spell(s), ` +
        `proficiency rank ${profRank}${anchorFixes ? `, repaired ${anchorFixes} anchor(s)` : ""}.`);
    }

    if (focusTotal > 0) {
      const cap = Math.min(3, focusTotal);
      await actor.update({ "system.resources.focus.value": cap, "system.resources.focus.max": cap });
      this._pushLog("info", `Set focus pool to ${cap} point(s).`);
    }
    this._pushLog("info",
      `Spellcasting finalized: ${entries.length} entr${entries.length === 1 ? "y" : "ies"} wired; spells now render on the Spells tab.`);
  }

  /**
   * Decide whether a spell belongs to a given entry plan. Focus spells
   * (focus trait) bind to a focus entry; everything else binds to the
   * prepared entry. With one entry of each kind this is unambiguous.
   */
  _spellBelongsToEntry(spell, plan, allEntries) {
    const isFocus = (spell.system?.traits?.value ?? []).includes("focus");
    if (plan?.kind === "focus") return isFocus;
    if (isFocus && allEntries.some((e) => getEntryPlan(e)?.kind === "focus")) return false;
    return true;
  }

  /**
   * Walk the actor's items and identify any new ones that appeared
   * during the grant-bearing embed phase but are NOT our imports.
   * Then filter the pending HLO list to drop any item whose (type,
   * slug) matches an auto-granted item. Returns the filtered list.
   *
   * Why prefer the auto-grant on conflict: the auto-granted item
   * carries flags.pf2e.grantedBy.id pointing at its parent (the
   * Class / Ancestry / etc), so SF2e's grant graph stays consistent.
   * If we deleted the auto-grant and kept HLO's version (which has
   * no grantedBy), the parent would think its grant slot is unfilled
   * and the next "level up" or "rebuild" action in the sheet would
   * re-grant it, producing the same duplicate problem in reverse.
   */
  _dedupAgainstAutoGrants(actor, idsBefore, pendingItems) {
    // SF2e's grant relationship lives on the GRANTER, not the
    // grantee: parent items carry `flags.sf2e.itemGrants[choiceKey]
    // = { id, onDelete }`. The grantee has no back-reference.
    // Confirmed by inspecting fvtt-actor-bhelthal-operative-lvl1
    // and -lvl5 export fixtures (data/test-fixtures/): items with
    // flags.pf2e.grantedBy = 0 across both, but lvl5's Operative's
    // Specialization carries flags.sf2e.itemGrants.striker pointing
    // at the Striker feat's _id.
    //
    // So auto-grant detection walks all items, collects every
    // itemGrants id (both sf2e and pf2e namespaces for safety
    // across system versions), and treats items in that set as
    // auto-granted. Backstop also accepts the legacy
    // flags.pf2e.grantedBy marker in case some content still
    // emits it.
    const grantedIds = new Set();
    for (const item of actor.items.contents) {
      const sf2eGrants = item.flags?.sf2e?.itemGrants;
      if (sf2eGrants && typeof sf2eGrants === "object") {
        for (const k of Object.keys(sf2eGrants)) {
          const id = sf2eGrants[k]?.id;
          if (id) grantedIds.add(id);
        }
      }
      const pf2eGrants = item.flags?.pf2e?.itemGrants;
      if (pf2eGrants && typeof pf2eGrants === "object") {
        for (const k of Object.keys(pf2eGrants)) {
          const id = pf2eGrants[k]?.id;
          if (id) grantedIds.add(id);
        }
      }
    }
    const autoGranted = [];
    for (const item of actor.items.contents) {
      if (idsBefore.has(item.id)) continue;
      if (item.getFlag(MODULE_ID, "importedFrom") || item.getFlag(MODULE_ID, "hlo")) continue;
      const isGranted = grantedIds.has(item.id) || !!item.flags?.pf2e?.grantedBy;
      if (!isGranted) continue;
      autoGranted.push(item);
    }
    if (autoGranted.length === 0) {
      this._pushDebug("Auto-grant detection: no system-granted items appeared during grant-bearing embed.");
      return pendingItems;
    }
    this._pushLog("info",
      `Detected ${autoGranted.length} auto-granted item(s) from grant-bearing embed: ` +
      `${autoGranted.map((i) => `${i.name} (${i.type})`).join(", ")}.`);
    const grantedKeys = new Set();
    for (const it of autoGranted) {
      const slug = it.system?.slug ?? slugifyName(it.name);
      grantedKeys.add(`${it.type}:${slug}`);
    }
    const survivors = [];
    let dropped = 0;
    for (const it of pendingItems) {
      const slug = it.system?.slug ?? slugifyName(it.name);
      const key = `${it.type}:${slug}`;
      if (grantedKeys.has(key)) {
        this._pushLog("info",
          `  Deduplicating HLO item "${it.name}" (${it.type}): already auto-granted by an earlier-phase item; preserving the system-granted version with its grant-chain link.`);
        dropped += 1;
        continue;
      }
      survivors.push(it);
    }
    if (dropped > 0) {
      this._pushLog("info", `Dedup: dropped ${dropped} HLO item(s) that the system already granted; ${survivors.length} item(s) remain to embed.`);
    }
    return survivors;
  }

  // Second-pass dedup after phase 3: catches grants fired by phase-3 items (e.g. Munitions Crafter -> Alchemical Crafting) and deletes the HLO copy in favor of the system-granted one with the grant-chain link.
  async _dedupAfterFullEmbed(actor) {
    const grantedIds = new Set();
    for (const item of actor.items.contents) {
      const sf2eGrants = item.flags?.sf2e?.itemGrants;
      if (sf2eGrants && typeof sf2eGrants === "object") {
        for (const k of Object.keys(sf2eGrants)) {
          const id = sf2eGrants[k]?.id;
          if (id) grantedIds.add(id);
        }
      }
      const pf2eGrants = item.flags?.pf2e?.itemGrants;
      if (pf2eGrants && typeof pf2eGrants === "object") {
        for (const k of Object.keys(pf2eGrants)) {
          const id = pf2eGrants[k]?.id;
          if (id) grantedIds.add(id);
        }
      }
    }

    const byKey = new Map();
    for (const item of actor.items.contents) {
      const slug = item.system?.slug ?? slugifyName(item.name);
      const key = `${item.type}:${slug}`;
      if (!byKey.has(key)) byKey.set(key, []);
      byKey.get(key).push(item);
    }

    const toDelete = [];
    for (const items of byKey.values()) {
      if (items.length < 2) continue;
      const systemGranted = items.find((it) => grantedIds.has(it.id) || !!it.flags?.pf2e?.grantedBy);
      if (!systemGranted) continue;
      for (const it of items) {
        if (it.id === systemGranted.id) continue;
        const isOurs = it.getFlag(MODULE_ID, "importedFrom") || it.getFlag(MODULE_ID, "hlo");
        if (!isOurs) continue;
        toDelete.push(it.id);
        this._pushLog("info",
          `  Post-embed dedup: deleting HLO copy of "${it.name}" (${it.type}); the system-granted version with the grant-chain link survives.`);
      }
    }

    if (toDelete.length > 0) {
      await actor.deleteEmbeddedDocuments("Item", toDelete);
      this._pushLog("info", `Post-embed dedup: removed ${toDelete.length} duplicate item(s) that the system also granted.`);
    } else {
      this._pushDebug("Post-embed dedup: no duplicates found.");
    }
  }

  /**
   * Inner helper that does the try-bulk-then-per-item dance for a single
   * batch of items with a given options bag. Pulled out so the segmented
   * embed in _createItemsResilient can use the same retry logic for both
   * the grant-bearing (noHook:true) and regular (full-hook) batches.
   */
  async _createItemsBatch(actor, items, opts) {
    if (!Array.isArray(items) || items.length === 0) return;
    const tag = opts?.noHook ? " (noHook)" : "";
    try {
      await actor.createEmbeddedDocuments("Item", items, opts);
      this._pushDebug(`Bulk-created ${items.length} item(s)${tag}.`);
      return;
    } catch (bulkErr) {
      this._pushLog("warn",
        `Bulk item creation${tag} failed (${bulkErr?.message ?? bulkErr}). ` +
        `Falling back to per-item creation so failures do not block the rest.`);
      if (bulkErr?.stack) {
        this._pushDebug(`Bulk-create stack: ${bulkErr.stack.split("\n").slice(0, 4).join(" | ")}`);
      }
    }
    let succeeded = 0;
    const failures = [];
    for (const itemData of items) {
      try {
        await actor.createEmbeddedDocuments("Item", [itemData], opts);
        succeeded += 1;
      } catch (itemErr) {
        failures.push({
          name: itemData.name ?? "(unnamed)",
          type: itemData.type ?? "(unknown)",
          message: itemErr?.message ?? String(itemErr),
        });
      }
    }
    this._pushLog("info",
      `Per-item creation${tag}: ${succeeded} of ${items.length} item(s) added; ${failures.length} skipped.`);
    for (const f of failures) {
      this._pushLog("warn", `  Skipped item "${f.name}" (${f.type}): ${f.message}. Add manually if needed.`);
    }
  }
}

// Compsets whose normalized items are expected to resolve against a
// Foundry compendium. Used by the per-item match-debug log and the
// end-of-actor unmatched-modal to decide which misses get surfaced to
// the user. A compset that resolves to a compendium item but is NOT
// listed here will silently disappear when the matcher returns null:
// no warn log, no modal entry, no actor item. That is the v0.7.0
// "silent drop" bug pattern.
//
// v0.7.1 (pass 3): added the four v0.7.0-introduced compsets
// (MagicItem, CustomArmor, Wand, GearItem) so their misses are now
// surfaced. Bhelroth EC's 6 dropped magic items (Boots of speed,
// Carved Jade Opium Pipe, Reflection of Life/Light/Stone/Water) and
// Berial PFS's Wand of cozy cabin were all vanishing here because
// the matcher returned null for them and the per-item debug log +
// unmatched modal both gated on COMPENDIUM_COMPSETS.has(compset),
// which excluded the four new compsets. FocSpell also belongs in
// this set (it routes to spells-srd via the Spell handler) so focus
// spell misses get the same treatment.
const COMPENDIUM_COMPSETS = new Set([
  "Ancestry", "Heritage", "Class", "Deity", "Background",
  "Feat", "Action", "Ability", "Spell", "FocSpell",
  "Weapon", "NaturalWep", "Armor", "GearBasic",
  "Ammunition", "Upgrade", "Augmentation",
  // v0.7.0 compsets that route to equipment / consumables / etc.
  // packs. Without these, misses produce no warn log, no modal
  // entry, and the item silently disappears from the actor.
  "MagicItem", "CustomArmor", "Wand", "GearItem",
]);

/**
 * Always-on scaffold for the SF2e/PF2e character system data the
 * prepare pipeline assumes is present. Returns a NEW system object
 * with our overrides layered on top of the scaffold defaults; never
 * clobbers existing keys (mergeObject overlay), so any real values
 * the builder produced win.
 *
 * Why always-on instead of conditional: previous revisions only
 * scaffolded when the existing actor was missing a field, on the
 * theory that touching present fields would clobber them. In
 * practice Foundry's deep-merge during update() can silently drop
 * nested fields that aren't explicitly included in our overrides
 * (especially when the parent path is replaced wholesale by an
 * earlier step). The safer default is to always include the
 * scaffold; the merge order below ensures real data still wins.
 */
function scaffoldSystemForCharacter(systemData) {
  // Sourced from two inputs:
  //   1. v0.5.7-v0.5.8 crash signatures naming missing fields
  //      (AncestryPF2e wanted system.traits.size, ClassPF2e wanted
  //      system.details.class, DeityPF2e wanted details.deities.
  //      primary, HeritagePF2e wanted details.heritage, FeatPF2e
  //      wanted build.languages.value + item.flags.pf2e.grantedBy).
  //   2. v0.6.3 schema audit against fvtt-Actor-bhelthal-operative-
  //      lvl1 and -lvl5 export fixtures showed:
  //        - details.languages uses { value: [...], details: "" },
  //          NOT { value, custom } as previous scaffold assumed.
  //        - details.keyability.value (str/dex/etc) drives derived
  //          attack/damage modifiers; SF2e auto-derives nothing if
  //          this is absent.
  //        - details.alliance is "party" by default for PCs.
  //        - details.xp has min/max in addition to value.
  //        - System has no top-level traits.languages; languages
  //          live only under details and build.
  //      The scaffold below now matches the observed export shape.
  const scaffold = {
    build: {
      attributes: { boosts: { 1: [], 5: [], 10: [], 15: [], 20: [] }, keyOptions: [] },
      languages: { value: [], granted: [], max: 0 },
    },
    traits: {
      value: [],
      size: { value: "med" },
      senses: [],
    },
    details: {
      languages: { value: [], details: "" },
      class: { value: null, trait: null },
      ancestry: { value: null, trait: null },
      heritage: { value: null, trait: null },
      background: { value: null, trait: null },
      deities: {
        primary: { value: null },
        secondary: { value: null },
        domains: { primary: [], secondary: [] },
      },
      keyability: { value: "str" },
      level: { value: 1 },
      xp: { value: 0, min: 0, max: 1000 },
      alliance: "party",
    },
    proficiencies: {
      spellcasting: { rank: 0 },
      classDC: { rank: 0 },
    },
    perception: { rank: 0, senses: [] },
    attributes: {
      hp: { value: 0, max: 0, temp: 0 },
      speed: { value: 25, otherSpeeds: [] },
      ac: { value: 10 },
    },
  };
  // mergeObject(target, source) overlays source ONTO target. Putting
  // the real systemData second means real values win; the scaffold
  // only fills holes.
  return foundry.utils.mergeObject(scaffold, systemData ?? {}, {
    inplace: false,
    insertKeys: true,
    insertValues: true,
    overwrite: true,
  });
}

/**
 * Walk known orphan-prone roots in actor _source.system and return the
 * paths where a scalar (number / string / boolean / null) is parked at a
 * location where SF2e/PF2e expects an object. These come from prior
 * AELikeRuleElement writes against undefined paths: setProperty assigns
 * the raw newValue (often a number) at the parent, then the NEXT
 * import's setProperty walk on a child path throws "Cannot create
 * property 'X' on number 'N'" because the parent is a primitive.
 *
 * Returns dotted paths RELATIVE to system (e.g. "proficiencies.classDC")
 * so the caller can build a sanitize patch like { system: { proficiencies:
 * { classDC: {} } } }.
 *
 * Roots scanned: attributes, proficiencies, skills, saves, perception,
 * build, traits, resources. These cover every region where SF2e AELike
 * paths terminate at depth 2-3 per a manual audit of the system source.
 * `details` is deliberately omitted because it carries legitimate
 * depth-1 strings (alliance, publication). The scan is shallow at each
 * root (one level deep is enough since AELikeRuleElement writes are
 * typically X.Y.value or X.Y.rank, both tripping at the X.Y
 * intermediate).
 */
function sanitizeSystemOrphans(sourceSystem) {
  if (!sourceSystem || typeof sourceSystem !== "object") return [];
  // Roots where SF2e/PF2e's prepareActorData and AELike rules write
  // into nested object shapes (X.Y.{value, rank, max, mod}). A bare
  // number / boolean parked at depth 1 here is the orphan signature
  // that trips the next setProperty walk.
  //
  // String values are deliberately NOT flagged: several legitimate
  // depth-1 strings exist on a clean character (details.alliance =
  // "party", details.languages.details = "", details.publication =
  // ...). Numbers and booleans cannot legitimately live at depth 1
  // under any of the roots below per the v0.6.3 fixture audit
  // (data/test-fixtures/fvtt-actor-bhelthal-operative-lvl5.json
  // shows every depth-1 child is either an object, an array, or
  // null), so flagging them is a precise signal that we are looking
  // at orphan AELike leftovers.
  const ROOTS = [
    "attributes", "proficiencies", "skills", "saves", "perception",
    "build", "traits", "resources",
  ];
  const orphans = [];
  for (const root of ROOTS) {
    const node = sourceSystem[root];
    if (node == null || typeof node !== "object" || Array.isArray(node)) continue;
    for (const [k, v] of Object.entries(node)) {
      if (v == null) continue;
      const t = typeof v;
      if (t === "number" || t === "boolean") {
        orphans.push(`${root}.${k}`);
      }
    }
  }
  return orphans;
}

/**
 * Initialize flags.pf2e on every item before embed. Without this,
 * Feat (and several other) prepareActorData methods crash with
 * "Cannot read properties of undefined (reading 'grantedBy')" because
 * they dot-chain into item.flags.pf2e.grantedBy.id. Compendium-pulled
 * items already have flags.pf2e from SF2e/PF2e's compendium build,
 * but pass-through items (lores emitted by the builder, custom items)
 * do not, and even compendium items can lose flags.pf2e if they were
 * manipulated upstream. Always-initialize is cheaper than guessing.
 */
function ensureItemFlags(items) {
  if (!Array.isArray(items)) return items;
  for (const it of items) {
    it.flags ??= {};
    it.flags.pf2e ??= {};
  }
  return items;
}

/**
 * v0.6.9 proper-fix replacement for v0.6.8's blanket suppression.
 *
 * On grant-bearing items (class/ancestry/heritage/deity/background),
 * walk system.rules and pre-fill ChoiceSet / GrantItem selections
 * from HLO's ground truth so SF2e/PF2e's grant pipeline can run
 * cleanly without showing a wizard prompt. This produces the same
 * grant chain (flags.sf2e.itemGrants on the granter, flags.sf2e.
 * grantedBy on the grantee) the system would build natively, which
 * level-up wizard reruns and re-import grant-cleanup both depend on.
 *
 * Two patterns are handled:
 *
 *   1. GrantItem with a chained ChoiceSet selected via the
 *      `{item|flags.system.rulesSelections.<flag>}` injection token.
 *      The GrantItem's `uuid` points to a feature; that feature
 *      carries a ChoiceSet with a matching `flag`. We set
 *      `preselectChoices = { [flag]: <UUID> }` on the GrantItem;
 *      SF2e propagates that into the granted item's ChoiceSet via
 *      #applyChoicePreselections (sf2e.mjs:48393).
 *
 *   2. Standalone ChoiceSet rule with a `flag` and no paired
 *      GrantItem-with-injection-token in front of it (e.g. a
 *      skill-trained pick on a Background, where the resulting
 *      selection is consumed by an ActiveEffectLike or similar
 *      rule rather than a GrantItem). Selection is written
 *      directly: `rule.selection = <UUID-or-value>`.
 *
 * If no HLO item matches a given slot, we fall back to v0.6.8's
 * `ignored: true` behavior so the user is not interrupted by a
 * wizard popup for choices HLO genuinely did not record. Every
 * decision (preselected / direct / fallback-ignored / no-match)
 * is logged at debug level via the supplied pushDebug callback so
 * the conversion log shows what was wired and what was skipped.
 *
 * Non-grant-bearing items (feats, spells, equipment) keep their
 * rule elements intact so legitimate effects (Toughness HP bonus,
 * spell tradition selection, weapon condition application) still
 * apply normally.
 *
 * @param {object} obj        Resolved item document about to be embedded.
 * @param {Array}  hloItems   ActorIR items list from parsePortfolio. Each
 *                            entry has {compset, name, slug, traitIds, ...}.
 * @param {Function} pushDebug Optional callback for per-decision debug log
 *                             lines: (msg: string) => void. Defaults to a
 *                             no-op so unit-test callers can omit it.
 */
function prefillGrantingRules(obj, hloItems = [], pushDebug = () => {}) {
  if (!obj?.type || !obj?.system?.rules) return;
  const GRANT_BEARING_TYPES = new Set(["class", "ancestry", "heritage", "deity", "background"]);
  if (!GRANT_BEARING_TYPES.has(obj.type)) return;
  if (!Array.isArray(obj.system.rules)) return;

  const rules = obj.system.rules;
  const itemName = obj.name ?? "(unnamed)";

  // First pass: index ChoiceSet rules by flag so the GrantItem pass below
  // can recognize the "chained-via-injection-token" pattern.
  const choiceSetByFlag = new Map();
  for (const rule of rules) {
    if (rule?.key === "ChoiceSet" && typeof rule.flag === "string" && rule.flag.length > 0) {
      choiceSetByFlag.set(rule.flag, rule);
    }
  }

  // Track which ChoiceSet rules were satisfied via a GrantItem preselect
  // so the second pass does not redundantly mark them ignored.
  const handledChoiceFlags = new Set();

  // Pass 2: GrantItem rules. Two sub-cases:
  //   (a) uuid is a concrete compendium UUID -> the granted feature may
  //       itself carry a ChoiceSet with this rule's `flag`. We can pre-
  //       seed that downstream ChoiceSet via preselectChoices.
  //   (b) uuid is an injection token like {item|flags.system.rulesSelections.X}
  //       -> the actual UUID comes from a sibling ChoiceSet on THIS item
  //       (the one with flag X). We set selection on that ChoiceSet
  //       directly (pass 3 handles standalone ChoiceSets the same way).
  for (const rule of rules) {
    if (rule?.key !== "GrantItem") continue;
    const flag = typeof rule.flag === "string" ? rule.flag : null;
    const uuid = typeof rule.uuid === "string" ? rule.uuid : "";
    const isInjection = uuid.startsWith("{") && uuid.endsWith("}");

    if (isInjection) {
      // Look for the sibling ChoiceSet that produces the value. The
      // injection token shape is {item|flags.system.rulesSelections.<flag>},
      // and the ChoiceSet flag matches the trailing segment.
      const match = uuid.match(/rulesSelections\.([A-Za-z0-9_-]+)/);
      const sourceFlag = match?.[1] ?? null;
      const choiceSet = sourceFlag ? choiceSetByFlag.get(sourceFlag) : null;
      if (!choiceSet) {
        // Cannot resolve where the value should come from; leave rule alone
        // so SF2e can prompt if it has any usable default. This is rare.
        pushDebug(`Preselect: GrantItem on "${itemName}" uses injection token ${uuid} but no sibling ChoiceSet with flag "${sourceFlag}" found; leaving as-is.`);
        continue;
      }
      const picked = pickHloItemForChoiceSet(choiceSet, hloItems);
      if (picked) {
        choiceSet.selection = picked.uuid;
        handledChoiceFlags.add(sourceFlag);
        pushDebug(`Preselected ${itemName}.${sourceFlag} -> ${picked.pack}/${picked.slug} (from HLO "${picked.hloName}")`);
      } else {
        choiceSet.ignored = true;
        choiceSet.allowNoSelection = true;
        rule.ignored = true;
        handledChoiceFlags.add(sourceFlag);
        pushDebug(`Preselect: no HLO match for ${itemName}.${sourceFlag}; suppressing ChoiceSet + chained GrantItem (fallback).`);
      }
      continue;
    }

    // Concrete-UUID GrantItem. If it has a `flag`, try to preselect the
    // downstream ChoiceSet on the granted item. We cannot inspect the
    // granted item's rules here (it has not been fetched yet) so we rely
    // on the `flag` being the link: SF2e will only apply our preselect
    // entry to a downstream ChoiceSet whose flag matches.
    if (!flag) continue;
    const picked = pickHloItemByGrantContext(rule, hloItems);
    if (picked) {
      rule.preselectChoices = { ...(rule.preselectChoices ?? {}), [flag]: picked.uuid };
      pushDebug(`Preselected ${itemName} GrantItem(${flag}) preselectChoices.${flag} -> ${picked.pack}/${picked.slug} (from HLO "${picked.hloName}")`);
    }
  }

  // Pass 3: standalone ChoiceSet rules (not paired with a GrantItem via
  // injection token). Pre-fill selection directly so the rule's preCreate
  // does not prompt.
  for (const rule of rules) {
    if (rule?.key !== "ChoiceSet") continue;
    if (typeof rule.flag !== "string" || rule.flag.length === 0) continue;
    if (handledChoiceFlags.has(rule.flag)) continue;
    if (rule.selection != null && rule.selection !== "") continue;

    const picked = pickHloItemForChoiceSet(rule, hloItems);
    if (picked) {
      rule.selection = picked.uuid;
      pushDebug(`Selected ${itemName}.${rule.flag} -> ${picked.pack}/${picked.slug} (from HLO "${picked.hloName}")`);
    } else {
      rule.ignored = true;
      rule.allowNoSelection = true;
      pushDebug(`Preselect: no HLO match for standalone ChoiceSet ${itemName}.${rule.flag}; ignoring (fallback).`);
    }
  }
}

/**
 * Pick the HLO item that should satisfy a given ChoiceSet rule. Uses the
 * rule's `choices.filter` predicates to narrow the candidate pool (e.g.
 * "item:tag:operative-specialization", "item:category:skill", "item:level:1"),
 * then runs each candidate through `lookupCanonical` to resolve a UUID.
 *
 * Returns null if nothing matches. Returns the FIRST match deterministically
 * so the same HLO data always picks the same compendium entry.
 */
export function pickHloItemForChoiceSet(choiceSet, hloItems) {
  if (!Array.isArray(hloItems) || hloItems.length === 0) return null;
  const filters = collectChoiceFilters(choiceSet);
  for (const hlo of hloItems) {
    if (!hloMatchesFilters(hlo, filters)) continue;
    const canonical = lookupCanonical(hlo);
    if (!canonical) continue;
    const pack = game?.packs?.get(canonical.fullPack);
    const uuid = pack?.getUuid?.(canonical._id) ?? null;
    if (!uuid) continue;
    return {
      uuid,
      pack: canonical.fullPack,
      slug: canonical.slug,
      hloName: hlo.name ?? hlo.slug ?? "(unnamed)",
    };
  }
  return null;
}

/**
 * Async sibling of pickHloItemForChoiceSet. Same job, but predicates that
 * inspect Foundry-side document tags (e.g. "item:tag:operative-specialization",
 * which lives at system.traits.otherTags on the compendium doc and is NOT
 * present on the raw HLO item) get re-checked against the matched canonical
 * compendium document after a fromUuid fetch.
 *
 * Per-candidate flow:
 *   1. HLO-side filter pass (no I/O); doc-side predicates are deferred.
 *   2. lookupCanonical for a candidate; skip on miss.
 *   3. fromUuid fetch the doc; reject if any deferred Foundry-side predicate
 *      fails against the doc's actual system.traits.otherTags/value/category.
 *   4. First survivor wins.
 *
 * Used by the SF2e grant resolver where the v0.6.11 wizard silencer would
 * otherwise have to guess (and v0.6.11 logs showed it picking a wrong
 * "Acrobatic Performer" branch when the upstream ChoiceSet was dropped).
 */
export async function pickHloItemForChoiceSetAsync(choiceSet, hloItems) {
  if (!Array.isArray(hloItems) || hloItems.length === 0) return null;
  const filters = collectChoiceFilters(choiceSet);
  for (const hlo of hloItems) {
    if (!hloMatchesFilters(hlo, filters, { skipDocSide: true })) continue;
    const canonical = lookupCanonical(hlo);
    if (!canonical) continue;
    const pack = game?.packs?.get(canonical.fullPack);
    const uuid = pack?.getUuid?.(canonical._id) ?? null;
    if (!uuid) continue;
    let doc = null;
    try {
      doc = await fromUuid(uuid);
    } catch (_err) {
      doc = null;
    }
    if (doc && !docMatchesFoundrySideFilters(doc, filters)) continue;
    return {
      uuid,
      pack: canonical.fullPack,
      slug: canonical.slug,
      hloName: hlo.name ?? hlo.slug ?? "(unnamed)",
    };
  }
  return null;
}

/**
 * Pick an HLO item that should satisfy a concrete-UUID GrantItem rule.
 * Without a `choices` filter on the rule itself there is no precise way
 * to narrow the pool; we use the GrantItem's `flag` slug as a soft hint
 * against HLO item slugs/names. Returns the first hit or null.
 *
 * In practice this branch fires for ancestry/heritage GrantItems that
 * grant a fixed feature (e.g. "Low-Light Vision"); the chained ChoiceSet
 * pattern is the more common preselect target and is handled separately.
 */
function pickHloItemByGrantContext(rule, hloItems) {
  if (!Array.isArray(hloItems) || hloItems.length === 0) return null;
  const flag = typeof rule.flag === "string" ? rule.flag.toLowerCase() : null;
  if (!flag) return null;
  for (const hlo of hloItems) {
    const hloSlug = (hlo.slug ?? "").toLowerCase();
    const hloName = (hlo.name ?? "").toLowerCase().replace(/[^a-z0-9]+/g, "");
    const flagFlat = flag.replace(/[^a-z0-9]+/g, "");
    if (hloSlug.includes(flagFlat) || hloName.includes(flagFlat) || flagFlat.includes(hloName)) {
      const canonical = lookupCanonical(hlo);
      if (!canonical) continue;
      const pack = game?.packs?.get(canonical.fullPack);
      const uuid = pack?.getUuid?.(canonical._id) ?? null;
      if (!uuid) continue;
      return {
        uuid,
        pack: canonical.fullPack,
        slug: canonical.slug,
        hloName: hlo.name ?? hlo.slug ?? "(unnamed)",
      };
    }
  }
  return null;
}

/**
 * Extract the `choices.filter` predicates from a ChoiceSet rule into a
 * flat array of `"namespace:value"` strings that pickHloItemForChoiceSet
 * uses to narrow HLO candidates. Returns [] if the rule does not declare
 * filters (every HLO item is a candidate; matcher coverage will winnow it).
 */
function collectChoiceFilters(choiceSet) {
  const filters = [];
  const choices = choiceSet?.choices;
  if (!choices || typeof choices !== "object") return filters;
  const raw = choices.filter;
  if (Array.isArray(raw)) {
    for (const p of raw) {
      if (typeof p === "string") filters.push(p);
    }
  }
  if (typeof choices.itemType === "string") filters.push(`itemType:${choices.itemType}`);
  return filters;
}

/**
 * Test whether an HLO item satisfies the given ChoiceSet filter set.
 * Supports the predicate shapes that show up in PF2e/SF2e ChoiceSet
 * filters in practice (verified against the Operative test fixtures):
 *
 *   "item:tag:<slug>"       -> HLO item.traitIds contains <slug>
 *   "item:category:<name>"  -> HLO item.compset matches one of:
 *                              "skill" -> compset Feat with skill trait,
 *                              "operative-specialization" -> traitIds,
 *                              etc.
 *   "item:level:<N>"        -> HLO item.level === N (when level known)
 *   "itemType:feat"         -> compset is Feat / Ability / Action
 *
 * Unknown predicates are treated as "no opinion" (do not exclude). This
 * is intentional: the matcher catches false positives downstream when
 * lookupCanonical returns null for items that do not actually live in
 * the compendium pack the GrantItem would draw from.
 */
function hloMatchesFilters(hlo, filters, opts = {}) {
  if (!Array.isArray(filters) || filters.length === 0) return true;
  const skipDocSide = opts && opts.skipDocSide === true;
  for (const f of filters) {
    if (typeof f !== "string") continue;
    if (f === "itemType:feat") {
      if (!["Feat", "Ability", "Action"].includes(hlo.compset)) return false;
      continue;
    }
    if (f.startsWith("item:tag:")) {
      // "item:tag:<slug>" targets system.traits.otherTags on the FOUNDRY
      // compendium doc, not HLO's traitIds. HLO traitIds carry the visible
      // traits (e.g. "operative") but never the slot-binding tags (e.g.
      // "operative-specialization") that subclass-style ChoiceSet filters
      // key on. When the async picker is in play we defer this check to
      // docMatchesFoundrySideFilters; here we ALSO accept a tag hit
      // against HLO traitIds (some indie traits do leak through) so the
      // sync picker keeps the same behavior as before.
      if (skipDocSide) continue;
      const tag = f.slice("item:tag:".length);
      const traits = Array.isArray(hlo.traitIds) ? hlo.traitIds : [];
      if (!traits.some((t) => String(t).toLowerCase() === tag.toLowerCase())) return false;
      continue;
    }
    if (f.startsWith("item:category:")) {
      const cat = f.slice("item:category:".length);
      if (cat === "skill") {
        const traits = Array.isArray(hlo.traitIds) ? hlo.traitIds : [];
        const hasSkillTrait = traits.some((t) => String(t).toLowerCase() === "skill");
        if (!hasSkillTrait && hlo.compset !== "Feat") return false;
      }
      continue;
    }
    if (f.startsWith("item:level:")) {
      const lvl = Number(f.slice("item:level:".length));
      if (Number.isFinite(lvl) && Number.isFinite(hlo.level) && hlo.level !== lvl) return false;
      continue;
    }
    // Unknown predicate: no opinion.
  }
  return true;
}

/**
 * Re-run the subset of ChoiceSet predicates that target FOUNDRY-side data
 * (tags, value-traits, category) against a fetched compendium document.
 * Used by pickHloItemForChoiceSetAsync to validate that an HLO -> canonical
 * match actually carries the slot-binding tag the ChoiceSet filter requires.
 *
 * Returns true if every doc-side predicate is satisfied (or if none are
 * present); false if any doc-side predicate is contradicted by the doc.
 * Non-doc-side predicates (itemType:*, item:level:*) are treated as already-
 * passed by the HLO-side filter and are ignored here.
 */
function docMatchesFoundrySideFilters(doc, filters) {
  if (!Array.isArray(filters) || filters.length === 0) return true;
  if (!doc) return true;
  const sys = doc.system ?? doc?._source?.system ?? {};
  const otherTags = Array.isArray(sys?.traits?.otherTags) ? sys.traits.otherTags : [];
  const traitValue = Array.isArray(sys?.traits?.value) ? sys.traits.value : [];
  const category = typeof sys?.category === "string" ? sys.category.toLowerCase() : null;
  const allTags = new Set([...otherTags, ...traitValue].map((t) => String(t).toLowerCase()));
  for (const f of filters) {
    if (typeof f !== "string") continue;
    if (f.startsWith("item:tag:")) {
      const tag = f.slice("item:tag:".length).toLowerCase();
      if (!allTags.has(tag)) return false;
      continue;
    }
    if (f.startsWith("item:category:")) {
      const cat = f.slice("item:category:".length).toLowerCase();
      // "category" in this predicate maps to system.category on feats
      // (e.g. "classfeature", "skill"). Doc-side check is authoritative:
      // if the doc declares a category, it must match.
      if (category && cat !== category) {
        // Heritage/ancestry filters sometimes use category:"skill" loosely
        // -- only reject when the doc's category is a hard mismatch.
        if (cat === "skill" || cat === "classfeature" || cat === "ancestryfeature") {
          return false;
        }
      }
      continue;
    }
    // itemType:*, item:level:*, unknown: defer to HLO-side / no opinion.
  }
  return true;
}

/**
 * v0.7.1 Rune Triad (pass 2). Apply the parser's `runes` envelope to
 * the resolved Foundry item's system.runes. Runs unconditionally on
 * weapon and armor types; non-weapon/armor items pass through
 * unchanged. Writes the same zeroed block for non-magic weapons that
 * PF2e's template already defaults to, so the call is safe even when
 * no runes were extracted (the empty propertyRunes list still
 * replaces system.runes.property with []).
 *
 * Mapping:
 *   weapon -> system.runes = {
 *               potency, striking, property: propertyRunes
 *             }
 *   armor  -> system.runes = {
 *               potency, resilient, property: propertyRunes
 *             }
 *   shield -> skipped (shields use a separate runes shape:
 *               { reinforcing }; v0.7.1 does not parse shield runes,
 *               leaving the compendium default in place).
 *   other  -> skipped.
 *
 * Note on slug form: propertyRunes from util-rune-parser are already
 * canonical PF2e camelCase slugs ("ghostTouch", "fireResistant",
 * "greaterReady"), per the PROPERTY_SLUG map in util-rune-parser.js.
 * No further normalization is needed here.
 */
function applyRunesToItem(obj, runes, pushDebug) {
  if (!obj || !runes) return;
  const type = obj.type;
  if (type !== "weapon" && type !== "armor") return;

  obj.system ??= {};
  // Preserve any non-runes structure already on the compendium item
  // (specific, grade, etc.) by merging instead of replacing.
  const existing = obj.system.runes ?? {};
  const potency       = runes.potency ?? 0;
  const propertyRunes = Array.isArray(runes.propertyRunes) ? runes.propertyRunes : [];

  if (type === "weapon") {
    obj.system.runes = {
      ...existing,
      potency,
      striking: runes.striking ?? 0,
      property: propertyRunes,
    };
  } else {
    // type === "armor"
    obj.system.runes = {
      ...existing,
      potency,
      // The armor parser stores tier as `resilient` (pass 2's
      // adaptRunesForArmor); the weapon parser stores tier as
      // `striking`. We accept either field defensively so a future
      // refactor of the IR shape does not silently zero out the armor
      // resilient tier.
      resilient: runes.resilient ?? runes.striking ?? 0,
      property: propertyRunes,
    };
  }

  if (typeof pushDebug === "function"
      && (potency > 0 || propertyRunes.length > 0
          || (runes.striking ?? 0) > 0 || (runes.resilient ?? 0) > 0)) {
    const tierField = type === "weapon" ? "striking" : "resilient";
    const tierValue = type === "weapon"
      ? (runes.striking ?? 0)
      : (runes.resilient ?? runes.striking ?? 0);
    pushDebug(
      `Applied runes to ${type} "${obj.name}": potency=${potency}, `
      + `${tierField}=${tierValue}, property=[${propertyRunes.join(", ")}]`,
    );
  }
}

async function resolveSkeletonForCreate(skeleton, attachmentPlan = [], hloItems = [], pushDebug = () => {}) {
  const resolvedItems = [];
  for (const ref of skeleton.items ?? []) {
    if (ref.type !== "compendium-reference") {
      // Already a real item document (e.g., lore items emitted by the
      // builder); pass through.
      resolvedItems.push(ref);
      continue;
    }
    const pack = game?.packs?.get(ref.pack);
    if (!pack) {
      logger.warn(`Pack ${ref.pack} not available; dropping reference to ${ref.name}.`);
      continue;
    }
    const idx = await pack.getIndex({ fields: ["system.slug"] });
    const entry = Array.from(idx).find((e) => (e.system?.slug ?? null) === ref.slug);
    if (!entry) {
      logger.warn(`No compendium hit for ${ref.pack}/${ref.slug} (${ref.name}); dropping.`);
      continue;
    }
    const doc = await pack.getDocument(entry._id);
    if (!doc) continue;
    const obj = doc.toObject();
    obj.flags ??= {};
    obj.flags[MODULE_ID] = {
      ...(ref.flags?.[MODULE_ID] ?? {}),
      importedFrom: { pack: ref.pack, slug: ref.slug },
      hlo: ref.hlo,
      strategy: ref.strategy,
      confidence: ref.confidence,
    };
    // v0.7.1 Rune Triad (pass 2): write the parsed runes onto
    // system.runes for weapon and armor items. See applyRunesToItem
    // for the field mapping and the rationale for unconditional
    // writes on non-runed items.
    applyRunesToItem(obj, ref.runes, pushDebug);
    // v0.6.9: pre-fill ChoiceSet / GrantItem selections on grant-bearing
    // items so SF2e/PF2e's grant pipeline runs without prompting. See the
    // long comment on prefillGrantingRules() for the full rationale.
    // Supersedes v0.6.8's blanket-suppression approach; falls back to
    // ignored:true only when HLO has no item to satisfy a given slot,
    // preserving the v0.6.8 no-wizard-popup guarantee.
    prefillGrantingRules(obj, hloItems, pushDebug);
    resolvedItems.push(obj);
  }
  // Wire ammo selection, drop redundant nested traits, tag upgrade
  // attachments. Mutates resolvedItems and returns a possibly-shorter list.
  const attached = applyAttachmentPlan(resolvedItems, attachmentPlan, MODULE_ID);
  // Defensive flag scaffolding. Some PF2e/SF2e system internals (notably
  // Class.getLinkedItems) dot-chain into `item.flags.pf2e.grantedBy.id`
  // when iterating actor.items. Compendium-pulled items already have
  // flags.pf2e populated by the system, but builder-emitted pass-through
  // items (lores, custom-built actions) only carry our module flag.
  // Initialize flags.pf2e to an empty object so any system-side filter
  // gets `undefined` instead of throwing on a missing intermediate key.
  for (const item of attached) {
    item.flags ??= {};
    item.flags.pf2e ??= {};
  }
  // v0.6.10: bind HLO feats to their proper class/skill/ancestry slot
  // via system.location + system.level.taken so they fill the sheet's
  // designated slots instead of cascading to "Bonus Feats." Per pass 5's
  // research: SF2e's FeatGroup.assignFeat (sf2e.mjs:38203) routes a feat
  // by its system.location matching a slot id like "class-1" or "skill-2",
  // built from the actor's class.classFeatLevels.value etc. Background-
  // granted skill feats use the background item's _id as the location.
  assignFeatLocations(attached, pushDebug);
  // Synthesize spellcasting entries and anchor spells. PF2e/SF2e filter
  // out any spell whose system.location.value does not match an entry on
  // the actor, so without this every imported spell is an orphan and the
  // Spells tab renders empty. The post-embed finalizer wires prepared
  // slots once the spells have real _ids.
  try {
    const sc = buildSpellcastingEntries(attached, hloItems, pushDebug);
    if (sc) pushDebug(`Spellcasting: ${sc.entries} entr(y/ies) built, ${sc.anchored} spell(s) anchored, ${sc.dropped} duplicate(s) dropped.`);
  } catch (err) {
    pushDebug(`Spellcasting build failed (${err?.message ?? err}); spells will embed unanchored.`);
  }
  return { ...skeleton, items: attached };
}

/**
 * v0.6.10 feat slotting (pass 5's research). Walk the resolved item
 * list, find every type:"feat" item, derive its target slot (class-N,
 * skill-N, ancestry-N, general-N, or background _id) from system.category
 * + HLO's reqLevelNet, and assign system.location + system.level.taken.
 * Feats with no available slot fall back to whatever default the system
 * assigns (typically "Bonus Feats" cascade, same as v0.6.9 behavior).
 */
function assignFeatLocations(items, pushDebug) {
  if (!Array.isArray(items) || items.length === 0) return;
  const classObj = items.find((i) => i.type === "class");
  const ancestryObj = items.find((i) => i.type === "ancestry");
  const backgroundObj = items.find((i) => i.type === "background");
  const slots = {
    class:    new Set(classObj?.system?.classFeatLevels?.value    ?? []),
    skill:    new Set(classObj?.system?.skillFeatLevels?.value    ?? []),
    general:  new Set(classObj?.system?.generalFeatLevels?.value  ?? []),
    ancestry: new Set(ancestryObj?.system?.ancestryFeatLevels?.value ?? [1, 5, 9, 13, 17]),
  };
  // Background skill slot needs a stable identifier. If the background
  // object has any items entries (skill grants), we use its _id as the
  // location. Foundry assigns _id at create time; resolvedItems pulled
  // via doc.toObject() carry the compendium _id which is what SF2e
  // expects in the location field, per fixture observation
  // (lvl5 fixture line 563-629).
  const backgroundId = backgroundObj?._id ?? null;
  const backgroundGrantsSkill = backgroundId
    && backgroundObj?.system?.items
    && Object.keys(backgroundObj.system.items).length > 0;
  let bgSkillUsed = false;
  let slotted = 0;
  let unslotted = 0;
  for (const item of items) {
    if (item.type !== "feat") continue;
    const cat = item.system?.category;
    if (!cat || cat === "classfeature" || cat === "ancestryfeature") {
      // Class/ancestry features are placed by the system's own grant
      // pipeline; we do not assign a slot for them.
      continue;
    }
    const hloLevel = item.flags?.[MODULE_ID]?.hlo?.reqLevelNet ?? 1;
    // First level-1 skill feat: prefer background slot if background
    // grants one. Matches SF2e's character-creation flow where the
    // background fills its own skill-feat slot.
    if (cat === "skill" && !bgSkillUsed && backgroundGrantsSkill && hloLevel === 1) {
      item.system.location = backgroundId;
      item.system.level = { ...(item.system.level ?? {}), taken: 1 };
      bgSkillUsed = true;
      slotted += 1;
      if (typeof pushDebug === "function") {
        pushDebug(`Slotted feat "${item.name}" -> background skill slot (${backgroundId})`);
      }
      continue;
    }
    const group = cat;
    if (!slots[group]?.has(hloLevel)) {
      unslotted += 1;
      if (typeof pushDebug === "function") {
        pushDebug(`No ${group} slot at level ${hloLevel} for feat "${item.name}"; cascading to Bonus Feats.`);
      }
      continue;
    }
    item.system.location = `${group}-${hloLevel}`;
    item.system.level = { ...(item.system.level ?? {}), taken: hloLevel };
    slotted += 1;
    if (typeof pushDebug === "function") {
      pushDebug(`Slotted feat "${item.name}" -> ${group}-${hloLevel}`);
    }
  }
  if (typeof pushDebug === "function" && (slotted > 0 || unslotted > 0)) {
    pushDebug(`assignFeatLocations: ${slotted} slotted, ${unslotted} cascaded to Bonus Feats.`);
  }
}

// ============================================================
// SECTION: Wizard silencer (v0.6.11)
// ============================================================
// The user clicks Import once and walks away. Any system-side
// dialog that pops up during the embed phase breaks that contract.
// v0.6.9's prefillGrantingRules wires up the parent-class rule
// elements before embed, but SF2e classes that load features via
// system.items + createGrantedItems (Operative, Mystic, anything
// that grants feats with their own internal ChoiceSets) can still
// open a PickAThingPrompt because the prompt comes from the
// GRANTED feature's preCreate, not from the class object we
// modified.
//
// The silencer is two layers of defense, installed only while a
// _runPipeline call is in flight:
//
//   Layer 1 (primary): render hook on "renderPickAThingPrompt"
//     and a generic backstop on "renderApplicationV2". When SF2e
//     opens a prompt, the hook fires synchronously after the DOM
//     is in place. We pick a choice (HLO-informed if possible,
//     otherwise the first option, NEVER cancel), write it into
//     app.selection, and call app.close(). The PickAThingPrompt's
//     _onClose hook (sf2e.mjs:47117) reads selection and resolves
//     its internal #resolve promise with that value, so the
//     awaiting ChoiceSetRuleElement.preCreate (sf2e.mjs:47253)
//     proceeds as if the user had picked normally.
//
//   Layer 2 (belt): once we have ever intercepted a PickAThingPrompt
//     instance, we monkey-patch its prototype's resolveSelection to
//     short-circuit before render. This catches calls that complete
//     synchronously (single-choice prompts that already auto-resolve
//     anyway) AND any prompt opened so fast the render hook hasn't
//     processed yet. The original method is restored on uninstall.
//
// Both layers log every silenced prompt to the conversion log so
// the user can audit what we picked on their behalf.

let _wizardSilencerState = null;

function installWizardSilencer({ pushLog, pushDebug, hloItems }) {
  if (_wizardSilencerState) {
    // Defensive: already installed (re-entrant call). Tear the old
    // one down first so we never leak hook IDs or prototype patches.
    uninstallWizardSilencer();
  }
  const safePushLog = typeof pushLog === "function" ? pushLog : () => {};
  const safePushDebug = typeof pushDebug === "function" ? pushDebug : () => {};
  const hloItemPool = Array.isArray(hloItems) ? hloItems : [];

  const state = {
    hookIds: [],
    patchedProto: null,
    patchedOriginal: null,
    silencedCount: 0,
    // WeakSet of prompt instances already silenced this run. Prevents
    // double-fires when both Layer 1 hooks (renderPickAThingPrompt +
    // renderApplicationV2) catch the same instance, or when Layer 2's
    // prototype patch fires for an instance Layer 1 already handled.
    // WeakSet is correct here because we only need identity checks and
    // we never want to keep prompt instances alive past their natural
    // GC, especially across many imports in one session.
    silencedInstances: new WeakSet(),
    pushLog: safePushLog,
    pushDebug: safePushDebug,
    hloItemPool,
    // v0.6.12: pre-resolved compendium UUIDs from the matcher. Updated
    // per-actor by setSilencerMatchedUuids() once matchAll completes,
    // so the silencer can prefer a prompt choice whose value/uuid IS
    // a UUID we already chose for that actor. Empty until the first
    // matchAll on the first actor lands.
    matchedUuids: new Set(),
  };

  const handleRender = (app /*, html, data */) => {
    if (!app) return;
    // Use duck-typing: anything with the resolveSelection shape and a
    // `choices` array is a PickAThingPrompt or a close-enough clone.
    // Checking constructor name keeps us forward-compatible if SF2e
    // renames or re-bundles the class in a future release.
    const ctorName = app?.constructor?.name ?? "";
    const looksLikePrompt = ctorName === "PickAThingPrompt"
      || (typeof app.resolveSelection === "function" && Array.isArray(app.choices));
    if (!looksLikePrompt) return;
    // Dedup: both renderPickAThingPrompt AND renderApplicationV2 fire
    // for the same PickAThingPrompt instance. Without this guard we
    // log + close the same prompt twice and silencedCount overcounts.
    if (state.silencedInstances.has(app)) return;
    silencePromptInstance(app, state);
  };

  // renderPickAThingPrompt fires for the exact class; renderApplicationV2
  // is the inheritance-chain fallback. Either one catching the instance
  // is sufficient; registering both is cheap insurance.
  state.hookIds.push({ name: "renderPickAThingPrompt", id: Hooks.on("renderPickAThingPrompt", handleRender) });
  state.hookIds.push({ name: "renderApplicationV2",    id: Hooks.on("renderApplicationV2", handleRender) });

  _wizardSilencerState = state;
  safePushDebug(
    `Wizard silencer installed (HLO pool ${hloItemPool.length} item(s)). ` +
    `Any PickAThingPrompt opened during this import will be auto-resolved.`
  );
}

/**
 * v0.6.12: refresh the silencer's pre-resolved-UUID pool from a matchAll
 * result. Called by _runPipelineImpl after each actor's matchAll, BEFORE
 * the embed step that triggers ChoiceSet prompts. The UUID pool is the
 * first preference pool in pickSilencerChoice: if a prompt's choice value
 * IS one of these UUIDs, the matcher already decided that HLO item
 * satisfies the slot, so we know that choice is correct without any
 * label heuristics.
 *
 * No-op if the silencer is uninstalled (defensive against teardown
 * races). Always replaces the prior actor's pool wholesale because
 * matched UUIDs are scoped to the actor currently being embedded.
 */
function setSilencerMatchedUuids(matchedResults) {
  const state = _wizardSilencerState;
  if (!state) return;
  const uuids = new Set();
  if (Array.isArray(matchedResults)) {
    for (const m of matchedResults) {
      const entry = m?.match?.entry;
      const uuid = entry?.uuid;
      if (typeof uuid === "string" && uuid.length > 0) uuids.add(uuid);
    }
  }
  state.matchedUuids = uuids;
  state.pushDebug(`Wizard silencer: matched-UUID pool refreshed (${uuids.size} UUID(s) available for prompt pre-resolution).`);
}

function uninstallWizardSilencer() {
  const state = _wizardSilencerState;
  if (!state) return;
  for (const { name, id } of state.hookIds) {
    try { Hooks.off(name, id); } catch (_err) { /* ignore */ }
  }
  if (state.patchedProto && state.patchedOriginal) {
    try {
      state.patchedProto.resolveSelection = state.patchedOriginal;
    } catch (_err) { /* ignore */ }
  }
  state.pushDebug(`Wizard silencer uninstalled. ${state.silencedCount} prompt(s) silenced this run.`);
  _wizardSilencerState = null;
}

/**
 * Pick the best choice for a live PickAThingPrompt instance, write it
 * into app.selection so the close path resolves with it, and close the
 * app. Logs the action to the conversion log so the user can review.
 * Also installs Layer 2 (prototype patch) if not already installed.
 */
function silencePromptInstance(app, state) {
  // Belt installation: patch the prototype on first sight. Future
  // resolveSelection calls short-circuit before render. We capture
  // the constructor so we restore on the EXACT prototype we patched.
  try {
    const proto = Object.getPrototypeOf(app);
    if (proto && !state.patchedProto && typeof proto.resolveSelection === "function") {
      state.patchedProto = proto;
      state.patchedOriginal = proto.resolveSelection;
      const original = proto.resolveSelection;
      // Closure over the silencer state so calls inside other code paths
      // still get HLO-informed picks.
      proto.resolveSelection = async function patchedResolveSelection() {
        // If silencer is no longer active (race between teardown and a
        // straggler call), fall through to the real implementation.
        if (!_wizardSilencerState) return original.call(this);
        // Dedup: if Layer 1's render hook already silenced this exact
        // instance, return its chosen selection (already on the app)
        // without logging again. Without this guard a single prompt
        // logs twice when both layers catch it.
        if (_wizardSilencerState.silencedInstances.has(this)) {
          return this.selection ?? null;
        }
        const picked = pickSilencerChoiceWithDebug(this, _wizardSilencerState);
        if (picked.choice == null) {
          // No choices to pick from; let the original method run so
          // SF2e's "no selection made" branch handles it. This is the
          // closest thing to a safe no-op.
          return original.call(this);
        }
        _wizardSilencerState.silencedInstances.add(this);
        _wizardSilencerState.silencedCount += 1;
        const title = this?.options?.window?.title
          ?? this?.title
          ?? "PickAThingPrompt";
        _wizardSilencerState.pushDebug(
          `Silencer pick: tried [matched-items, paren-hint, hlo-skills, label-fallback] -> hit on ${picked.hitPool}, picked "${picked.choice.label ?? picked.choice.value}".`
        );
        _wizardSilencerState.pushLog("info",
          `Silenced wizard prompt: "${title}" - auto-resolved to "${picked.choice.label ?? picked.choice.value}".`);
        return picked.choice;
      };
      state.pushDebug("Wizard silencer: PickAThingPrompt.prototype.resolveSelection patched.");
    }
  } catch (err) {
    state.pushDebug(`Wizard silencer: prototype patch skipped (${err?.message ?? err}).`);
  }

  // Layer 1: handle the live instance that just rendered. Mark the
  // instance in the WeakSet BEFORE doing any work so that the second
  // render hook (renderApplicationV2 vs renderPickAThingPrompt) and
  // the prototype patch both see it and skip.
  try {
    state.silencedInstances.add(app);
    const picked = pickSilencerChoiceWithDebug(app, state);
    const title = app?.options?.window?.title ?? app?.title ?? "PickAThingPrompt";
    if (picked.choice == null) {
      // No selectable choices. Closing without a selection lets
      // SF2e's ruleSource.ignored = true branch handle it (the same
      // behavior as if the user dismissed the prompt). We do NOT
      // surface a notification to the user because the conversion
      // log already documents the silencer ran.
      state.pushDebug(`Wizard silencer: prompt "${title}" had no usable choices; closing without selection.`);
      app.selection = null;
      app.close({ force: true });
      return;
    }
    app.selection = picked.choice;
    state.silencedCount += 1;
    state.pushDebug(
      `Silencer pick: tried [matched-items, paren-hint, hlo-skills, label-fallback] -> hit on ${picked.hitPool}, picked "${picked.choice.label ?? picked.choice.value}".`
    );
    state.pushLog("info",
      `Silenced wizard prompt: "${title}" - auto-resolved to "${picked.choice.label ?? picked.choice.value}".`);
    // close() triggers _onClose which calls #resolve(this.selection),
    // unblocking the awaiting ChoiceSetRuleElement.preCreate.
    app.close({ force: true });
  } catch (err) {
    state.pushDebug(`Wizard silencer: failed to silence live prompt (${err?.message ?? err}).`);
  }
}

/**
 * Pick a choice object for a PickAThingPrompt. Order of preference:
 *   1. Pre-resolved compendium UUIDs (matched-items pool): if a prompt
 *      choice value IS a UUID we already matched for this actor, the
 *      matcher decided that HLO item satisfies the slot, so we trust it.
 *   2. HLO skill picks (for skill ChoiceSets specifically): when the
 *      prompt offers skills, prefer an HLO Skill compset entry whose
 *      profLevel is Trained-or-better. The Infiltrator class-feature
 *      grants "trained in a skill of your choice"; HLO records the
 *      chosen skill at Trained, so the matching skill on the actor's
 *      HLO state is the one to pick.
 *   3. Label / slug / UUID-tail string match against the full HLO item
 *      pool (the v0.6.11 behavior). Catches non-skill ChoiceSets where
 *      HLO's chosen feat/feature name matches a prompt label.
 *   4. First available choice (last-resort fallback so the silencer
 *      never returns null for a prompt with choices).
 *
 * NEVER returns a "cancel" / null-selection result for a non-empty
 * prompt because that would leave the grant slot empty and cascade
 * into broken state per spec.
 */
function pickSilencerChoice(app, hloItemPool) {
  return pickSilencerChoiceWithDebug(app, { hloItemPool, matchedUuids: new Set() }).choice;
}

/**
 * Three-pool variant that also reports WHICH pool produced the hit
 * (matched-items, hlo-skills, label-fallback, first-choice, or null).
 * silencePromptInstance uses this to log the strategy alongside the
 * picked label, which makes wrong-pick triage in the conversion log a
 * one-line audit instead of a guessing game.
 *
 * Returns { choice, hitPool }. choice is null only when the prompt is
 * empty. hitPool is "none" iff choice is null.
 */
// Strip a trailing parenthetical group from a name. "Foxfire (Fire)" -> "Foxfire".
function stripTrailingParens(name) {
  return typeof name === "string" ? name.replace(/\s*\([^)]*\)\s*$/, "").trim() : "";
}

// Return the contents of the last parenthetical group, or null. "Foxfire (Fire)" -> "Fire".
function lastParenthetical(name) {
  const m = typeof name === "string" ? name.match(/\(([^)]*)\)\s*$/) : null;
  return m ? m[1].trim() : null;
}

function pickSilencerChoiceWithDebug(app, state) {
  const choices = Array.isArray(app?.choices) ? app.choices : [];
  if (choices.length === 0) return { choice: null, hitPool: "none" };

  const hloItemPool = Array.isArray(state?.hloItemPool) ? state.hloItemPool : [];
  const matchedUuids = state?.matchedUuids instanceof Set ? state.matchedUuids : new Set();

  // Pool 1: pre-resolved compendium UUIDs from the matcher. If a choice
  // value (PF2e/SF2e ChoiceSet uses the UUID as the choice value when
  // the rule's itemType is set) IS a UUID we already matched, that is
  // by definition the right answer; skip the fuzzier pools.
  if (matchedUuids.size > 0) {
    for (const choice of choices) {
      const value = typeof choice?.value === "string" ? choice.value : "";
      if (value && matchedUuids.has(value)) {
        return { choice, hitPool: "matched-items" };
      }
    }
  }

  // Pool 1.5: parenthetical hint. HLO encodes a player's variant choice
  // in a trailing parenthetical on the item name ("Foxfire (Fire)"). When
  // the prompt title matches such an item's base name, the parenthetical
  // IS the answer. Higher confidence than the skill/label pools because
  // HLO stated the choice outright, so it runs right after the exact-UUID
  // pool. Without this, a damage-type prompt falls through to first-choice
  // and silently picks the wrong element.
  const promptTitle = stripTrailingParens(app?.options?.window?.title ?? app?.title ?? "").toLowerCase();
  if (promptTitle && hloItemPool.length > 0) {
    for (const it of hloItemPool) {
      const itName = typeof it?.name === "string" ? it.name : "";
      if (!itName || stripTrailingParens(itName).toLowerCase() !== promptTitle) continue;
      const paren = lastParenthetical(itName);
      if (!paren) continue;
      const tokens = paren.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean);
      // Exact match first (damage-type prompts: choice "Fire" === token "fire").
      for (const token of tokens) {
        for (const choice of choices) {
          const label = typeof choice?.label === "string" ? choice.label.trim().toLowerCase() : "";
          const value = typeof choice?.value === "string" ? choice.value.trim().toLowerCase() : "";
          if (label === token || value === token) return { choice, hitPool: "paren-hint" };
        }
      }
      // Whole-word fallback (a longer slug value may contain the token).
      for (const token of tokens) {
        const re = new RegExp(`\\b${token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`);
        for (const choice of choices) {
          const label = typeof choice?.label === "string" ? choice.label.toLowerCase() : "";
          const value = typeof choice?.value === "string" ? choice.value.toLowerCase() : "";
          if (re.test(label) || re.test(value)) return { choice, hitPool: "paren-hint" };
        }
      }
    }
  }

  // Pool 2: HLO skill picks. Detect a "pick a skill" prompt by checking
  // whether any choice value looks like a known PF2e/SF2e skill slug.
  // If so, walk HLO's Skill compset items in profLevel-desc order and
  // return the first choice whose value matches an HLO skill that is
  // Trained+ on the actor. This handles the Infiltrator class-feature
  // skill grant: HLO knows which skill the user picked because it is
  // the one recorded at Trained in the actor's Skill items.
  const looksLikeSkillPrompt = choices.some((c) => SKILL_SLUGS.has(skillSlugFromChoice(c)));
  if (looksLikeSkillPrompt && hloItemPool.length > 0) {
    // Build a ranked list of HLO skill names: highest profLevel first,
    // so a Master-rank skill grant prefers the Master skill over a
    // Trained one (rare in practice at level 1, but cheap insurance).
    const rankedHloSkills = [];
    for (const it of hloItemPool) {
      if (it?.compset !== "Skill") continue;
      // Raw HLO uses "ProfLevel" (uppercase); the parsed IR uses
      // "profLevel" (lowercase). The silencer pool can be either
      // depending on where in the pipeline the install happened, so
      // accept both casings here.
      const profLevel = it?.profLevel ?? it?.ProfLevel ?? null;
      const rank = PROF_RANK[profLevel] ?? 0;
      if (rank < 1) continue; // Untrained skills cannot satisfy a grant.
      const name = typeof it?.name === "string" ? it.name : "";
      if (!name) continue;
      // Lore skills are surfaced by the prompt as "lore-<topic>"; skip
      // generic lore entries because the grant usually demands a core
      // skill, not a lore subskill.
      if (/ lore$/i.test(name)) continue;
      rankedHloSkills.push({ slug: slugifySkill(name), rank });
    }
    rankedHloSkills.sort((a, b) => b.rank - a.rank);

    for (const { slug } of rankedHloSkills) {
      for (const choice of choices) {
        if (skillSlugFromChoice(choice) === slug) {
          return { choice, hitPool: "hlo-skills" };
        }
      }
    }
  }

  // Pool 3: label / slug / UUID-tail string matching (v0.6.11 behavior).
  if (hloItemPool.length > 0) {
    const hloNames = new Set();
    const hloSlugs = new Set();
    for (const it of hloItemPool) {
      if (typeof it?.name === "string") hloNames.add(it.name.trim().toLowerCase());
      if (typeof it?.slug === "string") hloSlugs.add(it.slug.trim().toLowerCase());
    }
    for (const choice of choices) {
      const label = typeof choice?.label === "string" ? choice.label.trim().toLowerCase() : "";
      const value = typeof choice?.value === "string" ? choice.value.trim().toLowerCase() : "";
      if (label && hloNames.has(label)) return { choice, hitPool: "label-fallback" };
      if (value && hloSlugs.has(value)) return { choice, hitPool: "label-fallback" };
      // UUID value: pull the trailing slug and try that too.
      if (value.includes(".")) {
        const tail = value.split(".").pop();
        if (tail && (hloSlugs.has(tail) || hloNames.has(tail))) {
          return { choice, hitPool: "label-fallback" };
        }
      }
    }
  }

  // Last resort: first concrete choice. Same v0.6.11 behavior, but
  // labeled so the conversion log makes the "we guessed" decision
  // visible instead of silent.
  return { choice: choices[0], hitPool: "first-choice" };
}

/**
 * Canonical PF2e/SF2e core skill slugs. Used by pickSilencerChoiceWithDebug
 * to detect "this prompt is asking for a skill" without a brittle title
 * regex. Both systems share the same skill list; lore is excluded because
 * lore picks are surfaced by separate item-type prompts.
 */
const SKILL_SLUGS = new Set([
  "acrobatics", "arcana", "athletics", "computers", "crafting", "deception",
  "diplomacy", "intimidation", "medicine", "nature", "occultism",
  "performance", "piloting", "religion", "society", "stealth", "survival",
  "thievery",
]);

const PROF_RANK = {
  Untrained: 0,
  Trained:   1,
  Expert:    2,
  Master:    3,
  Legendary: 4,
};

function slugifySkill(name) {
  return String(name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

/**
 * Extract the skill slug from a PickAThingPrompt choice, accepting both
 * the slug-as-value shape ({value: "stealth", label: "Stealth"}) and the
 * AcuityRecord-shape used by some SF2e ChoiceSet variants ({value: {
 * slug: "stealth" }, label: "Stealth"}).
 */
function skillSlugFromChoice(choice) {
  if (!choice) return "";
  const v = choice.value;
  if (typeof v === "string") return v.trim().toLowerCase();
  if (v && typeof v === "object" && typeof v.slug === "string") return v.slug.trim().toLowerCase();
  return "";
}
