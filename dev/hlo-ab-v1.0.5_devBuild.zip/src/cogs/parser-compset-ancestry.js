// ============================================================
// COG: parser-compset-ancestry.js - Identity-shaping compsets
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - Migrated from src/parser/compsets/ancestry.js as part
//             of the cog architecture pivot. Handles Ancestry,
//             Heritage, Language. These set the character's basic
//             shape and feed the matcher's slug-first lookup against
//             the ancestries / heritages / ancestry-features Foundry
//             compendia.

export const Ancestry = {
  normalize(raw, _warnings) {
    // raw.Trait holds a comma-separated list whose first entry is typically
    // the ancestry slug (an*, e.g. anHuman). Subsequent entries are creature
    // type traits (trtHumanoid). The dispatcher already parses Trait into
    // traitIds; here we tag the primary slug for the matcher's convenience.
    const traitIds = parseTraitList(raw.Trait);
    return {
      primarySlug: traitIds.find((t) => t.startsWith("an")) ?? null,
      creatureTypeTraits: traitIds.filter((t) => t.startsWith("trt")),
    };
  },
};

export const Heritage = {
  normalize(raw, _warnings) {
    return {
      components: raw.components ?? null,
    };
  },
};

export const Language = {
  normalize(raw, _warnings) {
    // Languages are pure identifiers; nothing extra to normalize.
    return {};
  },
};

function parseTraitList(traitField) {
  if (!traitField || typeof traitField !== "string") return [];
  return traitField.split(",").map((s) => s.trim()).filter(Boolean);
}

export default { id: "parser-compset-ancestry" };
