// ============================================================
// COG: parser-compset-armor.js - Armor family normalizers
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.2.0
//           - v0.7.1 Rune Triad (pass 2). Wired util-rune-parser into
//             Armor.normalize. HLO ships armor with runes baked into
//             the display name the same way it ships weapons: "+3
//             greater resilient fire resistant winged greater ready
//             full plate" lands as a single Armor item whose
//             display name carries the +3 potency, the greater
//             resilient fundamental, and three property runes (fire
//             resistant, winged, greater ready). v0.7.0 already
//             passed this through the slug pipeline (the matcher
//             reads `item.runes?.baseName` to retry the lookup with
//             just "full plate"), but the Armor handler wasn't
//             surfacing `runes` at all, so:
//               (a) the matcher fell back to slugifying the full
//                   name, which on entries like "+1 padded armor"
//                   produced "1-padded-armor", which no compendium
//                   contains, so the armor was silently dropped from
//                   the actor (Berial ETT had zero armor items
//                   land in v0.7.0).
//               (b) the builder had no rune envelope to write to
//                   system.runes, so even when the base name DID
//                   match (Bhelroth's full plate), the resulting
//                   Foundry item came back with runes.potency=0,
//                   runes.resilient=0, property=[].
//             The handler now stores `runes: { potency, striking,
//             propertyRunes, baseName, matchedRunes }` on the IR,
//             mirroring the v0.7.0 Weapon shape. The `striking`
//             field name is preserved across weapon and armor IRs
//             because the underlying rune-parser does not branch on
//             item type, and the dialog-side resolver knows to map
//             that field to system.runes.resilient when the resolved
//             Foundry item type is "armor" and to system.runes.
//             striking when it is "weapon".
//           - 0.1.0: Migrated from src/parser/compsets/armor.js as part of
//             the cog architecture pivot. Armor, ArmorTrait, Upgrade.
//             Armor upgrades in SF2e (deflecting field, basic
//             environmental protection, filtered rebreather) arrive
//             as nested items via containment: "Installed". The
//             matcher resolves each against the equipment pack; the
//             builder attaches them under the parent armor via
//             flags.pf2e.attached when supported.

import { extractRunes } from "./util-rune-parser.js";

/**
 * Transform the rune-parser output for an armor IR. The parser uses
 * `striking` to carry both weapon striking tiers and armor resilient
 * tiers (it does not know whether the input is a weapon or armor
 * name). For armor IRs we keep the field name aligned with the
 * underlying PF2e schema: armor stores tier under
 * system.runes.resilient, not system.runes.striking. The builder
 * reads `runes.resilient` for armor items; pass 1's
 * applyRuneAndMaterialPatches in builder-items.js also writes to
 * `runes.resilient` when it merges in apply-to-parent rune patches.
 * We zero out `striking` defensively so any downstream code that
 * iterates both fields does not double-count.
 */
function adaptRunesForArmor(runes) {
  return {
    potency:       runes.potency ?? 0,
    striking:      0,
    resilient:     runes.striking ?? 0,
    propertyRunes: Array.isArray(runes.propertyRunes) ? runes.propertyRunes : [],
    baseName:      runes.baseName ?? "",
    matchedRunes:  Array.isArray(runes.matchedRunes) ? runes.matchedRunes : [],
  };
}

export const Armor = {
  normalize(raw, _warnings) {
    const runes = adaptRunesForArmor(extractRunes(raw?.name ?? ""));
    return {
      arAC:             raw.arAC ?? null,
      arItemAC:         raw.arItemAC ?? null,
      arDexModCap:      raw.arDexModCap ?? null,
      proLevelBonNet:   raw.proLevelBonNet ?? null,
      grBulk:           raw.grBulk ?? null,
      profLevel:        raw.ProfLevel ?? null,
      runes,
    };
  },
};

export const ArmorTrait = {
  normalize(raw, _warnings) {
    return {
      components:       raw.components ?? null,
    };
  },
};

export const Upgrade = {
  normalize(raw, _warnings) {
    return {
      grBulk:           raw.grBulk ?? null,
      period:           raw.Period ?? null,
      trkMaximum:       raw.trkMaximum ?? null,
    };
  },
};

export default { id: "parser-compset-armor" };
