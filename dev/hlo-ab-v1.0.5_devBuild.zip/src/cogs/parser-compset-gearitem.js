// ============================================================
// COG: parser-compset-gearitem.js - GearItem normalizer
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.1.0
//           - New compset cog for v0.7.0. HLO emits a second
//             flavor of generic gear under the "GearItem"
//             compset (id prefix "gr", same prefix as GearBasic;
//             the compset field disambiguates). GearItem covers
//             everyday items that do not fit the GearBasic
//             schema cleanly: HLO sometimes drops the
//             stackQty / grBulk fields on items like Earplugs
//             (Berial carries grEarplugs.1176 "Earplugs" with
//             nothing but a name and the compset tag). The
//             normalizer mirrors GearBasic's shape so the actor
//             builder can treat the two compsets uniformly, but
//             gracefully tolerates the missing fields. The
//             builder embeds GearItem as Foundry type=
//             "equipment" (the catch-all gear type) when no
//             compendium match is found; matched entries flow
//             through pf2e.equipment-srd or the SF2e equivalent
//             the same way GearBasic does.

export const GearItem = {
  normalize(raw, _warnings) {
    return {
      stackQty:         raw.stackQty ?? null,
      grBulk:           raw.grBulk ?? null,
    };
  },
};

export default { id: "parser-compset-gearitem" };
