// ============================================================
// COG: parser-compset-faction.js - PFS faction membership
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.1.0
//           - v0.7.0: new cog for HLO's Faction compset (id prefix
//             "fa"). PFS faction memberships ("Envoys' Alliance",
//             "Grand Archive", "Horizon Hunters", "Radiant Oath",
//             "Verdant Wheel", "Vigilant Seal") are NOT embedded
//             items in PF2e; they are actor metadata stored at
//             system.pfs.reputation. The PF2e schema (verified
//             against data/FoundryVTT-WindowsPortable-14.361/Data/
//             systems/pf2e/template.json line 106-119) keys the
//             reputation block by two-letter faction code:
//                 system.pfs.reputation = {
//                   EA: null, GA: null, HH: null,
//                   VS: null, RO: null, VW: null
//                 }
//             A null entry means "not a member"; any numeric value
//             (default 0) means "member, this much reputation".
//             HLO's export records membership only (the boon
//             reputation totals are tracked outside the export
//             format), so we surface a default rep value of 0 to
//             flip the slot from null to "member, fresh start".
//             The user can edit the value on the sheet afterward.
//
// Routing note: this handler does NOT create a Foundry item. Instead
// it tags the IR with a discriminator (`_actorMetadata`) that the
// PF2e/SF2e actor builder reads to populate system.pfs.reputation.
// COMPSET_TO_PACKS["Faction"] stays null so matcher-core short-
// circuits to "no match" without trying to look up a non-existent
// "factions" pack.

/**
 * Map the canonical HLO faction name (with the curly apostrophe
 * variant for "Envoys' Alliance") to the two-letter PF2e code used
 * in system.pfs.reputation. We normalize the name (strip the
 * apostrophe, collapse whitespace, lowercase) so HLO's curly-quote
 * "Envoys’ Alliance" matches the same as a straight-quote
 * variant.
 */
export const FACTION_NAME_TO_CODE = {
  "envoys alliance":   "EA",
  "grand archive":     "GA",
  "horizon hunters":   "HH",
  "radiant oath":      "RO",
  "verdant wheel":     "VW",
  "vigilant seal":     "VS",
};

/**
 * Strip apostrophes (straight and curly), collapse whitespace, and
 * lowercase so "Envoys’ Alliance" -> "envoys alliance".
 */
export function normalizeFactionName(name) {
  if (!name || typeof name !== "string") return null;
  return name
    .replace(/[’']/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

/**
 * Resolve an HLO faction name (or id prefix-stripped slug) to the
 * two-letter PF2e code. Returns null if the name is not a known
 * PFS faction (in which case the caller emits an unknown-faction
 * warning rather than silently dropping data).
 */
export function factionCodeFor(name) {
  const key = normalizeFactionName(name);
  if (!key) return null;
  return FACTION_NAME_TO_CODE[key] ?? null;
}

export const Faction = {
  normalize(raw, warnings) {
    const name = raw?.name ?? null;
    const code = factionCodeFor(name);
    if (!code) {
      if (Array.isArray(warnings)) {
        warnings.push({
          code: "unknown-faction",
          message: `Unknown PFS faction "${name}". Expected one of: Envoys' Alliance, Grand Archive, Horizon Hunters, Radiant Oath, Verdant Wheel, Vigilant Seal.`,
          context: { name },
        });
      }
      return {};
    }
    // HLO does not surface a reputation total per faction in the
    // standard export shape; we set 0 as the "member, fresh start"
    // marker so the sheet flips the row from "not a member" to
    // "0 reputation, member" and the user can edit upward.
    return {
      _actorMetadata: {
        subtype: "faction",
        code,
        name,
        reputation: 0,
      },
    };
  },
};

export default { id: "parser-compset-faction" };
