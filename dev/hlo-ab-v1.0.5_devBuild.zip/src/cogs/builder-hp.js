// ============================================================
// COG: builder-hp.js - Baseline HP calculation for PF2e/SF2e
//                      actors at create time
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.2.0
//           - Wave 3 of the cog migration. Promoted from
//             src/builder/build-hp.js. No logic changes; only the
//             file location and header are new.
//           - 0.1.0: Wave 5 (in src/builder/). HP baseline
//             calculation. PF2e and SF2e auto-compute HP at
//             runtime from class + ancestry + level + con
//             modifier, but the actor needs a non-zero value at
//             create time or the sheet's HP bar reads 0/0 until
//             the class item recalculates.
//
// PF2e/SF2e HP formula (per-level, level 1+):
//   HP_max = ancestryHP + (classHP + conMod) * level
//
// Class HP per level by published class (current as of PF2e Player Core 2):
//   Alchemist 8, Barbarian 12, Bard 8, Champion 10, Druid 8, Fighter 10,
//   Investigator 8, Kineticist 8, Magus 8, Monk 10, Oracle 8, Ranger 10,
//   Rogue 8, Sorcerer 6, Summoner 10, Swashbuckler 10, Thaumaturge 8,
//   Witch 6, Wizard 6.
// SF2e classes:
//   Envoy 8, Mystic 8, Operative 8, Solarian 10, Technomancer 6, Witchwarper 6.
// Ancestry HP varies (Human 8, Dwarf 10, Elf 6, Goblin 6, Gnome 8, Halfling 6,
// Kasatha 8, Lashunta 6, Shirren 6, Vesk 10, Android 8, etc.).
//
// Lookup tables below are best-effort and capture the most common cases.
// Anything missing returns null and the builder leaves HP unset (Foundry
// auto-calc will fill in at the next system tick).

const CLASS_HP = {
  // PF2e
  alchemist: 8, barbarian: 12, bard: 8, champion: 10, druid: 8,
  fighter: 10, investigator: 8, kineticist: 8, magus: 8, monk: 10,
  oracle: 8, ranger: 10, rogue: 8, sorcerer: 6, summoner: 10,
  swashbuckler: 10, thaumaturge: 8, witch: 6, wizard: 6, gunslinger: 8,
  inventor: 8, animist: 8, exemplar: 10, runesmith: 8,
  // SF2e
  envoy: 8, mystic: 8, operative: 8, solarian: 10, technomancer: 6,
  witchwarper: 6,
};

const ANCESTRY_HP = {
  // PF2e core
  human: 8, dwarf: 10, elf: 6, goblin: 6, gnome: 8, halfling: 6,
  // PF2e ancestry guide / remastered additions
  leshy: 8, orc: 10, kobold: 6, ratfolk: 6, tengu: 6, hobgoblin: 8,
  lizardfolk: 8, catfolk: 8, conrasu: 6, anadi: 8, fetchling: 6,
  fleshwarp: 10, kashrishi: 10, nagaji: 8, poppet: 6, shisk: 8,
  shoony: 6, sprite: 4, vanara: 8, vishkanya: 6, athamaru: 8,
  // SF2e ancestries
  kasatha: 8, lashunta: 6, shirren: 6, vesk: 10, android: 8,
  ysoki: 6, // ratfolk variant in SF2e
};

/**
 * Compute baseline HP for a freshly-imported actor.
 *
 * @param {object} actorIR    From parseActor.
 * @returns {number | null}   HP max, or null if not enough data to compute.
 */
export function computeBaselineHp(actorIR) {
  const level = actorIR.gameValues.levelNet ?? 1;
  const conItem = actorIR.items.find((i) => i.compset === "AbilScore" && i.name === "Constitution");
  const conMod = conItem?.modifier ?? 0;

  const classItem = actorIR.items.find((i) => i.compset === "Class");
  const ancestryItem = actorIR.items.find((i) => i.compset === "Ancestry");

  const classSlug = classItem?.primarySlug?.replace(/^cl/, "").toLowerCase();
  const ancestrySlug = (ancestryItem?.primarySlug ?? ancestryItem?.slug ?? "")
    .replace(/^an/, "").replace(/SF$/i, "").toLowerCase();

  const classHp = CLASS_HP[classSlug];
  const ancestryHp = ANCESTRY_HP[ancestrySlug];

  if (classHp == null || ancestryHp == null) return null;

  return ancestryHp + (classHp + conMod) * level;
}
