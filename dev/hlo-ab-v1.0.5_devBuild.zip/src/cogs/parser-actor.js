// ============================================================
// COG: parser-actor.js - Per-actor walker
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.2.0
//           - v0.6.0: synthesize a Background item when HLO
//             gameValues.actBackgroundText is present. HLO sends
//             the background as a top-level field, not as a
//             compset item, so the parser previously dropped it
//             on the floor. Synthesizing it as an item with
//             compset "Background" lets it flow through the
//             standard matcher pipeline (which now resolves it
//             against the pf2e.backgrounds / sf2e.backgrounds
//             pack via the deterministic pack index).
//           - 0.1.0: Migrated from src/parser/parse-actor.js as part of the
//             cog architecture pivot. parseActor takes one raw actor
//             object from the HLO export and produces an ActorIR.
//             Imports parseItems, detectActorType, and inferSystem
//             from sibling cogs.

import { parseItems } from "./parser-items.js";
import { detectActorType } from "./parser-actor-type.js";
import { inferSystem } from "./system-detection.js";

/**
 * @param {object} rawActor      Raw `actors["actor.N"]` block.
 * @param {string} actorKey      The HLO actor key, e.g. "actor.1".
 * @param {Array}  warnings      Shared warning accumulator (mutated).
 * @returns {{
 *   key: string,
 *   name: string,
 *   player: string,
 *   gameValues: object,
 *   items: Array<object>,
 *   itemTree: { [parentId: string]: Array<string> },
 *   inferredSystem: "pf2e" | "sf2e" | null
 * }}
 */
export function parseActor(rawActor, actorKey, warnings, options = {}) {
  if (!rawActor || typeof rawActor !== "object") {
    throw new Error(`parseActor: actor "${actorKey}" is not an object.`);
  }

  const name = rawActor.name ?? null;
  const player = typeof rawActor.player === "string" ? rawActor.player : (rawActor.player?.name ?? null);
  const gameValues = normalizeGameValues(rawActor.gameValues ?? {});

  const { items, itemTree } = parseItems(rawActor.items ?? {}, warnings);
  // Synthesize a Background item from gameValues.actBackgroundText. HLO
  // surfaces the chosen background as a top-level field, never as a
  // compset entry; if we do not synthesize it here, the matcher never
  // sees it and the Foundry actor lands without its background item.
  const synthBackground = makeSyntheticBackground(gameValues);
  if (synthBackground) items.push(synthBackground);
  const inferredSystem = inferSystem(items, gameValues, warnings);
  const actorIR = {
    key: actorKey,
    name,
    player,
    gameValues,
    items,
    itemTree,
    inferredSystem,
    portfolioCharId: options.portfolioCharId ?? null,
  };
  const typeDecision = detectActorType(actorIR);
  actorIR.actorType = typeDecision.actorType;
  actorIR.actorTypeConfidence = typeDecision.confidence;
  actorIR.actorTypeReasons = typeDecision.reasons;
  actorIR.minionSubtype = typeDecision.minionSubtype ?? null;
  if (typeDecision.confidence < 0.6) {
    warnings.push({
      code: "ambiguous-actor-type",
      message: `Low-confidence type detection for "${name ?? actorKey}": ${typeDecision.actorType} at ${typeDecision.confidence.toFixed(2)}. Builder will emit "character" by default; override if wrong.`,
    });
  }
  return actorIR;
}

/**
 * Build a synthetic Background item from gameValues.backgroundText so
 * the matcher pipeline can route it like any other compset entry.
 * Returns null if the actor has no background text. Returned shape
 * matches the parser-items.js item IR contract: compset, name, slug,
 * id, plus the back-reference fields the matcher reads.
 */
function makeSyntheticBackground(gameValues) {
  const text = gameValues?.backgroundText;
  if (!text || typeof text !== "string" || text.trim().length === 0) return null;
  const name = text.trim();
  // Best-effort slug derivation: lowercase, kebab. The pack index
  // resolves by name first so this is just a fallback.
  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  return {
    id: `synthetic-background.${slug || "unknown"}`,
    name,
    compset: "Background",
    components: "Background",
    slug,
    primarySlug: slug,
    traitIds: [],
    parentId: null,
    children: [],
    raw: { actBackgroundText: text, _synthetic: true },
  };
}

function normalizeGameValues(raw) {
  // HLO uses act* prefix conventions for character-level computed values. We
  // pass these through directly so the builder layer can reference them by
  // their original keys; this layer just declares the canonical shape.
  return {
    levelNet: raw.actLevelNet ?? null,
    xpNet: raw.actXPNet ?? null,
    race: raw.actRace ?? null,
    backgroundText: raw.actBackgroundText ?? null,
    classText: raw.actClassText ?? null,
    bulk: raw.actBulk ?? null,
    encumbered: raw.actEncumbered ?? null,
    overburdened: raw.actOverburdened ?? null,
    moneyNet: raw.actMoneyNet ?? null,
    space: raw.actSpace ?? null,
    reachBase: raw.actReachBase ?? null,
    reachNet: raw.actReachNet ?? null,
    raw, // preserve the original block for compset code that needs more
  };
}

export default { id: "parser-actor" };
