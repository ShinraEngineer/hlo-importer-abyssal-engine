// ============================================================
// COG: parser-compset-magicitem.js - MagicItem normalizer
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.1.0
//           - New cog. HLO emits magic items under a single
//             compset called MagicItem (id prefix "gr", shared
//             with GearBasic; the compset field is the source of
//             truth, not the prefix). Foundry PF2e/SF2e split
//             that one bag across several types: handwraps land
//             as type "weapon", potions/elixirs as "consumable",
//             worn items (belts, mantles, aeon stones, talismans,
//             wayfinders) as "equipment", and the pouch /
//             knapsack family as "backpack". Without a handler
//             every MagicItem fell through "Unknown compset" and
//             produced no Foundry item at all (verified
//             2026-05-16 against Berial Jeggare's exported
//             actor: all eight MagicItem entries were missing
//             from the resulting Foundry actor).
//
//             This handler does three things:
//               1. Parses rune prefixes via util-rune-parser so
//                  enchanted handwraps land on the actor with
//                  the right potency/striking/property values.
//               2. Detects the Foundry document type by name
//                  pattern (handwraps -> weapon, potion / elixir
//                  -> consumable, pouch / knapsack / sack ->
//                  backpack, default -> equipment) and stashes
//                  it on the IR as `foundryType` so the builder
//                  layer can route it.
//               3. Surfaces baseName so the matcher resolves to
//                  the base compendium entry rather than the
//                  rune-prefixed display name. The matcher's
//                  slug pipeline already strips parenthetical
//                  tier suffixes (step 3.5) and precious
//                  materials (step 3.6); baseName lets us add a
//                  rune-stripped candidate for MagicItem without
//                  touching matcher-slug-table.
//
//             Magical bulk and the trtInvested marker pass
//             through so the builder can populate
//             system.bulk.value and system.usage.value
//             ("worn", "invested").

import { extractRunes } from "./util-rune-parser.js";

// Foundry document types we may route a MagicItem to. Kept as
// constants so a typo in any switch arm fails noisily at lint.
const TYPE_WEAPON     = "weapon";
const TYPE_CONSUMABLE = "consumable";
const TYPE_BACKPACK   = "backpack";
const TYPE_EQUIPMENT  = "equipment";

/**
 * Patterns that drive name-based type detection. Order matters: the
 * first match wins, so put more-specific phrases first. Each entry is
 * { regex, type, reason } where reason is recorded on the IR for
 * debugging.
 */
const TYPE_PATTERNS = [
  // Handwraps of Mighty Blows and its alternative-handwraps tag-mates
  // (e.g. Bloodknuckles) all land as type "weapon" so the rune slots
  // resolve correctly.
  { regex: /\bhandwraps\b/i,         type: TYPE_WEAPON,     reason: "handwraps -> weapon" },
  { regex: /\bbloodknuckles\b/i,     type: TYPE_WEAPON,     reason: "alternative-handwraps -> weapon" },

  // Consumables. Potion, elixir, scroll, talisman, oil, ammunition all
  // appear under MagicItem in HLO's compset bucket. Scrolls are the
  // odd one out (Foundry uses type "consumable" for them but stores
  // them under the consumables-srd pack; the matcher already routes
  // there via packsFor("MagicItem", ...)).
  { regex: /\bpotion\b/i,            type: TYPE_CONSUMABLE, reason: "potion -> consumable" },
  { regex: /\belixir\b/i,            type: TYPE_CONSUMABLE, reason: "elixir -> consumable" },
  { regex: /\bscroll\b/i,            type: TYPE_CONSUMABLE, reason: "scroll -> consumable" },
  { regex: /\btalisman\b/i,          type: TYPE_CONSUMABLE, reason: "talisman -> consumable" },
  { regex: /\boil\b/i,               type: TYPE_CONSUMABLE, reason: "oil -> consumable" },
  { regex: /\bsnare\b/i,             type: TYPE_CONSUMABLE, reason: "snare -> consumable" },

  // Containers (backpack-type items, which inherit the bulk-reducing
  // schema in PF2e/SF2e). The "pouch", "knapsack", "sack", "bag",
  // "satchel", "chest" patterns cover the family.
  { regex: /\bspacious pouch\b/i,    type: TYPE_BACKPACK,   reason: "spacious pouch -> backpack" },
  { regex: /\bknapsack\b/i,          type: TYPE_BACKPACK,   reason: "knapsack -> backpack" },
  { regex: /\bbag of holding\b/i,    type: TYPE_BACKPACK,   reason: "bag of holding -> backpack" },
  { regex: /\bhandy haversack\b/i,   type: TYPE_BACKPACK,   reason: "haversack -> backpack" },
];

/**
 * Detect the Foundry document type for a MagicItem entry from its
 * baseName (name with runes stripped). Falls back to "equipment" for
 * the worn-but-not-bag case: belts, mantles, aeon stones, rings,
 * cloaks, brooches, wayfinders, headbands, etc.
 */
export function detectMagicItemType(baseName) {
  if (!baseName || typeof baseName !== "string") {
    return { type: TYPE_EQUIPMENT, reason: "default (empty name) -> equipment" };
  }
  for (const { regex, type, reason } of TYPE_PATTERNS) {
    if (regex.test(baseName)) return { type, reason };
  }
  return { type: TYPE_EQUIPMENT, reason: "default (worn magic item) -> equipment" };
}

export const MagicItem = {
  normalize(raw, _warnings) {
    const rawName = raw?.name ?? "";
    const runes = extractRunes(rawName);
    const detected = detectMagicItemType(runes.baseName || rawName);
    const traitField = typeof raw?.Trait === "string" ? raw.Trait : "";
    const invested = /\btrtInvested\b/.test(traitField);
    return {
      // Foundry document-type routing. The builder reads this to
      // decide whether to wrap the matched compendium entry as a
      // weapon, consumable, backpack, or equipment item.
      foundryType:      detected.type,
      foundryTypeReason: detected.reason,
      // Rune envelope. Empty fields (potency=0, striking=0,
      // propertyRunes=[]) are still present so the builder does not
      // have to existence-check before reading.
      runes,
      // Pass-through gear fields the builder uses on the actor.
      grBulk:           raw.grBulk ?? null,
      stackQty:         raw.stackQty ?? null,
      invested,
    };
  },
};

export default { id: "parser-compset-magicitem" };
