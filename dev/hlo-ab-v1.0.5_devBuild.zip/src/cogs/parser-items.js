// ============================================================
// COG: parser-items.js - Item dispatcher (recursive walker)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.2.0
//           - v0.7.1: thread the HLO slug into raw as `_slug` so
//             compset handlers that need to classify by id prefix
//             (parser-compset-rune, parser-compset-material) can
//             reach it without changing the normalize() signature.
//             The slug was already computed once at this layer (line
//             below); the new field is a non-destructive addition
//             alongside raw's existing fields.
//           - 0.1.0: Migrated from src/parser/parse-items.js as part of the
//             cog architecture pivot. parseItems walks the actor's
//             nested item tree and produces a flat ItemIR list plus a
//             nesting map. Imports COMPSET_HANDLERS / KNOWN_COMPSETS
//             / dispatchCompset from the parser-compset-registry cog.
//
// HLO item IDs follow a stable prefix convention (the "trait id"):
//   ac* ArmorClass    sk* Skill        wp* Weapon
//   an* Ancestry      sp* Spell        am* Ammunition (nested)
//   ar* Armor         sv* Save         at* ArmorTrait (nested)
//   as* AbilScore     mv* Movement     wt* WeaponTrait (nested)
//   au* Augmentation  rv* Reserves     ab* Ability (nested)
//   cl* Class         ft* Feat
//   dei* Deity        hr* Heritage
//   ln* Language
// The prefix-to-compset mapping is informative, not authoritative; the
// 'compset' field on each item is the source of truth.

import { COMPSET_HANDLERS, KNOWN_COMPSETS, dispatchCompset } from "./parser-compset-registry.js";

/**
 * @param {object} rawItems   Raw `actor.items` block, keyed by HLO item id.
 * @param {Array}  warnings   Shared warning accumulator (mutated).
 * @returns {{
 *   items: Array<object>,                    // flat list of normalized items
 *   itemTree: { [parentId: string]: string[] } // parentId -> array of childIds
 * }}
 */
export function parseItems(rawItems, warnings) {
  const items = [];
  const itemTree = {};

  walk(rawItems, null, items, itemTree, warnings);

  return { items, itemTree };
}

function walk(rawItems, parentId, outItems, outTree, warnings) {
  for (const [id, raw] of Object.entries(rawItems)) {
    const compset = raw.compset;
    const traitIds = parseTraitList(raw.Trait);
    const containment = raw.containment ?? null;
    // Item IDs follow `<slug>.<sequenceN>`; the slug portion is the stable
    // identifier that maps to PF2e/SF2e compendium slugs.
    const slug = typeof id === "string" && id.includes(".") ? id.split(".")[0] : id;
    const normalized = {
      id,
      slug,
      compset,
      name: raw.name ?? null,
      parentId,
      containment,
      traitIds,
      useInPlay: raw.useInPlay ?? null,
      raw,
    };

    if (KNOWN_COMPSETS.has(compset)) {
      const handler = COMPSET_HANDLERS[compset];
      if (handler && typeof handler.normalize === "function") {
        // v0.7.1: surface the slug on raw so handlers that classify
        // by id prefix (Rune, Material) can recover the target type
        // without changing the normalize() signature.
        raw._slug = slug;
        Object.assign(normalized, handler.normalize(raw, warnings));
      }
    } else if (compset != null) {
      warnings.push({
        code: "unknown-compset",
        message: `Unknown compset "${compset}" on item ${id} ("${raw.name ?? "?"}"). Falling through with raw data only.`,
        context: { id, compset },
      });
    }

    outItems.push(normalized);
    if (parentId != null) {
      (outTree[parentId] ??= []).push(id);
    }

    if (raw.items && typeof raw.items === "object") {
      walk(raw.items, id, outItems, outTree, warnings);
    }
  }
}

function parseTraitList(traitField) {
  if (!traitField || typeof traitField !== "string") return [];
  return traitField.split(",").map((s) => s.trim()).filter(Boolean);
}

// Re-export for convenience.
export { dispatchCompset, KNOWN_COMPSETS };

export default { id: "parser-items" };
