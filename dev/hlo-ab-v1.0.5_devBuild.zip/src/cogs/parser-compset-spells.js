// ============================================================
// COG: parser-compset-spells.js - Spell normalizer
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.2.0
//           - v1.0.5: surfaced trkMaximum and stAbScModifier so
//             builder-spellcasting can size prepared slots (trkMaximum
//             is HLO's per-rank prepared count, the "(x2)" notation)
//             and derive the casting ability by matching the spell's
//             ability modifier against the actor's ability scores.
//           - Migrated from src/parser/compsets/spells.js as part of
//             the cog architecture pivot. Captures rank, DC, range,
//             target, and save fields HLO surfaces. Spell-attack
//             proficiency lives on the Spell item (proLevelBonNet)
//             and is wired through the builder when spellcasting
//             entries take shape.

export const Spell = {
  normalize(raw, _warnings) {
    return {
      spLevelBase:      raw.spLevelBase ?? null,
      spLevelNet:       raw.spLevelNet ?? null,
      proLevelBonNet:   raw.proLevelBonNet ?? null,
      stNet:            raw.stNet ?? null,
      stDC:             raw.stDC ?? null,
      stAbScModifier:   raw.stAbScModifier ?? null,
      trkMaximum:       raw.trkMaximum ?? null,
      vaSave:           raw.vaSave ?? null,
      vaRangeText:      raw.vaRangeText ?? null,
      vaTarget:         raw.vaTarget ?? null,
      actionRaw:        raw.Action ?? null,
    };
  },
};

export default { id: "parser-compset-spells" };
