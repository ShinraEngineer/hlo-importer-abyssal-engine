// ============================================================
// COG: api-token-cache.js - In-memory HLO access-token cache
//                           (50-min TTL, module-scoped singleton)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.2.0
//           - Wave 4 of the cog migration. Promoted from
//             src/api/access-token-cache.js. Internal import
//             repointed at sibling cog ./api-hlo-client.js. No
//             logic changes.
//           - 0.1.0: Phase 4 (in src/api/). In-memory access
//             token cache. The HLO Public API issues access
//             tokens via /v1/access/acquire-access-token using
//             the user-level JWT refresh token. Access tokens
//             are nominal 1-2 hours; we cache aggressively (50
//             minutes default) to avoid redundant exchange
//             calls during a single Foundry session.
//
// The cache is intentionally module-scoped, not actor-scoped. One user
// account, one access token; element tokens (which are per-character) ride
// on top of the same access token.

import { acquireAccessToken } from "./api-hlo-client.js";

const DEFAULT_TTL_MS = 50 * 60 * 1000;

export class AccessTokenCache {
  #token = null;
  #expiresAt = 0;
  #ttlMs;
  #userToken = null;

  constructor({ ttlMs = DEFAULT_TTL_MS } = {}) {
    this.#ttlMs = ttlMs;
  }

  /**
   * Return a fresh access token, exchanging the user token only when the
   * cache is empty or expired. Pass the same user token each call; if a
   * different user token comes in, the cache is invalidated.
   */
  async get(userToken) {
    if (!userToken) throw new Error("AccessTokenCache.get: userToken is required.");
    const now = Date.now();
    if (this.#token && now < this.#expiresAt && this.#userToken === userToken) {
      return this.#token;
    }
    const fresh = await acquireAccessToken(userToken);
    this.#token = fresh;
    this.#expiresAt = now + this.#ttlMs;
    this.#userToken = userToken;
    return fresh;
  }

  invalidate() {
    this.#token = null;
    this.#expiresAt = 0;
    this.#userToken = null;
  }
}

// A module-scoped singleton for convenience. Most callers want this.
export const tokenCache = new AccessTokenCache();
