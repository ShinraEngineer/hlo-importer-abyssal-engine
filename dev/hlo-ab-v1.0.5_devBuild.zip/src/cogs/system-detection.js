// ============================================================
// COG: system-detection.js - SF2e vs PF2e identification
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.2.0
//           - Renamed from system-detection.cog.js to plain
//             system-detection.js to mirror the abyssalEngine webapp
//             cog convention (cogs are *.js in cogs/, banner-comment
//             header, files starting with _ are skipped).
//           - 0.1.0: Initial cog. Single source of truth for SF2e
//             class identification + system inference. Replaces the
//             duplicate SF2E_CLASS_SLUGS sets that previously lived
//             in src/parser/parse-actor.js AND src/parser/compsets/
//             class.js (the duplication caused the Soldier-detection
//             bug: clSoldier was missing from one set so Soldier
//             characters classified as pf2e and the matcher returned
//             zero hits). Both consumers now import from this cog.

/**
 * The complete set of HLO class slugs that identify a Starfinder 2e
 * class. Player Core (7) plus Field Test playtest classes (2). Update
 * here only - this is the single source of truth.
 */
export const SF2E_CLASS_SLUGS = new Set([
  // Player Core
  "clOperative", "clSoldier", "clMystic", "clTechnomancer",
  "clSolarian", "clEnvoy", "clWitchwarper",
  // Field Test / playtest
  "clMechanic", "clVanguard",
]);

/**
 * Compsets that only exist in SF2e. Used as an additional system
 * signal in inferSystem() below.
 */
export const SF2E_ONLY_COMPSETS = new Set(["Augmentation", "Upgrade"]);

/** True if the given HLO class slug identifies a Starfinder 2e class. */
export function isSf2eClassSlug(slug) {
  return SF2E_CLASS_SLUGS.has(slug);
}

/**
 * Infer system (sf2e | pf2e) from an array of parsed items. HLO labels
 * both gamecodes as "pf2", so we look at class trait identifiers and
 * SF2e-only compsets as discriminators.
 *
 * @param {Array<{compset:string, traitIds?:string[]}>} items  Parsed items.
 * @returns {"sf2e" | "pf2e"}
 */
export function inferSystem(items, _gameValues, _warnings) {
  let sf2eSignals = 0;
  for (const item of items) {
    if (item.compset === "Class" && item.traitIds?.some((t) => SF2E_CLASS_SLUGS.has(t))) {
      sf2eSignals += 2;
    }
    if (SF2E_ONLY_COMPSETS.has(item.compset)) {
      sf2eSignals += 1;
    }
  }
  return sf2eSignals > 0 ? "sf2e" : "pf2e";
}

// Cog metadata. Cogs without runtime lifecycle hooks (init/ready)
// still export a default with at least an id so the registry has a
// uniform shape.
export default {
  id: "system-detection",
};
