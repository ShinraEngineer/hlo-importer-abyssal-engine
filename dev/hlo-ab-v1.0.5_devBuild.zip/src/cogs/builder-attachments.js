// ============================================================
// COG: builder-attachments.js - Item attachment plan + apply
//                               (ammo, runes, traits, upgrades)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.3.0
//           - Embed weapon/armor upgrades and weapon ammo as
//             PARENT.system.subitems[] entries rather than free-
//             floating actor items. This is the native SF2e/PF2e
//             attachment shape (see sf2e.mjs:50573 prepareBaseData,
//             where each subitem source becomes an ItemProxyPF2e
//             with `parentItem: this`). Restoring it eliminates
//             the ~30 per-import "Failed to resolve injected
//             property parentItem.id" warnings that Bipod and
//             other attachments emit when their rule elements
//             reference {item|parentItem.id} on a top-level
//             actor item with no parent context.
//           - 0.2.0: Wave 3 of the cog migration. Promoted from
//             src/builder/build-attachments.js. No logic changes;
//             only the file location and header are new.
//           - 0.1.0: Phase 3 (in src/builder/). Item attachment
//             resolver. Walks the actor's itemTree and produces
//             attachment metadata that the import dialog will
//             apply once items have been created in Foundry.
//             Without this step, nested items (weapon ammo,
//             armor upgrades, weapon traits) land on the actor
//             disconnected from their parents.
//
// PF2e/SF2e Foundry attachment patterns this layer is aware of:
//   - Weapon/armor upgrades + weapon ammo: parent's system.subitems[]
//     holds the child's source object. The parent's prepareBaseData
//     constructs each subitem as an ItemProxyPF2e with parentItem set
//     to the parent, which is what makes rule-element injection
//     tokens like {item|parentItem.id} resolve. Without this, top-
//     level upgrades fire ~30 warning logs per import.
//   - Weapon and armor traits: typically already baked into the
//     compendium item; nested HLO trait items duplicate that information
//     and can be safely dropped after their data has been merged into
//     the parent's flags.
//
// The actual attachment wire-up happens in the import dialog's
// resolveSkeletonForCreate, since that step has access to the created
// document IDs. This cog produces the *plan* (a list of operations),
// not the side effects.

/**
 * @typedef {Object} AttachmentPlan
 * @property {"ammo" | "armor-upgrade" | "weapon-trait" | "armor-trait" | "weapon-upgrade" | "augmentation" | "drop"} kind
 * @property {string} parentHloId
 * @property {string} childHloId
 * @property {string} childCompset
 * @property {string} childName
 */

/**
 * Build the list of attachment operations from the parser's itemTree.
 *
 * @param {object} actorIR        ActorIR from parseActor.
 * @returns {AttachmentPlan[]}
 */
export function buildAttachmentPlan(actorIR) {
  const out = [];
  const itemsByid = new Map(actorIR.items.map((it) => [it.id, it]));

  for (const item of actorIR.items) {
    if (!item.parentId) continue;
    const parent = itemsByid.get(item.parentId);
    if (!parent) continue;

    const kind = classifyAttachment(parent.compset, item.compset);
    if (!kind) continue;

    out.push({
      kind,
      parentHloId: parent.id,
      childHloId: item.id,
      childCompset: item.compset,
      childName: item.name ?? null,
    });
  }
  return out;
}

function classifyAttachment(parentCompset, childCompset) {
  if (parentCompset === "Weapon" && childCompset === "Ammunition") return "ammo";
  if (parentCompset === "Weapon" && childCompset === "WeaponTrait") return "weapon-trait";
  if (parentCompset === "Weapon" && childCompset === "Upgrade")     return "weapon-upgrade";
  if (parentCompset === "Armor"  && childCompset === "Upgrade")     return "armor-upgrade";
  if (parentCompset === "Armor"  && childCompset === "ArmorTrait")  return "armor-trait";
  if (parentCompset === "Armor"  && childCompset === "Ability")     return "armor-upgrade"; // Foundry stores environmental protection as an upgrade-like ability
  if (parentCompset === "Weapon" && childCompset === "Ability")     return "weapon-trait";
  return null;
}

/**
 * Apply an attachment plan to the resolved Foundry items array. Mutates and
 * returns the array. The plan is keyed by HLO IDs; the items have those IDs
 * recorded in flags["hlo-importer-abyssal-engine-dev"].hlo.id from the
 * compendium-reference resolver step.
 *
 * Each kind has a different wire-up:
 *   - ammo: embed the ammo child's source into parent.system.subitems[]
 *     and set parent.system.selectedAmmoId to that subitem's _id. The
 *     child is dropped from the actor-level item list because it now
 *     lives inside the parent weapon as a subitem.
 *   - weapon-trait, armor-trait: drop the child (parent already carries it)
 *   - weapon-upgrade, armor-upgrade: embed the upgrade child's source
 *     into parent.system.subitems[] so SF2e/PF2e's prepareBaseData
 *     constructs the child as a subitem with parentItem set to the
 *     parent weapon/armor. This is what makes rule-element injection
 *     tokens like {item|parentItem.id} resolve at prepare time. The
 *     child is dropped from the actor-level item list.
 *   - augmentation: leave both items as actor-level items (augments are
 *     not weapon/armor subitems; they attach to the actor itself).
 */
export function applyAttachmentPlan(resolvedItems, plan, moduleId) {
  const byHlo = new Map();
  for (const it of resolvedItems) {
    const hloId = it.flags?.[moduleId]?.hlo?.id;
    if (hloId) byHlo.set(hloId, it);
  }

  const toDrop = new Set();

  for (const op of plan) {
    const parent = byHlo.get(op.parentHloId);
    const child = byHlo.get(op.childHloId);
    if (!parent || !child) continue;

    switch (op.kind) {
      case "ammo": {
        const subitemId = embedAsSubitem(parent, child, moduleId, op);
        parent.system ??= {};
        parent.system.selectedAmmoId = subitemId ?? child._id ?? null;
        toDrop.add(child);
        break;
      }
      case "weapon-trait":
      case "armor-trait":
        // The compendium parent already carries these traits; the nested
        // HLO trait item is redundant. Drop the child after recording the
        // attachment intent in the parent flags for diagnostics.
        parent.flags ??= {};
        parent.flags[moduleId] ??= {};
        parent.flags[moduleId].nestedTraits ??= [];
        parent.flags[moduleId].nestedTraits.push({
          compset: op.childCompset,
          name: op.childName,
        });
        toDrop.add(child);
        break;
      case "weapon-upgrade":
      case "armor-upgrade": {
        // Wire the upgrade as a real SF2e/PF2e subitem on the parent.
        // Without this, the upgrade lands as a standalone actor item
        // whose rule elements cannot resolve {item|parentItem.id}.
        embedAsSubitem(parent, child, moduleId, op);
        toDrop.add(child);
        break;
      }
      case "drop":
        toDrop.add(child);
        break;
      default:
        break;
    }
  }

  if (toDrop.size === 0) return resolvedItems;
  return resolvedItems.filter((it) => !toDrop.has(it));
}

/**
 * Push a deep-cloned child item source into parent.system.subitems[],
 * shaped the way SF2e/PF2e's weapon/armor prepareBaseData expects
 * (see sf2e.mjs:50573 - it iterates parent.system.subitems and for
 * each entry constructs a new ItemProxyPF2e with parentItem set to
 * the parent). Returns the subitem's _id, or null if the parent does
 * not support attachments (e.g. it's already a subitem itself, or the
 * type isn't weapon/armor/equipment/shield).
 *
 * Skips silently when the child source has no _id - upstream
 * resolveSkeletonForCreate pulls items via doc.toObject() which
 * always carries the compendium _id, so this should never trip in
 * normal use, but the guard avoids producing an invalid subitem
 * entry that SF2e's _initialize would crash on.
 */
function embedAsSubitem(parent, child, moduleId, op) {
  if (!parent || !child) return null;
  // Only weapon/armor/equipment/shield host subitems. Equipment is
  // included for augmentation-like attachments that legitimately
  // could live as subitems (currently routed through "augmentation"
  // which keeps them top-level; reserved for future use).
  const parentType = parent.type;
  if (!parentType || !["weapon", "armor", "equipment", "shield"].includes(parentType)) {
    return null;
  }
  parent.system ??= {};
  parent.system.subitems = Array.isArray(parent.system.subitems)
    ? parent.system.subitems
    : [];
  // Avoid double-adding the same child if applyAttachmentPlan is
  // somehow re-run on a partially-built skeleton.
  const subitemId = child._id ?? null;
  if (subitemId && parent.system.subitems.some((s) => s?._id === subitemId)) {
    return subitemId;
  }
  // Deep-clone to keep the actor-level items array's child (if any
  // other code path inspects it) untouched, and to avoid two consumers
  // mutating the same object reference.
  const cloned = deepCloneItemSource(child);
  // SF2e/PF2e expect subitems to declare their carry/equip state in
  // sync with the parent. The system rewrites equipped.carryType from
  // the parent's equipped block during prepareBaseData (sf2e.mjs:50574
  // - subitemSource.system.equipped = pick(this.system.equipped,
  // ["carryType", "handsHeld"])) but we still seed sensible defaults
  // so older fixtures or non-equipped parents don't crash.
  cloned.system ??= {};
  cloned.system.equipped ??= {};
  const usageType = cloned.system.usage?.type
    ?? cloned.system.usage?.value
    ?? "attached";
  const validCarryTypes = ["attached", "installed"];
  cloned.system.equipped.carryType = validCarryTypes.find((c) => c === usageType)
    ?? "attached";
  cloned.system.equipped.handsHeld ??= 0;
  // Record the parent linkage in our module flag so re-import cleanup
  // and diagnostics can trace which actor-level weapon owns this
  // subitem.
  cloned.flags ??= {};
  cloned.flags[moduleId] ??= {};
  cloned.flags[moduleId].attachedTo = {
    hloParentId: op?.parentHloId ?? null,
    parentName: parent.name ?? null,
  };
  parent.system.subitems.push(cloned);
  return cloned._id ?? null;
}

/**
 * Structured-clone an item source. Foundry's deepClone is preferred when
 * available (handles its own Collection/Set quirks); otherwise fall back
 * to structuredClone, then JSON-roundtrip as a last resort. We never
 * want a shallow reference sneaking through, because mutating the
 * parent.system.subitems[i] later would otherwise also mutate the
 * top-level item the caller may still hold a reference to.
 */
function deepCloneItemSource(source) {
  try {
    if (typeof foundry !== "undefined" && foundry?.utils?.deepClone) {
      return foundry.utils.deepClone(source);
    }
  } catch { /* fall through */ }
  try {
    if (typeof structuredClone === "function") return structuredClone(source);
  } catch { /* fall through */ }
  return JSON.parse(JSON.stringify(source));
}
