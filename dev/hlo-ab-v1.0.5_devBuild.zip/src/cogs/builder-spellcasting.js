// ============================================================
// COG: builder-spellcasting.js - Spellcasting entry synthesizer
//                                shared by PF2e and SF2e actors
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-30
// Revision: 0.1.0
//           - New cog. Closes the original spell-import gap: the
//             importer matched and embedded every spell but never
//             created the spellcastingEntry container or set each
//             spell's system.location.value, so PF2e/SF2e filtered
//             all spells off the Spells tab (orphans). Verified
//             against the Berial Jeggare PFS export, whose 66
//             imported spells all carried location.value=null with
//             zero spellcastingEntry on the actor.
//           - Pre-embed half (buildSpellcastingEntries) runs next to
//             assignFeatLocations in the dialog resolver: it dedupes
//             the known-spellbook and prepared-loadout copies HLO
//             ships separately, creates one prepared entry per caster
//             tradition plus a focus entry when focus spells exist,
//             and stashes a slot plan on each entry's module flag.
//           - Post-embed half lives in the dialog (_finalizeSpellcasting)
//             because prepared slots reference embedded spell _ids
//             that only exist after createEmbeddedDocuments runs.
//           - PF2e and SF2e share the spellcastingEntry/spell schema
//             verbatim (SF2e is a PF2e fork), so one code path covers
//             both; only the default entry icon path is system-aware.

import { MODULE_ID } from "./util-version.js";

// HLO trait token -> Foundry spell tradition. HLO stamps the caster's
// tradition on every prepared spell's Trait CSV (trdArcane, trdDivine,
// trdOccult, trdPrimal). Spellbook children instead carry school tags
// (ssEvocation, etc.) and no trd* token, so tradition is read off the
// prepared copies and the focus spell when present.
const TRAD_TOKEN_TO_TRADITION = {
  trdArcane: "arcane",
  trdDivine: "divine",
  trdOccult: "occult",
  trdPrimal: "primal",
};

// Sane casting-ability default per tradition when the precise ability
// cannot be derived from HLO ability-score modifiers. Refined below by
// matching the spell's stAbScModifier against the actor's AbilScore set.
const TRADITION_DEFAULT_ABILITY = {
  arcane: "int",
  divine: "wis",
  occult: "cha",
  primal: "wis",
};

// HLO ability-score slug -> Foundry ability key.
const ABIL_SLUG_TO_KEY = {
  asStr: "str", asDex: "dex", asCon: "con",
  asInt: "int", asWis: "wis", asCha: "cha",
};

/**
 * Build spellcasting entries for the resolved actor items, dedupe the
 * known/prepared spell copies HLO ships separately, and anchor every
 * spell to its entry. Mutates `resolvedItems` in place: drops duplicate
 * spell documents, appends one or more spellcastingEntry objects, and
 * pre-sets each surviving spell's system.location.value. The authoritative
 * anchoring + prepared-slot wiring happens post-embed in the dialog using
 * the slot plan stashed on each entry's flags[MODULE_ID].spellcasting.
 *
 * @param {Array}  resolvedItems Resolved Foundry item source objects (mutated).
 * @param {Array}  hloItems      Parsed HLO actor IR items (for spLevelNet,
 *                               trkMaximum, traitIds, ability scores).
 * @param {Function} pushDebug   Optional per-decision debug logger.
 * @returns {{entries:number, anchored:number, dropped:number}|null}
 */
export function buildSpellcastingEntries(resolvedItems, hloItems = [], pushDebug = () => {}) {
  if (!Array.isArray(resolvedItems) || resolvedItems.length === 0) return null;

  const irById = new Map();
  for (const ir of Array.isArray(hloItems) ? hloItems : []) {
    if (ir?.id != null) irById.set(ir.id, ir);
  }

  // Decorate every resolved spell with the HLO facts we need.
  const spellDocs = [];
  for (const obj of resolvedItems) {
    if (obj?.type !== "spell") continue;
    const hlo = obj.flags?.[MODULE_ID]?.hlo ?? {};
    const ir = hlo.id != null ? irById.get(hlo.id) : null;
    const traits = obj.system?.traits?.value ?? [];
    const baseRank = Number(obj.system?.level?.value ?? 0);
    spellDocs.push({
      obj,
      slug: obj.system?.slug ?? slugifyName(obj.name),
      containment: hlo.containment ?? null,          // "Installed" => known spellbook child
      compset: ir?.compset ?? null,                  // "Spell" | "FocSpell"
      traitIds: Array.isArray(hlo.traitIds) ? hlo.traitIds : (ir?.traitIds ?? []),
      isCantrip: traits.includes("cantrip") || baseRank === 0,
      isFocus: traits.includes("focus") || (ir?.compset === "FocSpell"),
      baseRank,
      // Prepared slot rank is the heightened rank HLO records as spLevelNet;
      // fall back to the spell's own base rank when the IR is unavailable.
      slotRank: Number(ir?.spLevelNet ?? obj.system?.level?.value ?? 0),
      preparedCount: Number(ir?.trkMaximum ?? 1) || 1,
      profBonus: Number(ir?.proLevelBonNet ?? 0) || 0,
      abilMod: Number(ir?.stAbScModifier ?? NaN),
    });
  }
  if (spellDocs.length === 0) return null;

  const focusDocs = spellDocs.filter((s) => s.isFocus);
  const castDocs = spellDocs.filter((s) => !s.isFocus);

  const toRemove = new Set();
  let entriesCreated = 0;
  let anchored = 0;

  // --- Prepared / spontaneous spellbook entry ---------------------------
  if (castDocs.length > 0) {
    const tradition = deriveTradition(castDocs, irById);
    const ability = deriveAbility(castDocs, hloItems, tradition);
    const profBonus = Math.max(0, ...castDocs.map((s) => s.profBonus));
    const entryId = newId();

    // Dedupe by slug: keep the known spellbook child when present (it is
    // the canonical document the prepared slots reference); record the
    // prepared loadout (rank + count) from the top-level prepared copies.
    const keepersBySlug = new Map();   // slug -> keeper doc descriptor
    const preparedBySlug = new Map();  // slug -> { rank, count }
    for (const s of castDocs) {
      const existing = keepersBySlug.get(s.slug);
      if (!existing) {
        keepersBySlug.set(s.slug, s);
      } else {
        // Prefer the spellbook child (containment "Installed") as keeper.
        const keep = existing.containment === "Installed" ? existing : s;
        const drop = keep === existing ? s : existing;
        keepersBySlug.set(s.slug, keep);
        toRemove.add(drop.obj);
      }
      // Any top-level (non-Installed) leveled copy defines a prepared slot.
      if (s.containment !== "Installed" && !s.isCantrip) {
        const prior = preparedBySlug.get(s.slug);
        preparedBySlug.set(s.slug, {
          rank: s.slotRank || s.baseRank || 1,
          count: Math.max(prior?.count ?? 0, s.preparedCount),
        });
      }
    }

    const cantripSlugs = [];
    for (const [slug, keeper] of keepersBySlug) {
      keeper.obj.system = keeper.obj.system ?? {};
      keeper.obj.system.location = { value: entryId };
      anchored += 1;
      if (keeper.isCantrip) cantripSlugs.push(slug);
    }

    const prepared = [...preparedBySlug.entries()].map(([slug, p]) => ({
      slug, rank: p.rank, count: p.count,
    }));

    resolvedItems.push(makeEntry({
      entryId, name: "Spellbook", kind: "prepared", tradition, ability,
      profBonus, prepared, cantrips: cantripSlugs,
    }));
    entriesCreated += 1;
    pushDebug(
      `Spellcasting: built prepared ${tradition} entry (ability ${ability}); ` +
      `${keepersBySlug.size} known spell(s), ${prepared.length} prepared leveled slot(s), ` +
      `${cantripSlugs.length} cantrip(s). Deduped ${toRemove.size} duplicate copy(ies).`,
    );
  }

  // --- Focus entry ------------------------------------------------------
  if (focusDocs.length > 0) {
    const tradition = deriveTradition(focusDocs, irById);
    const ability = deriveAbility(focusDocs, hloItems, tradition);
    const entryId = newId();
    const keepersBySlug = new Map();
    for (const s of focusDocs) {
      const existing = keepersBySlug.get(s.slug);
      if (existing) { toRemove.add(s.obj); continue; }
      keepersBySlug.set(s.slug, s);
      s.obj.system = s.obj.system ?? {};
      s.obj.system.location = { value: entryId };
      anchored += 1;
    }
    resolvedItems.push(makeEntry({
      entryId, name: "Focus Spells", kind: "focus", tradition, ability,
      profBonus: Math.max(0, ...focusDocs.map((s) => s.profBonus)),
      prepared: [], cantrips: [],
      focusCount: Math.min(3, keepersBySlug.size),
    }));
    entriesCreated += 1;
    pushDebug(
      `Spellcasting: built focus ${tradition} entry (ability ${ability}); ` +
      `${keepersBySlug.size} focus spell(s); focus pool ${Math.min(3, keepersBySlug.size)}.`,
    );
  }

  // Drop the duplicate documents from the embed list.
  let dropped = 0;
  if (toRemove.size > 0) {
    for (let i = resolvedItems.length - 1; i >= 0; i--) {
      if (toRemove.has(resolvedItems[i])) { resolvedItems.splice(i, 1); dropped += 1; }
    }
  }

  return { entries: entriesCreated, anchored, dropped };
}

/**
 * Read the slot plan a spellcasting entry carries on its module flag.
 * Used by the dialog's post-embed finalizer.
 */
export function getEntryPlan(entry) {
  return entry?.flags?.[MODULE_ID]?.spellcasting ?? null;
}

/**
 * Build the system.slots block for a prepared entry from its stashed
 * plan plus a slug -> embedded-spell-_id map (resolved post-embed).
 * slot0 holds every anchored cantrip; slotN holds the prepared loadout
 * at rank N. Empty ranks get a zeroed slot so the sheet renders cleanly.
 */
export function buildPreparedSlots(plan, idBySlug) {
  const slots = {};
  for (let r = 0; r <= 10; r++) slots[`slot${r}`] = { max: 0, prepared: {} };

  // slot0: all known cantrips, all auto-prepared.
  const cantripIds = (plan?.cantrips ?? [])
    .map((slug) => idBySlug.get(slug))
    .filter(Boolean);
  slots.slot0.max = cantripIds.length;
  cantripIds.forEach((id, i) => { slots.slot0.prepared[String(i)] = { id, expended: false }; });

  // slotN: prepared leveled loadout, one prepared entry per copy (count).
  const byRank = new Map();
  for (const p of plan?.prepared ?? []) {
    const id = idBySlug.get(p.slug);
    if (!id) continue;
    const rank = Math.min(10, Math.max(1, Number(p.rank) || 1));
    const list = byRank.get(rank) ?? [];
    for (let c = 0; c < (Number(p.count) || 1); c++) list.push(id);
    byRank.set(rank, list);
  }
  for (const [rank, ids] of byRank) {
    const key = `slot${rank}`;
    slots[key].max = ids.length;
    ids.forEach((id, i) => { slots[key].prepared[String(i)] = { id, expended: false }; });
  }
  return slots;
}

// --- internals ----------------------------------------------------------

function makeEntry({ entryId, name, kind, tradition, ability, profBonus, prepared, cantrips, focusCount }) {
  const slots = {};
  for (let r = 0; r <= 10; r++) slots[`slot${r}`] = { max: 0, prepared: {} };
  return {
    _id: entryId,
    name,
    type: "spellcastingEntry",
    img: "icons/sundries/books/book-embossed-jeweled-gold-purple.webp",
    system: {
      ability: { value: ability },
      spelldc: { value: 0, dc: 0, mod: 0 },
      tradition: { value: tradition },
      prepared: { value: kind === "focus" ? "focus" : "prepared", flexible: false },
      showSlotlessLevels: { value: false },
      proficiency: { value: 1 },
      slots,
      autoHeightenLevel: { value: null },
    },
    flags: {
      [MODULE_ID]: {
        // Slot plan + raw HLO derivations consumed post-embed once the
        // spells have real _ids. profBonus -> proficiency rank is finished
        // there because it needs the live actor level.
        spellcasting: { kind, tradition, ability, profBonus, prepared, cantrips, focusCount: focusCount ?? 0 },
      },
      pf2e: {},
    },
  };
}

// Derive the caster tradition from the trd* tokens on the spells' HLO
// trait lists; fall back to the most common spell tradition, then arcane.
function deriveTradition(docs, irById) {
  const tally = {};
  for (const s of docs) {
    for (const t of s.traitIds ?? []) {
      const trad = TRAD_TOKEN_TO_TRADITION[t];
      if (trad) tally[trad] = (tally[trad] ?? 0) + 1;
    }
  }
  let best = null;
  let bestN = 0;
  for (const [trad, n] of Object.entries(tally)) {
    if (n > bestN) { best = trad; bestN = n; }
  }
  if (best) return best;
  // Fall back to a tradition the spell docs themselves declare.
  for (const s of docs) {
    const trads = s.obj.system?.traits?.traditions ?? [];
    if (trads.length === 1) return trads[0];
  }
  return "arcane";
}

// Casting ability: match a spell's stAbScModifier against the actor's
// AbilScore items to find which ability drives spellcasting; fall back
// to the tradition default (arcane->int, divine->wis, etc).
function deriveAbility(docs, hloItems, tradition) {
  const target = docs.map((s) => s.abilMod).find((m) => Number.isFinite(m));
  if (Number.isFinite(target)) {
    for (const ir of Array.isArray(hloItems) ? hloItems : []) {
      if (ir?.compset !== "AbilScore") continue;
      const key = ABIL_SLUG_TO_KEY[ir.slug];
      const mod = Number(ir.stAbScModifier);
      if (key && Number.isFinite(mod) && mod === target) return key;
    }
  }
  return TRADITION_DEFAULT_ABILITY[tradition] ?? "int";
}

// Foundry's randomID at runtime; deterministic-length fallback otherwise.
function newId() {
  if (typeof foundry !== "undefined" && foundry?.utils?.randomID) {
    return foundry.utils.randomID();
  }
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let id = "";
  for (let i = 0; i < 16; i++) id += chars[Math.floor(Math.random() * chars.length)];
  return id;
}

function slugifyName(name) {
  return String(name ?? "")
    .toLowerCase()
    .replace(/['’]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export default { id: "builder-spellcasting" };
