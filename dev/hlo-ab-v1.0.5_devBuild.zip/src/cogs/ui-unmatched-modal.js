// ============================================================
// COG: ui-unmatched-modal.js - End-of-import "unmatched items"
//                              modal dialog (ApplicationV2)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - Initial cut. Replaces the "small line in the
//             conversion log" UX for unmatched-item warnings.
//             Field reports were that users would close the
//             import dialog without realizing 4-6 items needed
//             manual addition, then open the sheet and find it
//             "missing things." The conversion log read fine to
//             a developer but disappeared from view the moment
//             the dialog closed.
//
//             showUnmatchedModal(unmatchedItems, options)
//             returns a Promise that resolves when the user
//             dismisses the modal, either via the X close button
//             in the title bar or via the explicit "I Understand"
//             primary action. The dialog is rendered modally
//             (above the actor sheet) and the user cannot
//             interact with anything else on the page until they
//             acknowledge it.
//
//             We build it as an ApplicationV2 + Handlebars-
//             ApplicationMixin subclass rather than reaching for
//             foundry.applications.api.DialogV2 because DialogV2
//             is optimized for short Yes/No prompts and the data
//             table we want to render (compset / name / slug /
//             suggested pack per row) is awkward in its content
//             slot. The subclass gives us a real template, real
//             CSS hooks, and the standard ApplicationV2 actions
//             map for the I-Understand button. The conversion-
//             log path remains untouched so debug-level users
//             still get the per-line warn entries.
//
// Contract:
//   showUnmatchedModal(unmatchedItems, options) -> Promise<void>
//     unmatchedItems: Array<{
//       compset: string,        // "Ancestry", "Feat", "Spell", ...
//       name:    string,        // HLO display name
//       slug:    string,        // HLO slug (abFoo, ftBar, ...)
//       suggestedPack: string|null, // best-guess Foundry pack id
//     }>
//     options.actorName: string  // imported actor's name
//     options.systemId:  "pf2e" | "sf2e" | string
//
//   The promise resolves with no value once the modal has been
//   acknowledged or closed. It never rejects.

import { MODULE_ID } from "./util-version.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

/**
 * Internal ApplicationV2 subclass. Not exported; the public surface
 * is the showUnmatchedModal() helper below, which constructs an
 * instance, wires a resolver to its dismiss path, and returns the
 * promise. Consumers should not new-up this class directly.
 */
class HLOUnmatchedModal extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "hlo-unmatched-modal",
    classes: ["abyssal-engine", "hlo-unmatched"],
    tag: "div",
    window: {
      title: "HLO Import: Items Need Manual Attention",
      icon: "fa-solid fa-triangle-exclamation",
      resizable: true,
      // contentClasses lets the surrounding window CSS know this is
      // our modal so the elevated z-index rule in styles/import-
      // dialog.css can target it without bleeding to other apps.
      contentClasses: ["hlo-unmatched-window"],
    },
    // Wider than the import dialog (720) so the four-column table
    // does not have to scroll horizontally on typical builds.
    position: { width: 760, height: "auto" },
    actions: {
      acknowledge: HLOUnmatchedModal._onAcknowledge,
    },
  };

  static PARTS = {
    body: {
      template: `modules/${MODULE_ID}/templates/unmatched-modal.hbs`,
    },
  };

  _items = [];
  _actorName = "";
  _systemId = "";
  // Resolver wired in by showUnmatchedModal() before render. Called
  // exactly once on the first dismiss path (acknowledge OR close).
  // The _resolved guard prevents the close hook from double-firing
  // resolve when acknowledge already did.
  _resolve = null;
  _resolved = false;

  async _prepareContext(_options) {
    return {
      items: this._items,
      itemCount: this._items.length,
      actorName: this._actorName,
      systemId: this._systemId,
    };
  }

  /**
   * Primary-button handler. Closes the dialog (which routes through
   * the close hook below) and resolves the showUnmatchedModal promise.
   * Bound by name in DEFAULT_OPTIONS.actions per V14 ApplicationV2.
   */
  static async _onAcknowledge(_event, _target) {
    // `this` is the application instance per ApplicationV2's
    // documented click-handler binding. Resolve first, then close,
    // so the promise consumer knows the modal is going away even
    // if the close call queues asynchronously.
    if (!this._resolved && typeof this._resolve === "function") {
      this._resolved = true;
      this._resolve();
    }
    await this.close();
  }

  /**
   * Catch the X-close-button path. ApplicationV2 calls _onClose on
   * every dismissal route (close button, programmatic close, ESC if
   * the window is focused). We resolve here too so the promise
   * settles whether the user clicks "I Understand" or hits the X.
   */
  async _onClose(options) {
    if (!this._resolved && typeof this._resolve === "function") {
      this._resolved = true;
      this._resolve();
    }
    return super._onClose(options);
  }
}

/**
 * Public helper. Render a modal listing the unmatched items the
 * importer could not resolve to a Foundry compendium entry, then
 * wait for the user to acknowledge it.
 *
 * If `unmatchedItems` is empty or falsy this resolves immediately
 * with no UI shown, so end-of-import callsites can call this
 * unconditionally without an outer length check.
 *
 * @param {Array<{ compset: string, name: string, slug: string, suggestedPack: string|null }>} unmatchedItems
 * @param {{ actorName?: string, systemId?: string }} [options]
 * @returns {Promise<void>}
 */
export function showUnmatchedModal(unmatchedItems, options = {}) {
  const items = Array.isArray(unmatchedItems) ? unmatchedItems : [];
  if (items.length === 0) return Promise.resolve();

  return new Promise((resolve) => {
    const modal = new HLOUnmatchedModal();
    modal._items = items.map((it) => ({
      compset: String(it?.compset ?? "Unknown"),
      name: String(it?.name ?? "(unnamed)"),
      slug: String(it?.slug ?? ""),
      suggestedPack: it?.suggestedPack ?? null,
    }));
    modal._actorName = String(options?.actorName ?? "");
    modal._systemId = String(options?.systemId ?? "");
    modal._resolve = resolve;
    // force: true ensures the modal renders even if a same-id
    // instance is already cached, so re-imports always get a
    // fresh window instead of a silently-closed orphan. The
    // modal "feel" (block other interactions until dismissed)
    // is delivered by the high z-index in styles/import-dialog
    // .css plus the explicit single acknowledgement button; we
    // do not need Foundry's old V1 modal-lock plumbing.
    modal.render({ force: true });
  });
}
