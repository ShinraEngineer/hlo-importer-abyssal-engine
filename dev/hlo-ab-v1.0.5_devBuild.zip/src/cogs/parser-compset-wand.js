// ============================================================
// COG: parser-compset-wand.js - Wand normalizer
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.2.0
//           - v0.7.1 (pass 3, silent-drop fix): surface baseName
//             so slugCandidates step 3.7 (the baseName fallback)
//             produces a `wand-of-<spell-slug>` candidate even
//             when HLO's display-name casing differs from the
//             canonical Foundry entry. Berial PFS's "Wand of cozy
//             cabin" slugifies to "wand-of-cozy-cabin" on the
//             name route (step 3), which is correct, but if a
//             future Foundry release ships the wand under a
//             different display-name casing or with a tier
//             suffix the slug derivation will need the baseName
//             route to recover. baseName here is the wand's
//             canonical Foundry name pattern: "Wand of <Spell>",
//             cased Title-cased so slugifyName normalises
//             cleanly. Non-Wand-shaped names (which is to say:
//             names that do not start with "Wand of ") fall
//             through to a null baseName and the existing slug
//             pipeline still does the work. This unblocks the
//             Bug 2 silent drop from the v0.7.0 Berial PFS log
//             where waWand.1448 returned a null match record
//             and disappeared with no warn line, no modal entry,
//             and no actor item. The dialog's COMPENDIUM_COMPSETS
//             extension (also part of this revision) means a
//             surviving miss now surfaces as a real unmatched
//             warning instead of vanishing.
//           - 0.1.0: New compset cog for v0.7.0. HLO emits magic wands
//             under the "Wand" compset (id prefix "wa"). Berial
//             carries waWand.1448 "Wand of cozy cabin" which
//             holds a nested spCozyCabin.1458 Spell child via
//             containment: "Installed". In PF2e the wand itself
//             is a magic consumable item that lives in
//             pf2e.equipment-srd under the naming convention
//             "wand-of-<spell-slug>" (verified against the
//             pack-index dump: wand-of-cozy-cabin,
//             wand-of-fireball, wand-of-mage-armor, etc.). The
//             Foundry document type is "consumable" with
//             consumableType="wand"; the builder handles the
//             type mapping. This normalizer's job is to
//             surface the underlying spell name so the matcher
//             can derive the right slug.
//
// The slug-derivation path: the display name "Wand of cozy
// cabin" slugifies to "wand-of-cozy-cabin" via the standard
// slugifyName transform (lowercase + non-alphanumeric -> -),
// which matches the canonical compendium slug exactly. The
// existing name-derived candidate in slugCandidates step 3
// does the primary work; the baseName surfaced here is a
// belt-and-braces fallback that fires at slugCandidates step
// 3.7 when the display-name candidate misses. We still extract
// spellName for use by the dialog when the matcher misses (so
// the user sees "Cozy Cabin" as the underlying spell) and for
// any future fuzzy fallback that wants to search by the spell
// name on its own.

/**
 * Extract the spell name from a "Wand of <spell>" display name. Case-
 * insensitive on the "Wand of" prefix; preserves the original case of
 * the spell name for display. Returns null if the name does not follow
 * the "Wand of <spell>" pattern, in which case the matcher relies on
 * the full display name slug alone.
 */
export function extractSpellName(name) {
  if (!name || typeof name !== "string") return null;
  const match = name.match(/^wand\s+of\s+(.+)$/i);
  if (!match) return null;
  return match[1].trim() || null;
}

/**
 * Build the canonical Title-Case base name for a "Wand of <spell>"
 * display name. PF2e equipment-srd ships these as title-cased
 * compendium entries ("Wand of Cozy Cabin", "Wand of Fireball"); HLO
 * sends sentence case ("Wand of cozy cabin"). Both slugify identically
 * via the matcher's slugifyName pipeline, but the title-cased form is
 * what the matcher's normalizeKey-vs-pack-index comparison prefers when
 * an entry has a parenthetical or punctuation that the strip-pass might
 * otherwise drop. Returns null when the name does not start with
 * "Wand of " so non-wand-shaped names fall through to the existing
 * slug pipeline unchanged.
 */
export function wandBaseName(name) {
  const spellName = extractSpellName(name);
  if (!spellName) return null;
  const titled = spellName
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(" ");
  return `Wand of ${titled}`;
}

export const Wand = {
  normalize(raw, _warnings) {
    const spellName = extractSpellName(raw?.name);
    return {
      grBulk:           raw.grBulk ?? null,
      stackQty:         raw.stackQty ?? null,
      // spellName is informational: surfaced to the dialog when
      // the matcher reports a miss so the user sees the
      // underlying spell.
      spellName,
      // baseName feeds slugCandidates step 3.7 (the v0.7.0 baseName
      // fallback that CustomArmor and MagicItem also use). The
      // primary slug-pipeline candidate from the display name still
      // wins on the canonical "Wand of <Spell>" case; this is a
      // belt-and-braces fallback for casing-sensitive lookups and
      // for any future Foundry release where the wand entry's
      // display name changes shape (tier suffix, etc.).
      baseName:         spellName ? wandBaseName(raw?.name) : null,
    };
  },
};

export default { id: "parser-compset-wand" };
