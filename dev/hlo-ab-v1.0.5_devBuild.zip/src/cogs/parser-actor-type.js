// ============================================================
// COG: parser-actor-type.js - Actor-type detection (PC / NPC / minion)
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.1.0
//           - Migrated from src/parser/detect-actor-type.js as part of
//             the cog architecture pivot. Recognizes PF2e/SF2e Foundry
//             actor types (character, npc, familiar) plus animal
//             companion, eidolon, and drone as specialized minion
//             flavors. No external cog imports.
//
// PF2e Foundry actor types: character, npc, hazard, familiar, loot,
//   party, vehicle. SF2e adds: army.
//
// Detection strategy:
//   1. Strong minion signals first (a Familiar class trait, a "Familiar of"
//      name pattern, animal companion / eidolon / drone trait IDs).
//   2. Otherwise fall back to the wave-6 character vs npc heuristic.
//
// PCs typically carry:
//   - A `player` field with a non-empty name
//   - Background and class compsets
//   - Stat-bearing compsets (AbilScore, Save, Skill) sized for a PC
//
// NPCs typically lack:
//   - The `player` field (or it is empty)
//   - A Class compset (creatures are typed by Trait, not Class)
//   - A Background compset
// And often carry NaturalWep without Weapon.

const MINION_NAME_PATTERNS = [
  { pattern: /^familiar of\b/i,         subtype: "familiar" },
  { pattern: /\bfamiliar$/i,            subtype: "familiar" },
  { pattern: /^animal companion of\b/i, subtype: "animal-companion" },
  { pattern: /\banimal companion$/i,    subtype: "animal-companion" },
  { pattern: /\beidolon\b/i,            subtype: "eidolon" },
  { pattern: /\bdrone\b/i,              subtype: "drone" },
];

// HLO trait IDs that indicate a minion subtype. Names are best-effort based
// on HLO's published trait-ID convention; entries marked `?` are predictions
// to confirm against real HLO exports.
const MINION_TRAIT_IDS = {
  trtFamiliar:        "familiar",
  trtAnimalComp:      "animal-companion",        // ?
  trtAnimalCompanion: "animal-companion",        // ?
  trtEidolon:         "eidolon",                 // ?
  trtDrone:           "drone",                   // ?
};

/**
 * @typedef {Object} ActorTypeDecision
 * @property {"character" | "npc" | "familiar"} actorType
 * @property {string | null} minionSubtype  "familiar" | "animal-companion" | "eidolon" | "drone" | null
 * @property {number} confidence  In [0, 1]; below 0.6 is low confidence.
 * @property {string[]} reasons
 */

/**
 * @param {object} actorIR
 * @returns {ActorTypeDecision}
 */
export function detectActorType(actorIR) {
  const reasons = [];

  // Strong minion signals: name pattern + trait id. Run these first so a
  // familiar with a player owner is correctly classified as familiar
  // (familiars belong to a PC; the player field on a familiar export is
  // legitimately populated).
  const minion = detectMinion(actorIR, reasons);
  if (minion) {
    return {
      actorType: minion.actorType,
      minionSubtype: minion.subtype,
      confidence: minion.confidence,
      reasons,
    };
  }

  // Character vs NPC heuristic.
  let pcSignals = 0;
  let npcSignals = 0;

  if (typeof actorIR.player === "string" && actorIR.player.trim().length > 0) {
    pcSignals += 2;
    reasons.push(`player="${actorIR.player}" suggests PC.`);
  } else {
    npcSignals += 1;
    reasons.push("Missing player field suggests NPC.");
  }

  const hasClass = actorIR.items.some((it) => it.compset === "Class");
  if (hasClass) {
    pcSignals += 2;
    reasons.push("Class compset present (PC indicator).");
  } else {
    npcSignals += 2;
    reasons.push("No Class compset (NPC or minion indicator).");
  }

  const hasBackground = actorIR.gameValues?.backgroundText != null;
  if (hasBackground) {
    pcSignals += 1;
    reasons.push("Background text present (PC indicator).");
  }

  const hasAbilityScores = actorIR.items.filter((it) => it.compset === "AbilScore").length >= 6;
  if (hasAbilityScores) {
    pcSignals += 1;
    reasons.push("Six AbilScore items (PC ability array).");
  }

  const naturalWeaponsOnly = actorIR.items.some((it) => it.compset === "NaturalWep") &&
                              !actorIR.items.some((it) => it.compset === "Weapon");
  if (naturalWeaponsOnly) {
    npcSignals += 1;
    reasons.push("Only natural weapons (creature indicator).");
  }

  const total = pcSignals + npcSignals;
  const score = total === 0 ? 0.5 : pcSignals / total;
  const actorType = score >= 0.5 ? "character" : "npc";
  return {
    actorType,
    minionSubtype: null,
    confidence: Math.abs(score - 0.5) * 2,
    reasons,
  };
}

function detectMinion(actorIR, reasons) {
  // 1. Name pattern match.
  if (actorIR.name) {
    for (const { pattern, subtype } of MINION_NAME_PATTERNS) {
      if (pattern.test(actorIR.name)) {
        const actorType = subtype === "familiar" ? "familiar" : "npc";
        reasons.push(`Name "${actorIR.name}" matches ${subtype} pattern.`);
        return { actorType, subtype, confidence: 0.95 };
      }
    }
  }

  // 2. Trait-id match across all items.
  for (const item of actorIR.items) {
    if (!Array.isArray(item.traitIds)) continue;
    for (const tid of item.traitIds) {
      const subtype = MINION_TRAIT_IDS[tid];
      if (subtype) {
        const actorType = subtype === "familiar" ? "familiar" : "npc";
        reasons.push(`Item "${item.name}" carries trait ${tid} indicating ${subtype}.`);
        return { actorType, subtype, confidence: 0.9 };
      }
    }
  }

  // 3. Class slug familiar-ish.
  const classItem = actorIR.items.find((i) => i.compset === "Class");
  if (classItem) {
    const slug = (classItem.primarySlug ?? classItem.slug ?? "").toLowerCase();
    if (/familiar/.test(slug)) {
      reasons.push(`Class slug "${slug}" matches familiar.`);
      return { actorType: "familiar", subtype: "familiar", confidence: 0.85 };
    }
    if (/companion/.test(slug)) {
      reasons.push(`Class slug "${slug}" matches animal companion.`);
      return { actorType: "npc", subtype: "animal-companion", confidence: 0.8 };
    }
    if (/eidolon/.test(slug)) {
      reasons.push(`Class slug "${slug}" matches eidolon.`);
      return { actorType: "npc", subtype: "eidolon", confidence: 0.8 };
    }
    if (/drone/.test(slug)) {
      reasons.push(`Class slug "${slug}" matches drone.`);
      return { actorType: "npc", subtype: "drone", confidence: 0.8 };
    }
  }

  return null;
}

export default { id: "parser-actor-type" };
