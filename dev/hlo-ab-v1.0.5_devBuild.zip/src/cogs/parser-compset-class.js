// ============================================================
// COG: parser-compset-class.js - Class + Deity + Background
//                                normalizers
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.2.0
//           - v0.6.0: Background normalizer added. parser-actor.js
//             synthesizes a Background item from gameValues.
//             actBackgroundText so this handler is mostly a
//             passthrough; the synthesized item already has the
//             fields the matcher needs. Registry will route
//             Background through this handler now.
//           - 0.1.0: Migrated from src/parser/compsets/class.js as part of
//             the cog architecture pivot. Imports isSf2eClassSlug
//             from sibling system-detection cog (single source of
//             truth for SF2e class identification).

import { isSf2eClassSlug } from "./system-detection.js";

export const Class = {
  normalize(raw, _warnings) {
    const traitIds = parseTraitList(raw.Trait);
    const primarySlug = traitIds.find((t) => t.startsWith("cl")) ?? null;
    return {
      primarySlug,
      profLevel: raw.ProfLevel ?? null,
      isSf2e: primarySlug ? isSf2eClassSlug(primarySlug) : false,
    };
  },
};

export const Deity = {
  normalize(raw, _warnings) {
    const traitIds = parseTraitList(raw.Trait);
    return {
      primarySlug: traitIds.find((t) => t.startsWith("dei")) ?? null,
    };
  },
};

export const Background = {
  // Background items are synthesized by parser-actor.js from
  // gameValues.actBackgroundText (HLO does not send backgrounds as
  // compset items). The synthetic item already carries name + slug +
  // primarySlug; this handler is a passthrough so the matcher pipeline
  // can flow through unchanged.
  normalize(_raw, _warnings) {
    return {};
  },
};

function parseTraitList(traitField) {
  if (!traitField || typeof traitField !== "string") return [];
  return traitField.split(",").map((s) => s.trim()).filter(Boolean);
}

export default { id: "parser-compset-class" };
