// ============================================================
// COG: sf2e-grant-resolver.js - Pre-pull SF2e class granted
//                               features (system.items) so the
//                               wizard cascade never fires.
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.2.0
//           - HLO ChoiceSet match accuracy fix. The picker now uses
//             pickHloItemForChoiceSetAsync so Foundry-side filter
//             predicates like "item:tag:operative-specialization"
//             (which live on the matched compendium doc's
//             system.traits.otherTags, NOT on HLO's traitIds) are
//             verified against the actual fetched document. Before
//             this fix, the Operative-class Specialization ChoiceSet
//             rejected every HLO candidate ("no HLO match; ignoring
//             (fallback)") because the picker only inspected HLO-side
//             tags. After the fix, HLO-side filtering still runs
//             cheaply first (with the tag predicate deferred), and
//             only the survivors are verified against their resolved
//             compendium doc via fromUuid.
// Revision: 0.1.0
//           - v0.6.9-pass-4-deferred work, finally landed.
//             Generalized from Operative-only to every SF2e
//             class so any class import skips the choice
//             wizard. SF2e classes load their features via
//             system.items (a map of {N: {uuid, level, name,
//             img}}) plus the ClassPF2e.createGrantedItems
//             lifecycle (sf2e.mjs:50290 and :56756). Our
//             v0.6.9 prefillGrantingRules can only see rules
//             on items in our embed batch, NOT on features
//             SF2e materializes at embed time from the
//             class's system.items map. Result: ChoiceSet
//             prompts inside granted features still fire.
//
//             This cog pre-pulls the granted features
//             ourselves, walks each one for ChoiceSet +
//             GrantItem pairs, writes selections from HLO
//             ground truth, and returns a flat list of
//             feature sources WITH the bidirectional
//             flags.sf2e.itemGrants <-> flags.sf2e.grantedBy
//             chain pre-wired. The caller embeds those in
//             the same batch as the patched Class (with
//             system.items cleared so SF2e sees no
//             outstanding grants) and uses keepId:true so
//             the pre-wired IDs survive.
//
// Scope:
//   - All six published SF2e classes (Envoy, Mystic,
//     Operative, Solarian, Soldier, Witchwarper). Their
//     subclass-style grants all use the same ChoiceSet +
//     GrantItem-with-injection-token pattern that Operative
//     uses for Specialization (verified by reading the
//     pack-index-sf2e-classes-2026-05-16T04-17-30-183Z.json
//     index and the Operative fixture).
//   - Recursive: a granted feature may itself carry a
//     GrantItem rule (Sharpshooter -> Aim action). We walk
//     those too, capping recursion depth at 4 to avoid
//     pathological cycles.
//   - Standalone ChoiceSet (no chained GrantItem) is also
//     handled - the feature's own rules-selections gets the
//     picked uuid, same as prefillGrantingRules does.
//
// Out of scope (defer to a follow-up if these surface):
//   - Class-level Mechanic / Vanguard. Not in the live
//     pack index, so HLO probably can't export them yet
//     either. Will need its own session whenever Paizo
//     releases them.
//   - Multiclass dedications. The dedication feat lives on
//     the Feat list, not as a Class item; the per-feat
//     GrantItem rules already get prefilled by
//     prefillGrantingRules.
//   - Class items from pf2e-anachronism. Those are PF2e
//     classes that use system.classFeatLevels +
//     ABCItemPF2e.createGrantedItems too, but their
//     granted-feature uuids point at pf2e-anachronism
//     packs. The same logic works since fromUuid resolves
//     across compendiums; we just route through this cog
//     only when systemId === "sf2e" so PF2e callers stay
//     on the existing prefillGrantingRules path.

import { pickHloItemForChoiceSetAsync } from "./ui-import-dialog.js";

/** Cap recursion so a malformed grant chain can't loop forever. */
const MAX_GRANT_DEPTH = 4;

/**
 * Walk a Class item's system.items map, fetch every granted feature
 * whose level is at or below the actor's level, pre-fill any
 * ChoiceSet / GrantItem rules from HLO ground truth, wire the
 * bidirectional grant flags, and return:
 *   - patchedClass:    the Class source with system.items cleared so
 *                      SF2e's createGrantedItems lifecycle becomes a
 *                      no-op (it bails when no entries have a uuid).
 *   - syntheticFeatures: flat array of feature sources ready to embed
 *                      alongside patchedClass. Every feature has a
 *                      pre-assigned _id, system.location = classId,
 *                      and (for ChoiceSet+GrantItem chains) the
 *                      flags.sf2e.itemGrants/grantedBy back-references
 *                      already in place.
 *
 * Caller must embed both patchedClass AND syntheticFeatures in the
 * SAME createEmbeddedDocuments call with { keepId: true }, otherwise
 * the pre-wired IDs get rewritten and the grant chain breaks.
 *
 * Returns { patchedClass: null, syntheticFeatures: [] } if input is
 * malformed; caller should fall through to the existing
 * prefillGrantingRules path in that case.
 *
 * @param {object}   classSource    Foundry class item source object
 *                                  (the toObject() output from a
 *                                  compendium document, with
 *                                  system.items present).
 * @param {Array}    hloItems       HLO item refs from the actor parse
 *                                  pass (each has compset, slug, name,
 *                                  traitIds, level...). Used to
 *                                  resolve ChoiceSet selections.
 * @param {number}   actorLevel     The character's current level. Used
 *                                  to filter system.items entries by
 *                                  their level field.
 * @param {Function} pushDebug      Optional per-decision debug logger.
 */
export async function resolveSf2eClassGrants(
  classSource,
  hloItems = [],
  actorLevel = 1,
  pushDebug = () => {},
) {
  if (!classSource || typeof classSource !== "object") {
    return { patchedClass: null, syntheticFeatures: [] };
  }
  if (classSource.type !== "class") {
    return { patchedClass: null, syntheticFeatures: [] };
  }
  const sysItems = classSource.system?.items;
  if (!sysItems || typeof sysItems !== "object") {
    return { patchedClass: classSource, syntheticFeatures: [] };
  }

  // The class needs a stable _id BEFORE we start so every granted
  // feature can point system.location at it. randomID is the same
  // helper SF2e itself uses (sf2e.mjs:48324).
  const patchedClass = foundry.utils.deepClone(classSource);
  patchedClass._id ??= foundry.utils.randomID();
  const classId = patchedClass._id;
  const className = patchedClass.name ?? "(unnamed class)";

  const eligibleEntries = Object.values(sysItems)
    .filter((e) => e && typeof e === "object" && typeof e.uuid === "string")
    .filter((e) => {
      const lvl = Number(e.level);
      if (!Number.isFinite(lvl)) return true;
      return lvl <= actorLevel;
    });

  if (eligibleEntries.length === 0) {
    // Nothing to materialize at this level. Still clear system.items
    // so SF2e does not try to re-grant on next prepare.
    patchedClass.system = patchedClass.system ?? {};
    patchedClass.system.items = {};
    return { patchedClass, syntheticFeatures: [] };
  }

  pushDebug(`SF2e grant resolver: ${className} has ${eligibleEntries.length} class feature(s) at or below level ${actorLevel}.`);

  const synthetic = [];
  for (const entry of eligibleEntries) {
    const feature = await materializeGrantedFeature({
      uuid: entry.uuid,
      grantedLevel: Number.isFinite(Number(entry.level)) ? Number(entry.level) : null,
      granterId: classId,
      granterIsClass: true,
      hloItems,
      pushDebug,
      depth: 0,
      synthetic,
    });
    if (feature) synthetic.push(feature);
  }

  // SF2e's createGrantedItems short-circuits when no entries carry a
  // uuid (sf2e.mjs:50292). Setting system.items = {} matches that
  // bail condition exactly so the lifecycle stays a no-op.
  patchedClass.system = patchedClass.system ?? {};
  patchedClass.system.items = {};

  pushDebug(`SF2e grant resolver: ${className} produced ${synthetic.length} pre-resolved feature source(s).`);
  return { patchedClass, syntheticFeatures: synthetic };
}

/**
 * Fetch a single feature by uuid, clone its source, assign an _id,
 * write system.location so SF2e routes it to the granter, pre-fill
 * any ChoiceSet/GrantItem rules from HLO, and recursively materialize
 * any chained GrantItem children that resolve to a fetchable uuid.
 *
 * Mutates `synthetic` (the running flat list) when recursing; returns
 * the top-level feature source so the caller can push it too.
 */
async function materializeGrantedFeature({
  uuid,
  grantedLevel,
  granterId,
  granterIsClass,
  hloItems,
  pushDebug,
  depth,
  synthetic,
}) {
  if (depth > MAX_GRANT_DEPTH) {
    pushDebug(`SF2e grant resolver: depth ${depth} exceeded for uuid ${uuid}; skipping to avoid infinite recursion.`);
    return null;
  }

  const doc = await safeFromUuid(uuid, pushDebug);
  if (!doc) return null;
  const featureSource = doc.toObject();

  // Stable id for every granted feature so child grants can target
  // it and the patched class's setProperty walks survive embed.
  featureSource._id = foundry.utils.randomID();

  // Level on classfeature-category feats matches the entry.level from
  // the class's system.items map (sf2e.mjs:50297-50298).
  if (
    granterIsClass
    && featureSource.type === "feat"
    && featureSource.system?.category === "classfeature"
    && Number.isFinite(grantedLevel)
  ) {
    featureSource.system.level = featureSource.system.level ?? {};
    featureSource.system.level.value = grantedLevel;
  }

  // system.location binds the feat to its parent class slot (matches
  // the Operative lvl5 fixture: line 1014 -> "location": class _id).
  // SF2e's ABCItemPF2e.createGrantedItems sets this at sf2e.mjs:50300.
  if (featureSource.type === "feat") {
    featureSource.system = featureSource.system ?? {};
    featureSource.system.location = granterId;
  }

  // Ensure the granter's flag scaffold exists. SF2e's GrantItem
  // constructor reads parent.flags.sf2e.itemGrants (sf2e.mjs:48255)
  // and crashes if the parent path is missing.
  featureSource.flags = featureSource.flags ?? {};
  featureSource.flags.sf2e = featureSource.flags.sf2e ?? {};
  featureSource.flags.sf2e.itemGrants = featureSource.flags.sf2e.itemGrants ?? {};

  // Rule walk: handle ChoiceSet + GrantItem injection-token pairs and
  // standalone GrantItem(concrete uuid) entries the same way
  // prefillGrantingRules does for top-level grant-bearing items, then
  // for any GrantItem whose resolved uuid points at a real fetchable
  // item, materialize the grantee recursively and wire the
  // bidirectional flag chain.
  const rules = Array.isArray(featureSource.system?.rules) ? featureSource.system.rules : [];
  if (rules.length === 0) return featureSource;

  // Pass 1: index ChoiceSets by flag and resolve any standalone
  // ChoiceSet selection from HLO so injection tokens can read it.
  const choiceSetByFlag = new Map();
  const rulesSelections = (featureSource.flags.sf2e.rulesSelections = featureSource.flags.sf2e.rulesSelections ?? {});
  for (const rule of rules) {
    if (rule?.key !== "ChoiceSet") continue;
    if (typeof rule.flag !== "string" || !rule.flag) continue;
    choiceSetByFlag.set(rule.flag, rule);
    if (rule.selection != null && rule.selection !== "") {
      rulesSelections[rule.flag] = rule.selection;
      continue;
    }
    // Use the async picker so Foundry-side filters (e.g.
    // "item:tag:operative-specialization", which lives on the doc's
    // system.traits.otherTags, NOT on the HLO export) get verified
    // against the matched compendium document. The sync picker only
    // checks HLO traitIds and would miss every subclass-style ChoiceSet
    // whose filter targets a Foundry-only slot tag.
    const picked = await pickHloItemForChoiceSetAsync(rule, hloItems);
    if (picked) {
      rule.selection = picked.uuid;
      rulesSelections[rule.flag] = picked.uuid;
      pushDebug(`SF2e grant resolver: ${featureSource.name}.ChoiceSet[${rule.flag}] selection -> ${picked.pack}/${picked.slug} (from HLO "${picked.hloName}")`);
    } else {
      rule.ignored = true;
      rule.allowNoSelection = true;
      pushDebug(`SF2e grant resolver: ${featureSource.name}.ChoiceSet[${rule.flag}] no HLO match; ignoring (fallback).`);
    }
  }

  // Pass 2: GrantItem rules. Two variants matter for SF2e classes:
  //   (a) Injection-token uuid {item|flags.system.rulesSelections.X}
  //       -> resolve X via the sibling ChoiceSet from pass 1.
  //   (b) Concrete compendium uuid -> fetch and recurse directly.
  // After resolving the grantee uuid we materialize the child,
  // wire the bidirectional flags chain, and drop the GrantItem rule
  // from the running feature's rules array (so SF2e does not re-grant
  // when we embed - the grant is already realized in our synthetic
  // batch).
  const surviving = [];
  for (const rule of rules) {
    if (rule?.key !== "GrantItem") {
      surviving.push(rule);
      continue;
    }
    const flag = typeof rule.flag === "string" ? rule.flag : null;
    const ruleUuid = typeof rule.uuid === "string" ? rule.uuid : "";
    let resolvedUuid = ruleUuid;
    if (ruleUuid.startsWith("{") && ruleUuid.endsWith("}")) {
      const match = ruleUuid.match(/rulesSelections\.([A-Za-z0-9_-]+)/);
      const sourceFlag = match?.[1] ?? null;
      resolvedUuid = sourceFlag ? rulesSelections[sourceFlag] ?? null : null;
      if (!resolvedUuid) {
        pushDebug(`SF2e grant resolver: ${featureSource.name}.GrantItem injection ${ruleUuid} did not resolve; dropping rule.`);
        continue;
      }
    }
    if (typeof resolvedUuid !== "string" || !resolvedUuid) {
      surviving.push(rule);
      continue;
    }

    const child = await materializeGrantedFeature({
      uuid: resolvedUuid,
      grantedLevel: null,
      granterId: featureSource._id,
      granterIsClass: false,
      hloItems,
      pushDebug,
      depth: depth + 1,
      synthetic,
    });
    if (!child) {
      pushDebug(`SF2e grant resolver: ${featureSource.name}.GrantItem could not materialize ${resolvedUuid}; dropping rule.`);
      continue;
    }

    // Bidirectional flag wiring matches the SF2e GrantItem flow at
    // sf2e.mjs:48403-48423. The flag key defaults to a sluggified
    // version of the grantee slug/name when no explicit flag was set
    // (sf2e.mjs:48313).
    const flagKey = flag && flag.length > 0
      ? flag
      : (child.system?.slug || child.name || "grant")
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-+|-+$/g, "");

    featureSource.flags.sf2e.itemGrants[flagKey] = {
      id: child._id,
      onDelete: "detach",
    };
    child.flags = child.flags ?? {};
    child.flags.sf2e = child.flags.sf2e ?? {};
    child.flags.sf2e.grantedBy = {
      id: featureSource._id,
      // SF2e defaults non-physical grantees to cascade (sf2e.mjs:48418).
      onDelete: "cascade",
    };
    synthetic.push(child);
    pushDebug(`SF2e grant resolver: ${featureSource.name} -granted-> ${child.name} (flag ${flagKey}, child id ${child._id}).`);
    // Drop the rule: the grant is already realized.
  }
  featureSource.system.rules = surviving;
  return featureSource;
}

/**
 * Wrapper around fromUuid that swallows transient compendium errors
 * and logs them at debug level. Returns null on any failure so the
 * caller can carry on with the remaining grants.
 */
async function safeFromUuid(uuid, pushDebug) {
  try {
    const doc = await fromUuid(uuid);
    if (!doc) {
      pushDebug(`SF2e grant resolver: fromUuid(${uuid}) returned null; skipping grant.`);
      return null;
    }
    return doc;
  } catch (err) {
    pushDebug(`SF2e grant resolver: fromUuid(${uuid}) threw "${err?.message ?? err}"; skipping grant.`);
    return null;
  }
}
