// ============================================================
// COG: import-conversion-journal.js - Persist post-import
//                                     conversion log to a Foundry
//                                     JournalEntry
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-15
// Revision: 0.2.0
//           - Wave 5 of the cog migration. Promoted from
//             src/import/conversion-journal.js. Internal import
//             still points at ../util/version.js; that gets
//             relocated to a sibling cog in Wave 6.
//           - 0.1.0: Wave 6 (in src/import/). Optional
//             conversion-log persistence. After a successful
//             import, a JournalEntry can be created carrying the
//             full structured log: matches by strategy, misses,
//             warnings, the source HLO portfolio identifier.
//             Users can review imports days or weeks later via
//             the standard Foundry journal UI.

import { MODULE_ID } from "./util-version.js";

/**
 * Render the structured log records into a single HTML payload suitable
 * for a JournalEntry's content. The format groups by level (info, warn,
 * error) and pulls out the counts at the top.
 */
export function renderLogAsHtml(records, actorName, charId) {
  const byLevel = { info: [], warn: [], error: [] };
  for (const r of records) {
    if (byLevel[r.level]) byLevel[r.level].push(r.message);
  }
  const headline = `HLO Import Conversion Log`;
  const subtitle = `Actor: ${actorName ?? "Unknown"} (charId ${charId ?? "Unknown"})`;
  const counts = `${byLevel.info.length} info, ${byLevel.warn.length} warn, ${byLevel.error.length} error`;
  const ts = new Date().toISOString();
  const renderList = (label, items) => items.length === 0 ? "" : (
    `<h3>${label} (${items.length})</h3><ul>${items.map((m) => `<li>${escapeHtml(m)}</li>`).join("")}</ul>`
  );
  return [
    `<h2>${headline}</h2>`,
    `<p><em>${escapeHtml(subtitle)}</em></p>`,
    `<p>${counts}, generated ${ts}</p>`,
    renderList("Errors", byLevel.error),
    renderList("Warnings", byLevel.warn),
    renderList("Info", byLevel.info),
  ].join("");
}

/**
 * Create a JournalEntry capturing the conversion log. Returns the created
 * entry, or null if creation failed (the import itself should not roll
 * back on log failures).
 */
export async function createConversionJournal({ records, actorName, charId, importedActor }) {
  if (typeof JournalEntry === "undefined") return null;
  const content = renderLogAsHtml(records, actorName, charId);
  const title = `HLO Import: ${actorName ?? "Unknown"} (${new Date().toISOString().slice(0, 10)})`;
  try {
    // CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML = 1 (V14 contract, see
    // docs/FOUNDRY_API_NOTES.md). Using the named constant instead of
    // the magic number 1 so the next maintainer does not have to guess
    // what 1 means.
    const htmlFormat = CONST?.JOURNAL_ENTRY_PAGE_FORMATS?.HTML ?? 1;
    return await JournalEntry.create({
      name: title,
      pages: [{
        name: "Conversion Log",
        type: "text",
        text: { content, format: htmlFormat },
      }],
      flags: {
        [MODULE_ID]: {
          importedActorId: importedActor?.id ?? null,
          charId: charId ?? null,
          generatedAt: new Date().toISOString(),
        },
      },
    });
  } catch (_err) {
    return null;
  }
}

function escapeHtml(s) {
  if (s == null) return "";
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
