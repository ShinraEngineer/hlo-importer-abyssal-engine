// ============================================================
// COG: parser-compset-registry.js - Compset handler dispatch table
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.4.0
//           - v0.7.1 integration pass: registered Rune and Material
//             compsets. These do NOT produce embedded items - the
//             builder-items.js pre-pass (applyRuneAndMaterialPatches)
//             merges them into the parent weapon/armor IR's runes/
//             material fields via the _runeApplyTo / _materialApplyTo
//             discriminator pattern (same shape as Faction's
//             _actorMetadata from v0.7.0). Resolves the 49+ "Unknown
//             compset Rune" warnings + 1 "Unknown compset Material"
//             warning observed across the 5-character v0.7.0 test
//             corpus. Critically resolves Berial Jeggare PFS's
//             Numerian Steel Breastplate losing its fire-resistant
//             property rune (the breastplate name carries zero rune
//             data; the rune data exists only in the standalone
//             ruArmResistFire item, which v0.7.0 silently dropped).
//             Verified: all 3 nested runes on Berial's breastplate
//             merge correctly, all 4 runes + Material on Bhelroth's
//             bastard sword land, Revascis Virholt's full plate +
//             aldori dueling sword both get correct rune blocks.
//             Zero unknown-rune warnings across all 3 verification
//             characters after this revision.
//           - 0.3.0: v0.7.0 integration pass: registered the 8 HLO compsets
//             that were silently degrading to "Unknown compset" in
//             v0.6.13 imports of PFS / magic-item-heavy characters.
//             Berial Jeggare (PF2e Wizard 8 PFS test fixture) carried
//             28 such items across these compsets that all dropped:
//             MagicItem (8 incl. handwraps + mantle + belt + potions
//             + aeon stone), CustomReward (8 PFS chronicle boons),
//             Faction (6 PFS faction memberships), CustomArmor (1
//             Numerian Steel Breastplate - his ACTUAL armor), Wand
//             (1), GearItem (1), Spellbook (2), CustomBoon (1). All
//             eight handlers ship together in this revision. Routing
//             splits three ways:
//               * Compendium-eligible (MagicItem, CustomArmor, Wand,
//                 GearItem): added to COMPSET_TO_PACKS in matcher-
//                 slug-table.js and dispatched to equipment-srd via
//                 the standard hybrid match pipeline.
//               * Actor-metadata (Faction): IR-patch carries
//                 _actorMetadata discriminator; builder-actor-pf2e
//                 routes to system.pfs.reputation (verified against
//                 pf2e template.json line 106-120). NOT an embedded
//                 item.
//               * Campaign features (CustomReward, CustomBoon): IR-
//                 patch carries _homebrewItem discriminator with
//                 type=campaignFeature, category=pfsboon. Embedded
//                 via the standard items path. PF2e sheet renders
//                 these in the PFS tab automatically.
//               * SKIP_BY_DESIGN (Spellbook): PF2e does not model
//                 the spellbook as a discrete Foundry item. The
//                 spellcastingEntry that anchors a Wizard's spell
//                 list is auto-provisioned by the Wizard class's
//                 GrantItem rules at embed time. Spellbook handler
//                 returns empty IR patch; matcher-overrides has the
//                 SKIP_BY_DESIGN entry for the dispatch reason.
//             Verified: Berial's 28 items all land in the right
//             places after this revision. The Weapon compset also
//             gained rune extraction in this pass (util-rune-parser
//             0.1.0), so "+1 striking wounding bastard sword" no
//             longer drops the magical properties.
//           - 0.2.0: Registered the FocSpell compset to the existing
//             Spell handler. HLO emits focus spells with a distinct
//             compset name (FocSpell, id prefix "fs"), but the
//             field schema HLO surfaces is identical to ranked
//             spells (rank, DC, save, range, target, action). The
//             Spell normalizer already captures those fields, so
//             FocSpell reuses it. Without this entry, parser-items
//             logs every focus spell as "Unknown compset" and the
//             item falls through with raw data only (caught in
//             the 2026-05-16 V14 import-log dump as fsHandApprentice
//             -> "Hand of the Apprentice").
//           - 0.1.0: Migrated from src/parser/compsets/index.js as
//             part of the cog architecture pivot. Maps HLO compset
//             names to handler modules. Imports each per-compset
//             handler from its own sibling cog
//             (parser-compset-abilities, etc.). Each handler exposes
//             a `normalize(raw, warnings)` function that returns an
//             object merged into the item IR by parser-items.

import * as Abilities      from "./parser-compset-abilities.js";
import * as AncestryMod    from "./parser-compset-ancestry.js";
import * as ClassMod       from "./parser-compset-class.js";
import * as Feats          from "./parser-compset-feats.js";
import * as Spells         from "./parser-compset-spells.js";
import * as Weapons        from "./parser-compset-weapons.js";
import * as ArmorMod       from "./parser-compset-armor.js";
import * as Gear           from "./parser-compset-gear.js";
import * as Augmentations  from "./parser-compset-augmentations.js";
import * as MagicItemMod   from "./parser-compset-magicitem.js";
import * as CustomArmorMod from "./parser-compset-customarmor.js";
import * as WandMod        from "./parser-compset-wand.js";
import * as GearItemMod    from "./parser-compset-gearitem.js";
import * as SpellbookMod   from "./parser-compset-spellbook.js";
import * as FactionMod     from "./parser-compset-faction.js";
import * as CustomRewardMod from "./parser-compset-customreward.js";
import * as RuneMod         from "./parser-compset-rune.js";
import * as MaterialMod     from "./parser-compset-material.js";

export const COMPSET_HANDLERS = {
  // abilities cog handles all stat-bearing compsets
  AbilScore:    Abilities.AbilScore,
  Save:         Abilities.Save,
  Skill:        Abilities.Skill,
  ArmorClass:   Abilities.ArmorClass,
  Movement:     Abilities.Movement,
  Reserves:     Abilities.Reserves,
  Derived:      Abilities.Derived,

  // ancestry cog handles identity-shaping compsets
  Ancestry:     AncestryMod.Ancestry,
  Heritage:     AncestryMod.Heritage,
  Language:     AncestryMod.Language,

  // class cog handles class, deity, and background selections
  Class:        ClassMod.Class,
  Deity:        ClassMod.Deity,
  Background:   ClassMod.Background,

  // Phase 2 handlers
  Feat:         Feats.Feat,
  Action:       Feats.Action,
  Ability:      Feats.Ability,
  Spell:        Spells.Spell,
  FocSpell:     Spells.Spell,   // HLO focus-spell compset (id prefix "fs"); shares schema with Spell
  Weapon:       Weapons.Weapon,
  NaturalWep:   Weapons.NaturalWep,
  WeaponTrait:  Weapons.WeaponTrait,
  Ammunition:   Weapons.Ammunition,
  Armor:        ArmorMod.Armor,
  ArmorTrait:   ArmorMod.ArmorTrait,
  Upgrade:      ArmorMod.Upgrade,
  GearBasic:    Gear.GearBasic,
  Trait:        Gear.Trait,

  // Phase 3 handler
  Augmentation: Augmentations.Augmentation,

  // v0.7.0 handlers: magic items, custom armor, wands, custom gear
  MagicItem:    MagicItemMod.MagicItem,
  CustomArmor:  CustomArmorMod.CustomArmor,
  Wand:         WandMod.Wand,
  GearItem:     GearItemMod.GearItem,

  // v0.7.0 handler: HLO Wizard spellbook container (SKIP_BY_DESIGN -
  // PF2e auto-provisions the spellcastingEntry via the Wizard class's
  // GrantItem rules; see matcher-overrides.js for the skip entry).
  Spellbook:    SpellbookMod.Spellbook,

  // v0.7.0 PFS handlers: faction memberships route to actor metadata
  // via _actorMetadata discriminator; chronicle boons embed as
  // campaignFeature items via _homebrewItem discriminator.
  // CustomBoon piggybacks the CustomReward handler module since they
  // share the boon shape; the registry routes both compsets to it.
  Faction:      FactionMod.Faction,
  CustomReward: CustomRewardMod.CustomReward,
  CustomBoon:   CustomRewardMod.CustomBoon,

  // v0.7.1 apply-to-parent handlers: Rune and Material items merge
  // into the parent weapon/armor IR via _runeApplyTo /
  // _materialApplyTo discriminator patches. builder-items.js
  // applyRuneAndMaterialPatches consumes them in a pre-build pass;
  // they never become embedded items on the actor.
  Rune:         RuneMod.Rune,
  Material:     MaterialMod.Material,
};

export const KNOWN_COMPSETS = new Set(Object.keys(COMPSET_HANDLERS));

/**
 * Dispatch a single raw item to its compset handler. Returns the normalization
 * patch (the object merged into the item IR by parser-items). If the compset is
 * unknown, returns an empty object and lets the dispatcher log a warning.
 */
export function dispatchCompset(raw, warnings) {
  const handler = COMPSET_HANDLERS[raw?.compset];
  if (!handler) return {};
  return handler.normalize(raw, warnings);
}

export default { id: "parser-compset-registry" };
