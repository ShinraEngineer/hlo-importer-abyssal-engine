// ============================================================
// COG: parser-compset-spellbook.js - Spellbook compset stub
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.1.0
//           - Initial implementation. HLO emits Wizard (and other
//             prepared-caster) spellbooks as their own compset
//             "Spellbook" with id prefix "gr" (overlapping the
//             GearBasic prefix; compset is the source of truth, not
//             the prefix). The Berial Jeggare (PFS) fixture (PF2e
//             Wizard 8) carries two entries: grSpellbook.878 (the
//             primary spellbook, holding 53 prepared and known
//             spells as nested children with containment="Installed")
//             and grSpellbook.1356 (an empty backup spellbook).
//
// RESEARCH FINDING: PF2e (v8.1.2) and SF2e (v1.1.2) do NOT model the
// spellbook as a discrete Foundry item. Evidence:
//
//   1. PF2e ITEM_TYPES (pf2e.mjs line 3281-3306) enumerates 23 item
//      types. The closest match is "book" (line 3289), implemented as
//      BookPF2e (pf2e.mjs line 55489), which is a generic
//      PhysicalItemPF2e subtype used for in-world tomes and reading
//      material, NOT a spellcasting container.
//
//   2. The equipment-srd pack ships zero entries with a "spellbook"
//      slug or a bare "Spellbook" name. The only book-themed
//      equipment is "Spellbook of Redundant Enchantment" (a specific
//      magic item, not the generic spellbook every wizard carries).
//
//   3. The mechanism PF2e uses is the spellcastingEntry item type
//      plus its child spell items. The Wizard class entry uses
//      GrantItem rule elements to install the "Wizard Spellcasting"
//      class feature, which in turn provisions the spellcastingEntry
//      on the actor; prepared spells live as child items keyed by
//      `system.location` pointing back to the spellcastingEntry id.
//      Verified against the Berial Jeggare Foundry export
//      (fvtt-Actor-berial-jeggare-(pfs)-fpGhYbzcmO4HOpfF.json,
//      2026-05-16): the imported actor contains the Wizard class
//      (id UZ06BR9t2qLFRWYr), the "Wizard Spellcasting" feat
//      (location UZ06BR9t2qLFRWYr), all the prepared spells, and
//      NO item named "Spellbook" at all. SF2e follows the same
//      pattern (sf2e.mjs line 3304 lists the same spellcastingEntry
//      type; no separate spellbook item).
//
// DECISION: SKIP_BY_DESIGN. The Spellbook compset is a HLO-side
// organisational container with no Foundry equivalent. The spells
// it holds reach the actor through the standard Spell-compset
// pipeline; the spellcastingEntry that anchors them is provisioned
// by the Wizard class entry's GrantItem rules during class embed.
// Emitting any item for the Spellbook itself would either land a
// phantom physical "book" on the actor or silently fail compendium
// lookup as a real miss.
//
// This handler returns an empty IR patch so the dispatcher in
// parser-items.js recognises the compset cleanly (no
// "unknown-compset" warning) and the matcher's SKIP_BY_DESIGN
// pre-check in matcher-core.js short-circuits with a strategy="skip"
// record. The corresponding SKIP_BY_DESIGN entry is registered in
// matcher-overrides.js as "Spellbook:grSpellbook".

export const Spellbook = {
  normalize(_raw, _warnings) {
    // Intentionally empty: see header for the rationale. The matcher's
    // SKIP_BY_DESIGN check filters every grSpellbook line before it
    // reaches the compendium lookup, so no IR fields are required.
    return {};
  },
};

export default { id: "parser-compset-spellbook" };
