// ============================================================
// COG: import-extract-overrides.js - Override stub extractor
//                                    from conversion-log warnings
// ============================================================
// Author:   Shinra CC
// Date:     2026-05-16
// Revision: 0.2.2
//           - v0.7.1 (pass 3): suggestPackFor now covers FocSpell,
//             MagicItem, CustomArmor, Wand, and GearItem. Previously
//             defaulted to null for these because they did not exist
//             when the helper was first written; with the v0.7.1
//             silent-drop fix in ui-import-dialog now surfacing
//             these compsets in the unmatched modal, suggestPackFor
//             needs a route for each so the modal's Suggested Pack
//             column has a value to render. All four route to
//             "equipment" (PF2e users rewrite to "equipment-srd"
//             when pasting into overrides.js, same as the existing
//             entries). FocSpell routes to "spells" by parallel to
//             Spell, matching the FocSpell -> spells-srd routing
//             added in matcher-slug-table.js 0.4.1.
//           - 0.2.1: Exported `suggestPackFor(compset)` so the new
//             ui-unmatched-modal cog can populate its
//             "Suggested Pack" column from the same compset
//             table the override-stub renderer uses. No logic
//             change to the function body itself; previously a
//             module-private helper.
//           - 0.2.0: Wave 5 of the cog migration. Promoted from
//             src/import/extract-overrides.js. No logic changes.
//           - 0.1.1: Wave 2 cog migration follow-up. Updated
//             comment refs from src/matcher/overrides.js ->
//             src/cogs/matcher-overrides.js so the printed
//             banner and JSDoc point at the new path.
//           - 0.1.0: Wave 9 (in src/import/). Override stub
//             extractor. Scans conversion log records for
//             "Unmatched <compset>: <name> (slug X)" lines and
//             produces ready-to-paste entries for src/cogs/
//             matcher-overrides.js. The Foundry-side slug needs
//             to be filled in by hand; the tool emits a
//             placeholder so the workflow is "run import, copy
//             stubs, look up real slugs, paste".

const UNMATCHED_RE = /^Unmatched ([A-Z][A-Za-z]*): (.+?) \(slug ([a-zA-Z0-9_-]+)\)/;

/**
 * Parse the dialog's structured log records (array of { level, message })
 * for "Unmatched" warnings and return a list of stub entries.
 */
export function extractFromLogRecords(records) {
  const out = [];
  for (const r of records ?? []) {
    if (r.level !== "warn") continue;
    const m = UNMATCHED_RE.exec(r.message ?? "");
    if (!m) continue;
    const [, compset, name, hloSlug] = m;
    out.push({
      compset,
      name,
      hloSlug,
      suggestedPack: suggestPackFor(compset),
    });
  }
  return out;
}

/**
 * Parse the rendered HTML of a saved conversion journal entry. Uses a
 * simple regex against the structure produced by renderLogAsHtml; the
 * doc shape is stable so this is safe.
 */
export function extractFromJournalHtml(html) {
  const records = [];
  const liRe = /<li>([^<]*Unmatched[^<]*)<\/li>/g;
  let m;
  while ((m = liRe.exec(html ?? "")) !== null) {
    records.push({ level: "warn", message: m[1] });
  }
  return extractFromLogRecords(records);
}

/**
 * Render the stubs as JavaScript source ready to paste into overrides.js.
 */
export function renderStubsAsSource(stubs) {
  if (stubs.length === 0) return "// (no unmatched items to extract)\n";
  const lines = [
    "// Generated override stubs from a conversion log.",
    "// Replace PUT-FOUNDRY-SLUG-HERE with the real slug from the Foundry",
    "// compendium browser, then paste into src/cogs/matcher-overrides.js.",
    "",
  ];
  for (const s of stubs) {
    const pack = s.suggestedPack ?? "PACK";
    lines.push(`["${s.compset}:${s.hloSlug}", { pack: "${pack}", slug: "PUT-FOUNDRY-SLUG-HERE" }],  // ${s.name}`);
  }
  return lines.join("\n") + "\n";
}

// Pack-name suggestion. Defaults to SF2e-style kebab-case since SF2e is
// the more common authoring path. PF2e users should s/feats/feats-srd/,
// s/actions/actionspf2e/, s/spells/spells-srd/, s/equipment/equipment-srd/
// before pasting into overrides.js. The stub header comment notes this.
// Exported so the unmatched-modal can populate the "Suggested Pack" column
// without duplicating this compset table.
//
// v0.7.1 (pass 3): added the v0.7.0 compsets (FocSpell, MagicItem,
// CustomArmor, Wand, GearItem) so the unmatched-modal can suggest a
// sensible pack for them too, instead of leaving the column blank when
// one of those misses now surfaces under the silent-drop fix in
// ui-import-dialog COMPENDIUM_COMPSETS.
export function suggestPackFor(compset) {
  switch (compset) {
    case "Ancestry":    return "ancestries";
    case "Heritage":    return "heritages";
    case "Class":       return "classes";
    case "Deity":       return "deities";
    case "Feat":        return "feats";
    case "Action":      return "actions";
    case "Ability":     return "actions";
    case "Spell":       return "spells";
    case "FocSpell":    return "spells";
    case "Weapon":      return "equipment";
    case "NaturalWep":  return "equipment";
    case "Armor":       return "equipment";
    case "GearBasic":   return "equipment";
    case "Ammunition":  return "equipment";
    case "Upgrade":     return "equipment";
    case "Augmentation":return "equipment";
    // v0.7.0 compsets routed to equipment / consumables / containers
    // / magic-items. "equipment" is the most common landing pack for
    // each; PF2e users still need to rewrite to "equipment-srd" before
    // pasting into overrides.js, same caveat as the older entries.
    case "MagicItem":   return "equipment";
    case "CustomArmor": return "equipment";
    case "Wand":        return "equipment";
    case "GearItem":    return "equipment";
    default: return null;
  }
}
